<?php
require_once "./config/app.php";
require_once "./autoload.php";
require_once "./app/views/inc/session_start.php";

    if (isset($_GET['views'])) {
        $url = explode("/", $_GET['views']);
    } else {
        $url = ["dashboardUsuario"];
    }

    if ($url[0] === "recuperar-contrasena" && isset($url[1]) && $url[1] === "recuperarContrasena") {
        $controllerUsuario = new app\controllers\controllerUsuario();
        $controllerUsuario->recuperarContrasena();
        exit(); 
    }

    if ($url[0] === "cita-especialista-fecha" && isset($url[1]) && $url[1] === "obtenerEspecialistasDias") {
        $controllerPaciente = new app\controllers\controllerPaciente();
        if (isset($_POST['especialidadCodigo'])) {
            $controllerPaciente->obtenerEspecialistasDias($_POST['especialidadCodigo']);
        }
        exit(); 
    }

    if ($url[0] === "cita-hora" && isset($url[1]) && $url[1] === "obtenerDisponibilidadHoras") {
        $controllerPaciente = new app\controllers\controllerPaciente();
        if (isset($_POST['especialistaCodigo'])) {
            $controllerPaciente->obtenerDisponibilidadHoras($_POST['especialistaCodigo']);
        }
        exit(); 
    }
?>

<!DOCTYPE html>
<html lang="es">
    <head>
        <?php require_once "./app/views/inc/head.php"; ?>
    </head>
        <body>
            <?php
                use app\controllers\controllerVista;
                use app\controllers\controllerAcceso;

                $objAcceso = new controllerAcceso();

                $vistasPermitidas = [
                    "dashboardUsuario", "especialistasInfo", "quienesSomos", "soporteUsuario", 
                    "acceso", "recuperarContrasena", "registrarUsuario", "terminosCondiciones", "politicaPrivacidad",
                    "dashboard", "usuarioNuevo", "usuarioPersonaLista", "usuarioActualizar", "usuarioPersonaBuscar", 
                    "usuarioFoto", "cerrarSesion", "especialistaLista", "especialistaBuscar", "pacienteLista",
                    "pacienteBuscar", "especialidadNuevo", "especialidadLista", "especialidadBuscar", "especialidadActualizar", "especialidadFoto", 
                    "citasPendientes", "historialCitasEsp", "citasEspecialistasBuscar", "misPacientes", "miDisponibilidad", "usuarioActualizarEspecialista", 
                    "citasAgendadas", "historialCitasPac", "citasPacientesBuscar", "misEspecialistas", "serviciosMedicos", "soportePaciente", "usuarioActualizarPaciente", "eliminarUsuario"
                ];
                
                $vistaSolicitada = $url[0] . "-vista.php";

                if (in_array($url[0], $vistasPermitidas)) {
                    if (!isset($_SESSION['codigo'])) {
                        require_once "./app/views/inc/navbarUsuario.php";
                        require_once "./app/views/content/" . $vistaSolicitada; 
                    } else {
                        switch ($_SESSION['rol']) {
                            case 'Administrador':
                                require_once "./app/views/inc/navbarAdministrador.php";
                                break;
                            case 'Especialista':
                                require_once "./app/views/inc/navbarEspecialista.php";
                                break;
                            case 'Paciente':
                                require_once "./app/views/inc/navbarPaciente.php";
                                break;
                        }
                        require_once "./app/views/content/" . $vistaSolicitada;
                    }
                } else {
                    require_once "./app/views/content/404-vista.php";
                }
                require_once "./app/views/inc/script.php";
            ?>
        </body>
<footer>
<?php
require_once "./app/views/inc/footer.php"; 
?>
</footer>
</html>