<?php 
	namespace app\controllers;
	use app\models\modelCrud;

    class controllerPersona extends modelCrud {

        public function listarPersona($pagina, $registros, $url) {
    		if ($_SESSION['codigo'] != 1) {
    			session_destroy();
    			header("Location: " . APP_URL . "app/views/content/404-vista");
    			exit();
    		}
        
    		$pagina = $this->limpiarCadena($pagina);
    		$registros = $this->limpiarCadena($registros);
    		$url = $this->limpiarCadena($url);
    		$url = APP_URL . $url . "/";
        
    		$tabla = "";
        
    		$pagina = (isset($pagina) && $pagina > 0) ? (int)$pagina : 1;
    		$inicio = ($pagina > 0) ? (($pagina * $registros) - $registros) : 0;

    		$consulta_datos = "SELECT * FROM persona p INNER JOIN usuario u ON p.usua_codigo_fk = u.usua_codigo WHERE p.usua_codigo_fk != '".$_SESSION['codigo']."' AND p.usua_codigo_fk != '1' ORDER BY p.apellido ASC LIMIT $inicio, $registros;";
        
    		$consulta_total = "SELECT COUNT(usua_codigo_fk) FROM persona p INNER JOIN usuario u ON p.usua_codigo_fk = u.usua_codigo WHERE p.usua_codigo_fk != '".$_SESSION['codigo']."' AND p.usua_codigo_fk != '1';";
        
    		$datos = $this->ejecutarConsulta($consulta_datos);
    		$datos = $datos->fetchAll();
        
    		$total = $this->ejecutarConsulta($consulta_total);
    		$total = (int)$total->fetchColumn();
        
    		$numeroPaginas = ceil($total / $registros);
        
    		$tabla .= '
    			<div class="table-container">
    			<table class="table is-bordered is-striped is-narrow is-hoverable is-fullwidth">
    				<thead>
    					<tr>
    						<th class="has-text-centered">#</th>
    						<th class="has-text-centered">Nombres y Apellidos</th>
    						<th class="has-text-centered">ID</th>
    						<th class="has-text-centered">Tipo ID</th>
    						<th class="has-text-centered">Edad</th>
    						<th class="has-text-centered">Sexo</th>
    						<th class="has-text-centered">Celular</th>
    						<th class="has-text-centered">Dirección</th>
    						<th class="has-text-centered">Teléfono 2</th>
    					</tr>
    				</thead>
    				<tbody>
    		';
        
    		if ($total >= 1 && $pagina <= $numeroPaginas) {
    			$contador = $inicio + 1;
    			$pag_inicio = $inicio + 1;
    			foreach ($datos as $filas) {
    				$tabla .= '
    					<tr class="has-text-centered">
    						<td>' . $contador . '</td>
    						<td>' . $filas['nombre'] . ' ' . $filas['apellido'] . '</td>
    						<td>' . $filas['identificacion'] . '</td>
    						<td>' . $filas['tipoID'] . '</td>
    						<td>' . $filas['edad'] . '</td>
    						<td>' . $filas['sexo'] . '</td>
    						<td>' . $filas['celular'] . '</td>
    						<td>' . $filas['direccion'] . '</td>
    						<td>' . $filas['telef2'] . '</td>
    					</tr>
    				';
    				$contador++;
    			}
    			$pag_final = $contador - 1;
    		} else {
    			if ($total >= 1) {
    				$tabla .= '
    					<tr class="has-text-centered">
    						<td colspan="9">
    							<a href="' . $url . '1/" class="button is-link is-rounded is-small mt-4 mb-4">
    								Haga clic acá para recargar el listado
    							</a>
    						</td>
    					</tr>
    				';
    			} else {
    				$tabla .= '
    					<tr class="has-text-centered">
    						<td colspan="9">
    							No hay registros en el sistema
    						</td>
    					</tr>
    				';
    			}
    		}
        
    		$tabla .= '</tbody></table></div>';
        
    		### Paginación ###
    		if ($total > 0 && $pagina <= $numeroPaginas) {
    			$tabla .= '<p class="has-text-right">Mostrando usuarios <strong>' . $pag_inicio . '</strong> al <strong>' . $pag_final . '</strong> de un <strong>total de ' . $total . '</strong></p>';
    			$tabla .= $this->paginadorTablas($pagina, $numeroPaginas, $url, 7);
    		}
        
    		return $tabla;
    	}

    }