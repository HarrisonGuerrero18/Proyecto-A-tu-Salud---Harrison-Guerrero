<?php 
namespace app\controllers;
use app\models\modelCrud;

class controllerDisponibilidad extends modelCrud{

    public function registrarDisponibilidadEspecialista($especialistaCodigo, $especialidadCodigo_fk, $conexion) {
        $especialistaCodigo_fk = $especialistaCodigo;
        $especialidad = $this->obtenerDetallesEspecialidad($especialidadCodigo_fk, $conexion);
    
        if (!$especialidad) { 
            $alerta = [ 
                "tipo" => "simple", 
                "titulo" => "Error en la disponibilidad", 
                "texto" => "No se pudo obtener la información de la especialidad", 
                "icono" => "error" 
            ]; 
            return json_encode($alerta); 
        } 
        
        $diaSemana = $especialidad['diaSemana']; 
        
        $duracion = $especialidad['duracion']; 
        
        list($horas, $minutos, $segundos) = explode(':', $duracion);
        
        $duracionEnMinutos = ($horas * 60) + $minutos + ($segundos / 60); 
        
        $duracionTotalMinutos = $duracionEnMinutos * 10; 
        
        $horaInicio = '07:00:00';
        
        $horaFin = date('H:i:s', strtotime($horaInicio) + ($duracionTotalMinutos * 60));
        
        $disponibilidad_datos = [
            [
                "campo_nombre" => "especialistaCodigo_fk",
                "campo_marcador" => ":EspecialistaID_fk",
                "campo_valor" => $especialistaCodigo_fk
            ],
            [
                "campo_nombre" => "diaSemana",
                "campo_marcador" => ":DiaSemana",
                "campo_valor" => $diaSemana
            ],
            [
                "campo_nombre" => "horaInicio",
                "campo_marcador" => ":HoraInicio",
                "campo_valor" => $horaInicio
            ],
            [
                "campo_nombre" => "horaFin",
                "campo_marcador" => ":HoraFin",
                "campo_valor" => $horaFin
            ]
        ];
    
        $guardar_disponibilidad = $this->guardarDatos("disponibilidadEspecialista", $disponibilidad_datos, $conexion);
    
        if ($guardar_disponibilidad->rowCount() != 1) {
            $alerta = [
                "tipo" => "simple",
                "titulo" => "Ocurrió un error inesperado",
                "texto" => "No se pudo registrar la disponibilidad, por favor intente nuevamente",
                "icono" => "error"
            ];
            return json_encode($alerta);
        }
    }
}