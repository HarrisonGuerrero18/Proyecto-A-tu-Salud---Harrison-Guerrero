<?php 
namespace app\controllers;
use app\models\modelCrud;

class controllerCita extends modelCrud{

    public function obtenerEspecialistasDias() {
        $especialidadCodigo = $this->limpiarCadena($_POST['especialidadCodigo']);
        if (!$especialidadCodigo) {
            return json_encode([
                'success' => false,
                'message' => 'Especialidad no proporcionada.'
            ]);
        }
    
        $especialistas = $this->obtenerEspecialistasPorEspecialidad($especialidadCodigo);
    
        $diasDisponibles = $this->obtenerDiasPorEspecialidad($especialidadCodigo);
    
        if ($especialistas && $diasDisponibles) {
            return json_encode([
                'success' => true,
                'especialistas' => $especialistas,
                'diasDisponibles' => $diasDisponibles
            ]);
        } else {
            return json_encode([
                'success' => false,
                'message' => 'No se encontraron especialistas o días disponibles para esta especialidad.'
            ]);
        }
        exit();
    }

    public function obtenerDisponibilidadHoras() {
        $especialistaCodigo_fk = $this->limpiarCadena($_POST['especialistaCodigo']);
        if (!$especialistaCodigo_fk) {
            return json_encode(['success' => false, 'message' => 'Código de especialista no válido']);
        }

        $disponibilidad = $this->seleccionarDatos("Unico", "disponibilidadEspecialista", "especialistaCodigo_fk", $especialistaCodigo_fk)->fetch();
		if (!$disponibilidad) {
            return json_encode(['success' => false, 'message' => 'No se encontró disponibilidad para el especialista.']);
        }else{
            return json_encode(['success' => true, 'horaInicio' => $disponibilidad['horaInicio'], 'horaFin' => $disponibilidad['horaFin']]);
        }        
    }

    public function agendarCita() {
        $especialistaCodigo_fk = $this->limpiarCadena($_POST['especialistaCodigo']);
        $especialidadCodigo_fk = $this->limpiarCadena($_POST['especialidadCodigo']);
        $horaInicio = $this->limpiarCadena($_POST['hora']);
        $fecha = $this->limpiarCadena($_POST['fecha']);
    
        $especialidad = $this->seleccionarDatos('Unico', 'Especialidad', 'especialidadCodigo', $especialidadCodigo_fk)->fetch();
        if (!$especialidad) {
            $alerta = [
                "tipo" => "error",
                "titulo" => "Error",
                "texto" => "No se encontró la especialidad seleccionada",
                "icono" => "error"
            ];
            return json_encode($alerta);
        }

        list($horas, $minutos, $segundos) = explode(':', $especialidad['duracion']);
        $duracionEnMinutos = ($horas * 60) + $minutos + ($segundos / 60);
    
        $horaFin = date('H:i:s', strtotime($horaInicio . " + {$duracionEnMinutos} minutes"));
    
        $consulta_cita = $this->ejecutarConsulta("SELECT * FROM Cita WHERE especialistaCodigo_fk = '$especialistaCodigo_fk' AND fecha = '$fecha' AND (('$horaInicio' BETWEEN horaInicio AND horaFin) OR ('$horaFin' BETWEEN horaInicio AND horaFin) OR (horaInicio BETWEEN '$horaInicio' AND '$horaFin') OR (horaFin BETWEEN '$horaInicio' AND '$horaFin'))");
        
        if ($consulta_cita->rowCount() > 0) {
            $citaExistente = $consulta_cita->fetch();
            $horaFinCitaExistente = $citaExistente['horaFin'];
        
            $alerta = [
                "tipo" => "error",
                "titulo" => "Conflicto de Horario",
                "texto" => "Ya existe una cita registrada en ese horario. La próxima cita terminará a las " . $horaFinCitaExistente,
                "icono" => "error"
            ];
            return json_encode($alerta);
        }
        
        $conexion = $this->conectar();
    
        $guardar_cita = [
            [
                "campo_nombre" => "fecha",
                "campo_marcador" => ":Fecha",
                "campo_valor" => $fecha
            ],
            [
                "campo_nombre" => "horaInicio",
                "campo_marcador" => ":HoraInicio",
                "campo_valor" => $horaInicio
            ],
            [
                "campo_nombre" => "horaFin",
                "campo_marcador" => ":HoraFin",
                "campo_valor" => $horaFin
            ],
            [
                "campo_nombre" => "estado",
                "campo_marcador" => ":Estado",
                "campo_valor" => "Agendada"
            ],
            [
                "campo_nombre" => "especialidadCodigo_fk",
                "campo_marcador" => ":EspecialidadCodigo_fk",
                "campo_valor" => $especialidadCodigo_fk
            ],
            [
                "campo_nombre" => "especialistaCodigo_fk",
                "campo_marcador" => ":EspecialistaCodigo_fk",
                "campo_valor" => $especialistaCodigo_fk
            ],
            [
                "campo_nombre" => "pacienteCodigo_fk",
                "campo_marcador" => ":PacienteCodigo_fk",
                "campo_valor" => $_SESSION['pacienteCodigo']  
            ]
        ];
    
        try {
            $resultado = $this->guardarDatos("Cita", $guardar_cita, $conexion);
    
            if ($resultado->rowCount()==1) {
                $alerta = [
                    "tipo" => "simple",  
                    "titulo" => "Cita agendada",
                    "texto" => "Tu cita ha sido agendada con éxito",
                    "icono" => "success"
                ];
                return json_encode($alerta);
            } else {
                $alerta = [
                    "tipo" => "error",
                    "titulo" => "Ocurrió un error inesperado",
                    "texto" => "No se pudo agendar la cita, intente nuevamente",
                    "icono" => "error"
                ];
                return json_encode($alerta);
            }
        } catch (Exception $e) {
            $alerta = [
                "tipo" => "error",
                "titulo" => "Error",
                "texto" => "Ocurrió un error inesperado: " . $e->getMessage(),
                "icono" => "error"
            ];
            return json_encode($alerta);
        }
    }   
}