<?php 
namespace app\controllers;
use app\models\modelCrud;
use app\controllers\controllerAdministrador; 

class controllerUsuario extends modelCrud {

	public function verEspecialistasPorEspecialidad() {
        $consulta = "SELECT e.especialidadNombre, p.nombre, p.apellido, p.edad, p.sexo, u.usua_usuario, u.usuario_foto
            FROM Especialista esp
            JOIN Especialidad e ON esp.especialidadCodigo_fk = e.especialidadCodigo
            JOIN Usuario u ON esp.usua_codigo_fk = u.usua_codigo
            JOIN Persona p ON esp.personaCodigo_fk = p.personaCodigo
            ORDER BY e.especialidadNombre, p.nombre, p.apellido";
        $especialistas = $this->ejecutarConsulta($consulta); 
        return $especialistas;
    }

    public function recuperarContrasena() {
        if (isset($_POST['nueva_contrasena'])) {
            $this->procesarNuevaContrasena();
        } else {
            $usuario_correo = $this->limpiarCadena($_POST['usuarioCorreo_recuperar']);
            $id = $this->limpiarCadena($_POST['identificacion_recuperar']);
            $tipoID = $this->limpiarCadena($_POST['tipoID_recuperar']);
            $rol = $this->limpiarCadena($_POST['rol_recuperar']);
            
            if ($usuario_correo == "" || $id == "" || $tipoID == "" || $rol == "") {
                $alerta = [
                    "tipo" => "simple",
                    "titulo" => "Ocurrió un error inesperado",
                    "texto" => "No has llenado todos los campos que son obligatorios",
                    "icono" => "error"
                ];
                return json_encode($alerta);
            }
            
            if ($this->verificarDatos("[a-zA-Z0-9\s@.]{8,35}", $usuario_correo)) {
                $alerta = [
                    "tipo" => "simple",  
                    "titulo" => "Ocurrió un error inesperado",
                    "texto" => "El NOMBRE DE USUARIO o CORREO no coincide con el formato solicitado",
                    "icono" => "error"
                ];
                return json_encode($alerta);
            }
        
            if ($this->verificarDatos("[0-9]{8,13}", $id)) {
                $alerta = [
                    "tipo" => "simple",  
                    "titulo" => "Ocurrió un error inesperado",
                    "texto" => "El NÚMERO DE IDENTIFICACIÓN no coincide con el formato solicitado",
                    "icono" => "error"
                ];
                return json_encode($alerta);
            }

            if ($tipoID != "TI" && $tipoID != "CC") {
                $alerta = [
                    "tipo" => "simple",  
                    "titulo" => "Ocurrió un error inesperado",
                    "texto" => "El TIPO DE IDENTIFICACIÓN no es válido",
                    "icono" => "error"
                ];
                return json_encode($alerta);
            }
        
            $consulta_usuarioPersona = $this->ejecutarConsulta(
                "SELECT * FROM usuario 
                INNER JOIN Persona p ON usua_codigo = p.usua_codigo_fk 
                WHERE (usua_usuario = '$usuario_correo' OR correo = '$usuario_correo') 
                AND p.identificacion = '$id' AND p.tipoID = '$tipoID' AND rol = '$rol'"
            );
        
            if ($consulta_usuarioPersona->rowCount() != 1) {    
                $alerta = [
                    "tipo" => "simple",  
                    "titulo" => "Ocurrió un error inesperado",
                    "texto" => "Los datos proporcionados no coinciden con ningún Usuario registrado",
                    "icono" => "error"
                ];
                return json_encode($alerta);
            } else {
                $usuario = $consulta_usuarioPersona->fetch();
                $usua_codigo = $usuario['usua_codigo']; 
                
                $alerta = [
                    "tipo" => "formulario", 
                    "usua_codigo" => $usua_codigo 
                ];
                return json_encode($alerta);
            }
        }        
    }
        
    public function procesarNuevaContrasena() {

        $clave1 = $this->limpiarCadena($_POST['nueva_contrasena']);
        $usua_codigo = $this->limpiarCadena($_POST['usua_codigo']); 
    
        if ($this->verificarDatos("[a-zA-Z0-9$@.-]{3,100}", $clave1)) {
            $alerta = [
                "tipo" => "simple",  
                "titulo" => "Ocurrió un error inesperado",
                "texto" => "Las CLAVES no coinciden con el formato solicitado",
                "icono" => "error"
            ];
            return json_encode($alerta);
        }
    
        $clave = password_hash($clave1, PASSWORD_BCRYPT, ["cost" => 10]);
    
        $contrasena_usuario_datos_up = [
            [
                "campo_nombre" => "usua_clave",
                "campo_marcador" => ":Clave",
                "campo_valor" => $clave
            ],
            [
                "campo_nombre" => "usuario_actualizado",
                "campo_marcador" => ":Actualizado",
                "campo_valor" => date("Y-m-d H:i:s")
            ]
        ];
    
        $condicionUsuario = [
            "condicion_campo" => "usua_codigo",
            "condicion_marcador" => ":UsuarioID",
            "condicion_valor" => $usua_codigo 
        ];
    
        if (!$this->actualizarDatos("Usuario", $contrasena_usuario_datos_up, $condicionUsuario)) {
            $alerta = [
                "tipo" => "simple",  
                "titulo" => "Ocurrió un error inesperado",
                "texto" => "La contraseña no se pudo actualizar, por favor intente nuevamente",
                "icono" => "error"
            ];
            return json_encode($alerta);
        }
    
        $alerta = [
            "tipo" => "simple",  
            "titulo" => "Contraseña actualizada exitosamente",
            "texto" => "La Contraseña se ha actualizado exitosamente, puedes iniciar sesión",
            "icono" => "success"
        ];
        echo json_encode($alerta);
    }

	public function registrarUsuarioPersona(){

		$usuario = $this->limpiarCadena($_POST['usua_usuario']);
		$correo = $this->limpiarCadena($_POST['correo']);
		$clave1 = $this->limpiarCadena($_POST['usua_clave1']);	
		$clave2 = $this->limpiarCadena($_POST['usua_clave2']);
		$nombre = $this->limpiarCadena($_POST['nombre']);
		$apellido = $this->limpiarCadena($_POST['apellido']);
		$id = $this->limpiarCadena($_POST['identificacion']);
		$edad = $this->limpiarCadena($_POST['edad']);
		$celular = $this->limpiarCadena($_POST['celular']);
		$telef2 = $this->limpiarCadena($_POST['telef2']);
		$direccion = $this->limpiarCadena($_POST['direccion']);
		$tipoID = $this->limpiarCadena($_POST['tipoID']);
		$sexo = $this->limpiarCadena($_POST['sexo']);
			
        if ($usuario == "" || $correo == "" || $clave1 == "" || $clave2 == "" ) {
            $alerta=[
                "tipo"=>"simple",
                "titulo"=>"Ocurrió un error inesperado",
                "texto"=>"No has llenado todos los campos que son obligatorios para el Usuario",
                "icono"=>"error"
            ];
            return json_encode($alerta);
        }

		if ($this->verificarDatos("[a-zA-Z0-9\s ]{8,35}", $usuario)) {
            $alerta=[
                "tipo"=>"simple",
                "titulo"=>"Ocurrió un error inesperado",
                "texto"=>"El NOMBRE DE USUARIO no coincide con el formato solicitado",
                "icono"=>"error"
            ];
            return json_encode($alerta);
        }

		$consulta_usuario = $this->ejecutarConsulta("SELECT usua_usuario FROM usuario WHERE usua_usuario='$usuario'");
        if ($consulta_usuario->rowCount() > 0) {
            $alerta=[
                "tipo"=>"simple",
                "titulo"=>"Ocurrió un error inesperado",
                "texto"=>"El NOMBRE DE USUARIO ingresado ya se encuentra registrado, por favor elija otro",
                "icono"=>"error"
            ];
            return json_encode($alerta);        
        }

		if($correo!=""){
            if(filter_var($correo, FILTER_VALIDATE_EMAIL)){
                $consulta_correo=$this->ejecutarConsulta("SELECT correo FROM usuario WHERE correo ='$correo'");
                if($consulta_correo->rowCount()>0){
                    $alerta=[
                        "tipo"=>"simple",
                        "titulo"=>"Ocurrió un error inesperado",
                        "texto"=>"El CORREO que acaba de ingresar ya se encuentra registrado en el sistema, por favor verifique e intente nuevamente",
                        "icono"=>"error"
                    ];
                    return json_encode($alerta);
                }
            }else{
                $alerta=[
                    "tipo"=>"simple",
                    "titulo"=>"Ocurrió un error inesperado",
                    "texto"=>"Ha ingresado un correo electrónico no valido",
                    "icono"=>"error"
                ];
                return json_encode($alerta);           
            }
        }
		
        if ($this->verificarDatos("[a-zA-Z0-9$@.-]{3,100}", $clave1) || $this->verificarDatos("[a-zA-Z0-9$@.-]{3,100}", $clave2)) {
            $alerta=[
                "tipo"=>"simple",
                "titulo"=>"Ocurrió un error inesperado",
                "texto"=>"Las CLAVES no coinciden con el formato solicitado",
                "icono"=>"error"
            ];
            return json_encode($alerta);
        }

        if ($clave1 != $clave2) {
            $alerta=[
                "tipo"=>"simple",
                "titulo"=>"Ocurrió un error inesperado",
                "texto"=>"Las contraseñas que acaba de ingresar no coinciden, por favor verifique e intente nuevamente",
                "icono"=>"error"
            ];
            return json_encode($alerta);
            
        } else {
            $clave = password_hash($clave1, PASSWORD_BCRYPT, ["cost" => 10]);
        }

        // Directorio de imágenes
        $img_dir = "../views/fotos/";

        // Comprobar si se selecciona una imagen
        if($_FILES['usuario_foto']['name']!="" && $_FILES['usuario_foto']['size']>0){

            # Creando directorio #
            if(!file_exists($img_dir)){
                if(!mkdir($img_dir,0777)){
                    $alerta=[
                        "tipo"=>"simple",
                        "titulo"=>"Ocurrió un error inesperado",
                        "texto"=>"Error al crear el directorio",
                        "icono"=>"error"
                    ];
                    return json_encode($alerta);
                } 
            }

            # Verificando formato de imagenes #
            if(mime_content_type($_FILES['usuario_foto']['tmp_name'])!="image/jpeg" && mime_content_type($_FILES['usuario_foto']['tmp_name'])!="image/png"){
                $alerta=[
                    "tipo"=>"simple",
                    "titulo"=>"Ocurrió un error inesperado",
                    "texto"=>"La imagen que ha seleccionado es de un formato no permitido",
                    "icono"=>"error"
                ];
                return json_encode($alerta);
            }

            # Verificando peso de imagen #
            if(($_FILES['usuario_foto']['size']/1024)>5120){
                $alerta=[
                    "tipo"=>"simple",
                    "titulo"=>"Ocurrió un error inesperado",
                    "texto"=>"La imagen que ha seleccionado supera el peso permitido",
                    "icono"=>"error"
                ];
                return json_encode($alerta);
                
            }

            # Nombre de la foto #
            $foto=str_ireplace(" ","_",$usuario);
            $foto=$foto."_".rand(0,100);

            # Extension de la imagen #
            switch(mime_content_type($_FILES['usuario_foto']['tmp_name'])){
                case 'image/jpeg':
                    $foto=$foto.".jpg";
                break;
                case 'image/png':
                    $foto=$foto.".png";
                break;
            }

            chmod($img_dir,0777);

            # Moviendo imagen al directorio #
            if(!move_uploaded_file($_FILES['usuario_foto']['tmp_name'],$img_dir.$foto)){
                $alerta=[
                    "tipo"=>"simple",
                    "titulo"=>"Ocurrió un error inesperado",
                    "texto"=>"No podemos subir la imagen al sistema en este momento",
                    "icono"=>"error"
                ];
                return json_encode($alerta);
            }

        }else{
            $foto="";
        }

		if ($nombre == "" || $apellido == "" || $id == "" || $edad == "" || $celular == "" || $tipoID == "" || $sexo == "") {
			$alerta=[
                "tipo"=>"simple",
                "titulo"=>"Ocurrió un error inesperado",
                "texto"=>"No has llenado todos los campos que son obligatorios en 'Campos Adicionales'",
                "icono"=>"error"
            ];
            return json_encode($alerta);
        }

		if ($this->verificarDatos("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]{3,40}", $nombre) || $this->verificarDatos("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]{3,40}", $apellido) ) {
            $alerta=[
                "tipo"=>"simple",
                "titulo"=>"Ocurrió un error inesperado",
                "texto"=>"Los NOMBRES ó APELLIDOS no coincide con el formato solicitado",
                "icono"=>"error"
            ];
            return json_encode($alerta);
        }

		if ($this->verificarDatos("[0-9]{8,10}", $id)) {
            $alerta=[
                "tipo"=>"simple",
                "titulo"=>"Ocurrió un error inesperado",
                "texto"=>"El NÚMERO DE IDENTIFICACIÓN no coincide con el formato solicitado",
                "icono"=>"error"
            ];
            return json_encode($alerta);
        }

		$consulta_personaID = $this->ejecutarConsulta("SELECT identificacion FROM persona WHERE identificacion='$id'");
        if ($consulta_personaID->rowCount() > 0) {
            $alerta=[
                "tipo"=>"simple",
                "titulo"=>"Ocurrió un error inesperado",
                "texto"=>"El NÚMERO DE IDENTIFICACIÓN ingresado ya se encuentra registrado, en caso de tener una cuenta asociada a esta persona seleccione la Opción '¿Olvidaste tu Contraseña?' que está en el Inicio de Sesión",
                "icono"=>"error"
            ];
            return json_encode($alerta);
        }

        if ($this->verificarDatos("[0-9]{1,2}", $edad)) {
            $alerta=[
                "tipo"=>"simple",
                "titulo"=>"Ocurrió un error inesperado",
                "texto"=>"La EDAD no coincide con el formato solicitado",
                "icono"=>"error"
            ];
            return json_encode($alerta);
	
        }

        if ($this->verificarDatos("[0-9]{10}", $celular)) {
            $alerta=[
                "tipo"=>"simple",
                "titulo"=>"Ocurrió un error inesperado",
                "texto"=>"El CELULAR no coincide con el formato solicitado",
                "icono"=>"error"
            ];
            return json_encode($alerta);
        }

		$consulta_personaCelular = $this->ejecutarConsulta("SELECT celular FROM persona WHERE celular = '$celular'");
        if ($consulta_personaCelular->rowCount() > 0) {
            $alerta=[
                "tipo"=>"simple",
                "titulo"=>"Ocurrió un error inesperado",
                "texto"=>"El NÚMERO CELULAR ingresado ya se encuentra registrado, en caso de tener una cuenta asociada a esta número seleccione la Opción '¿Olvidaste tu Contraseña?' que está en el Inicio de Sesión o elija otro número",
                "icono"=>"error"
            ];
            return json_encode($alerta);
        }

		if (!empty($telef2)) {
			if ($this->verificarDatos("[0-9]{10}", $telef2)) {
				$alerta = [
					"tipo" => "simple",
					"titulo" => "Ocurrió un error inesperado",
					"texto" => "El NÚMERO DE TELÉFONO 2 no coincide con el formato solicitado",
					"icono" => "error"
				];
				return json_encode($alerta);
			}
		
			$consulta_persona_Telef2 = $this->ejecutarConsulta("SELECT telef2 FROM persona WHERE telef2='$telef2'");
			if ($consulta_persona_Telef2->rowCount() > 0) {
				$alerta = [
					"tipo" => "simple",
					"titulo" => "Ocurrió un error inesperado",
					"texto" => "El NÚMERO DE TELÉFONO 2 ingresado ya se encuentra registrado. Si ya tiene una cuenta, seleccione la opción 'Recuperar Cuenta' en el inicio de sesión o elija otro número",
					"icono" => "error"
				];
				return json_encode($alerta);
			}
		}
	
		if (!empty($direccion)){
			if($this->verificarDatos("^[a-zA-Z0-9\s#\\-]{10,100}$", $direccion)){
				$alerta = [
					"tipo" => "simple",
					"titulo" => "Ocurrió un error inesperado",
					"texto" => "La DIRECCIÓN no coincide con el formato solicitado",
					"icono" => "error"
				];
				return json_encode($alerta);
			}
		}  
		
		if (($edad < 18 && $tipoID == "CC") || ($edad >= 18 && $tipoID == "TI")) {
			$alerta = [
				"tipo" => "simple",
				"titulo" => "Ocurrió un error inesperado",
				"texto" => $edad < 18 
					? "Al ser menor de edad debe seleccionar 'Tarjeta de Identidad', no 'Cédula de Ciudadanía'" 
					: "Al ser mayor de edad debe seleccionar 'Cédula de Ciudadanía', no 'Tarjeta de Identidad'",
				"icono" => "error"
			];
			return json_encode($alerta);
		}

		$conexion = $this->conectar();
		$conexion->beginTransaction();
		
		try {
			$usuario_datos_reg = [
				[
				    "campo_nombre" => "usua_usuario",
				    "campo_marcador" => ":Usua_usuario",
				    "campo_valor" => $usuario
				],
				[
				    "campo_nombre" => "correo",
				    "campo_marcador" => ":Correo",
				    "campo_valor" => $correo
				],
				[
				    "campo_nombre" => "usua_clave",
				    "campo_marcador" => ":Usua_clave",
				    "campo_valor" => $clave
				],
				[
				    "campo_nombre" => "rol",
				    "campo_marcador" => ":Rol",
				    "campo_valor" => "Paciente"
				],
				[
				    "campo_nombre" => "usuario_foto",
				    "campo_marcador" => ":Foto",
				    "campo_valor" => $foto
				],
				[
				    "campo_nombre" => "usuario_creado",
				    "campo_marcador" => ":Creado",
				    "campo_valor" => date("Y-m-d H:i:s")
				],
				[
				    "campo_nombre" => "usuario_actualizado",
				    "campo_marcador" => ":Actualizado",
				    "campo_valor" => date("Y-m-d H:i:s")
				]
			];

			$guardar_usuario = $this->guardarDatos("Usuario", $usuario_datos_reg, $conexion);

			if ($guardar_usuario->rowCount() != 1) {
				$alerta = [
        			"tipo" => "simple",
    			    "titulo" => "Error",
    			    "texto" => "No se pudo registrar el usuario ".$usuario." por favor intente nuevamente",
    			    "icono" => "error"
    			];
    			return json_encode($alerta);
			}

			$usua_codigo_fk = $conexion->lastInsertId();

			$persona_datos_reg = [
				[            
					"campo_nombre" => "usua_codigo_fk",
					"campo_marcador" => ":Usua_codigo_fk",
					"campo_valor" => $usua_codigo_fk
				],
				[
					"campo_nombre" => "identificacion",
					"campo_marcador" => ":idPersona",
					"campo_valor" => $id
				],
				[
					"campo_nombre" => "tipoID",
					"campo_marcador" => ":TipoID",
					"campo_valor" => $tipoID
				],
				[
					"campo_nombre" => "nombre",
					"campo_marcador" => ":Nombre",
					"campo_valor" => $nombre
				],
				[
					"campo_nombre" => "apellido",
					"campo_marcador" => ":Apellido",
					"campo_valor" => $apellido
				],
				[
					"campo_nombre" => "edad",
					"campo_marcador" => ":Edad",
					"campo_valor" => $edad
				], 
				[
					"campo_nombre" => "sexo",
					"campo_marcador" => ":Sexo",
					"campo_valor" => $sexo
				],
				[  
					"campo_nombre" => "celular",
					"campo_marcador" => ":Celular",
					"campo_valor" => $celular
				],
				[            
					"campo_nombre" => "direccion",
					"campo_marcador" => ":Direccion",
					"campo_valor" => $direccion
				],
				[            
					"campo_nombre" => "telef2",
					"campo_marcador" => ":Telef2",
					"campo_valor" => $telef2
				]
			];
	
			$guardar_persona = $this->guardarDatos("Persona", $persona_datos_reg, $conexion);

			if ($guardar_persona->rowCount() != 1) {
				$alerta = [
					"tipo" => "simple",
					"titulo" => "Ocurrió un error inesperado",
					"texto" => "No se pudo registrar la persona, por favor intente nuevamente, código:".$usua_codigo_fk,
					"icono" => "error"
				];
				return json_encode($alerta); 
			}

			$personaCodigo_fk = $conexion->lastInsertId();

			$objUsuario_Persona = new controllerAdministrador();
			$objUsuario_Persona->registrarPaciente($usua_codigo_fk, $personaCodigo_fk, $conexion); 
			
			$conexion->commit();
			$alerta = [
				"tipo" => "simple",
				"titulo" => "Registro exitoso",
				"texto" => "El Usuario " . $usuario . " se ha registrado exitosamente.",
				"icono" => "success"
			];
			return json_encode($alerta);
		
		} catch (\Exception $e) {
			$conexion->rollBack();
			$alerta = [
				"tipo" => "simple",
				"titulo" => "Error",
				"texto" => $e->getMessage(),
				"icono" => "error"
			];
			return json_encode($alerta);
		}
	}

	public function actualizarUsuarioPersona(){

		$usua_codigo = $this->limpiarCadena($_POST['usua_codigo']);

		$datos = $this->ejecutarConsulta("SELECT * FROM usuario u INNER JOIN persona pe ON u.usua_codigo = pe.usua_codigo_fk WHERE u.usua_codigo = '$usua_codigo'");
			if($datos->rowCount()<=0){
				$alerta=[
					"tipo"=>"simple",
					"titulo"=>"Ocurrió un error inesperado",
					"texto"=>"No hemos encontrado el usuario en el sistema",
					"icono"=>"error"
				];
				return json_encode($alerta);
			}else{
				$datos=$datos->fetch();
				$usuarioAnterior = $datos['usua_usuario']; 
				$idAnterior = $datos['identificacion']; 
				$celularAnterior = $datos['celular']; 
			}

			$usuario_correo=$this->limpiarCadena($_POST['usuario_correo']);
			$usuario_clave=$this->limpiarCadena($_POST['usuario_clave']);

			if($usuario_correo=="" || $usuario_clave==""){
				$alerta=[
					"tipo"=>"simple",
					"titulo"=>"Ocurrió un error inesperado",
					"texto"=>"No ha llenado todos los campos que son obligatorios, que corresponden a su 'USUARIO o CORREO' y 'CLAVE'",
					"icono"=>"error"
				];
				return json_encode($alerta);
			}

			if($this->verificarDatos("[a-zA-Z0-9\s@.]{8,35}",$usuario_correo)){
				$alerta=[
					"tipo"=>"simple",
					"titulo"=>"Ocurrió un error inesperado",
					"texto"=>"Su USUARIO o CORREO para confirmar la actualización no coincide con el formato solicitado",
					"icono"=>"error"
				];
				return json_encode($alerta);
			}

			if($this->verificarDatos("[a-zA-Z0-9$@.-]{3,100}",$usuario_clave)){
				$alerta=[
					"tipo"=>"simple",
					"titulo"=>"Ocurrió un error inesperado",
					"texto"=>"Su CLAVE para confirmar la actualización no coincide con el formato solicitado",
					"icono"=>"error"
				];
				return json_encode($alerta);
			}

			$consulta_usuario = $this->ejecutarConsulta("SELECT * 
    			FROM usuario u 
    			LEFT JOIN especialista e ON e.usua_codigo_fk = u.usua_codigo 
    			LEFT JOIN paciente p ON p.usua_codigo_fk = u.usua_codigo 
    			INNER JOIN persona pe ON pe.personaCodigo = COALESCE(e.personaCodigo_fk, p.personaCodigo_fk)
    			WHERE (u.usua_usuario = '$usuario_correo' OR u.correo = '$usuario_correo') 
    			AND (e.usua_codigo_fk IS NOT NULL OR p.usua_codigo_fk IS NOT NULL)");
	
			if($consulta_usuario->rowCount() == 1){
				$consulta_usuario = $consulta_usuario->fetch();
			
				if ((!($consulta_usuario['usua_usuario'] == $usuario_correo || $consulta_usuario['correo'] == $usuario_correo)) || 
					!password_verify($usuario_clave, $consulta_usuario['usua_clave'])) {
					$alerta = [
						"tipo" => "simple",
						"titulo" => "Ocurrió un error inesperado",
						"texto" => "'USUARIO o CORREO' o 'CLAVE' son incorrectos",
						"icono" => "error"
					];
					return json_encode($alerta);
				}
			} else {
				$alerta = [
					"tipo" => "simple",
					"titulo" => "Ocurrió un error inesperado",
					"texto" => "'USUARIO o CORREO' o 'CLAVE' son incorrectos",
					"icono" => "error"
				];
				return json_encode($alerta);
			}
	
			$nombreActual = $this->limpiarCadena($_POST['nombre']);
			$apellidoActual = $this->limpiarCadena($_POST['apellido']);
			$usuarioActual = $this->limpiarCadena($_POST['usua_usuario']);
			$correoActual = $this->limpiarCadena($_POST['correo']);
			$idActual = $this->limpiarCadena($_POST['identificacion']);
			$tipoIDActual = $this->limpiarCadena($_POST['tipoID']);
			$edadActual = $this->limpiarCadena($_POST['edad']);
			$celularActual = $this->limpiarCadena($_POST['celular']);
			$direccionActual = $this->limpiarCadena($_POST['direccion']);
			$telef2Actual = $this->limpiarCadena($_POST['telef2']);
			$clave1 = $this->limpiarCadena($_POST['usuario_clave_1']);
			$clave2 = $this->limpiarCadena($_POST['usuario_clave_2']);

			if($nombreActual=="" || $apellidoActual=="" || $usuarioActual=="" || $correoActual=="" || $idActual=="" || $tipoIDActual=="" || $edadActual=="" || $celularActual==""){
				$alerta=[
					"tipo"=>"simple",
					"titulo"=>"Ocurrió un error inesperado",
					"texto"=>"No has llenado todos los campos que son obligatorios",
					"icono"=>"error"
				];
				return json_encode($alerta);
			}

			if ($this->verificarDatos("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]{3,40}", $nombreActual) || $this->verificarDatos("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]{3,40}", $apellidoActual) ) {
				$alerta=[
					"tipo"=>"simple",
					"titulo"=>"Ocurrió un error inesperado",
					"texto"=>"Los NOMBRES o APELLIDOS no coinciden con el formato solicitado",
					"icono"=>"error"
				];
				return json_encode($alerta);
			}

			if ($correoActual != "" && $correoActual != $datos['correo']) {
				if(filter_var($correoActual, FILTER_VALIDATE_EMAIL)){
					$check_correo=$this->ejecutarConsulta("SELECT correo FROM usuario WHERE correo='$correoActual'");
					if($check_correo->rowCount()>0){
						$alerta=[
							"tipo"=>"simple",
							"titulo"=>"Ocurrió un error inesperado",
							"texto"=>"El CORREO que acaba de ingresar ya se encuentra registrado en el sistema, por favor verifique e intente nuevamente",
							"icono"=>"error"
						];
						return json_encode($alerta);
					}
				}else{
					$alerta=[
						"tipo"=>"simple",
						"titulo"=>"Ocurrió un error inesperado",
						"texto"=>"Ha ingresado un correo electrónico no valido",
						"icono"=>"error"
					];
					return json_encode($alerta);
				}
			}

			if ($this->verificarDatos("[a-zA-Z0-9\s ]{8,35}", $usuarioActual)) {
				$alerta=[
					"tipo"=>"simple",
					"titulo"=>"Ocurrió un error inesperado",
					"texto"=>"El NOMBRE DE USUARIO no coincide con el formato solicitado",
					"icono"=>"error"
				];
				return json_encode($alerta);
			}

			if($usuarioAnterior != $usuarioActual){
				$consulta_usuario = $this->ejecutarConsulta("SELECT usua_usuario FROM usuario WHERE usua_usuario='$usuarioActual'");
				if($consulta_usuario->rowCount()>0){
					$alerta=[
						"tipo"=>"simple",
						"titulo"=>"Ocurrió un error inesperado",
						"texto"=>"El USUARIO ingresado ya se encuentra registrado, por favor elija otro",
						"icono"=>"error"
					];
					return json_encode($alerta);
					
				}
			}

			if ($this->verificarDatos("[0-9]{8,13}", $idActual)) {
				$alerta=[
					"tipo"=>"simple",
					"titulo"=>"Ocurrió un error inesperado",
					"texto"=>"El NÚMERO DE IDENTIFICACIÓN no coincide con el formato solicitado",
					"icono"=>"error"
				];
				return json_encode($alerta);
			}

			if ($idAnterior !== $idActual) {
				$consulta_personaID = $this->ejecutarConsulta("SELECT identificacion FROM persona WHERE identificacion = '$idActual'");
				if ($consulta_personaID->rowCount() > 0) {
					$alerta = [
						"tipo" => "simple",
						"titulo" => "Ocurrió un error inesperado",
						"texto" => "El NÚMERO DE IDENTIFICACIÓN ingresado ya se encuentra registrado, verifique que el Usuario le haya proporcionado el Número de Identificación correcto o cancele la Actualización",
						"icono" => "error"
					];
					return json_encode($alerta);
				}
			}

			if ($this->verificarDatos("[0-9]{1,2}", $edadActual)) {
				$alerta = [
					"tipo" => "simple",
					"titulo" => "Ocurrió un error inesperado",
					"texto" => "La EDAD no coincide con el formato solicitado",
					"icono" => "error"
				];
				return json_encode($alerta);
			}

			if ($this->verificarDatos("[0-9]{10,15}", $celularActual)) {
				$alerta=[
					"tipo"=>"simple",
					"titulo"=>"Ocurrió un error inesperado",
					"texto"=>"El CELULAR no coincide con el formato solicitado",
					"icono"=>"error"
				];
				return json_encode($alerta);
			}

			if ($celularActual !== $celularAnterior) {
				$consulta_personaCelular = $this->ejecutarConsulta("SELECT celular FROM persona WHERE celular = '$celularActual'");
				if ($consulta_personaCelular->rowCount() > 0) {
					$alerta = [
						"tipo" => "simple",
						"titulo" => "Ocurrió un error inesperado",
						"texto" => "El NÚMERO CELULAR ingresado ya se encuentra registrado, verifique que el Usuario le haya proporcionado el Número de Celular correcto o cancele la Actualización",
						"icono" => "error"
					];
					return json_encode($alerta);
					
				}
			}

			if (!empty($telef2Actual)) {
				if ($this->verificarDatos("[0-9]{10}", $telef2Actual)) {
					$alerta = [
						"tipo" => "simple",
						"titulo" => "Ocurrió un error inesperado",
						"texto" => "El NÚMERO DE TELÉFONO 2 no coincide con el formato solicitado",
						"icono" => "error"
					];
					return json_encode($alerta);
				}
			
				$consulta_persona_Telef2 = $this->ejecutarConsulta("SELECT telef2 FROM persona WHERE telef2='$telef2Actual'");
				if ($consulta_persona_Telef2->rowCount() > 0) {
					$alerta = [
						"tipo" => "simple",
						"titulo" => "Ocurrió un error inesperado",
						"texto" =>  "El NÚMERO DE TELÉFONO 2 ingresado ya se encuentra registrado, verifique que el Usuario le haya proporcionado el Número de Teléfono 2 correcto o cancele la Actualización",
						"icono" => "error"
					];
					return json_encode($alerta);
				}
			}
			
			if (!empty($direccionActual)){
				if($this->verificarDatos("^[a-zA-Z0-9\s#\\-]{10,100}$", $direccionActual)){
					$alerta = [
						"tipo" => "simple",
						"titulo" => "Ocurrió un error inesperado",
						"texto" => "La DIRECCIÓN no coincide con el formato solicitado",
						"icono" => "error"
					];
					return json_encode($alerta);
				}
			}  

			if (($edadActual < 18 && $tipoIDActual == "CC") || ($edadActual >= 18 && $tipoIDActual == "TI")) {
				$alerta = [
					"tipo" => "simple",
					"titulo" => "Ocurrió un error inesperado",
					"texto" => $edadActual < 18 
						? "Al ser menor de edad debe seleccionar 'Tarjeta de Identidad', no 'Cédula de Ciudadanía'" 
						: "Al ser mayor de edad debe seleccionar 'Cédula de Ciudadanía', no 'Tarjeta de Identidad'",
					"icono" => "error"
				];
				return json_encode($alerta);
			}

			if($clave1!="" || $clave2!=""){
            	if($this->verificarDatos("[a-zA-Z0-9$@.-]{3,100}",$clave1) || $this->verificarDatos("[a-zA-Z0-9$@.-]{3,100}",$clave2)){
			        $alerta=[
						"tipo"=>"simple",
						"titulo"=>"Ocurrió un error inesperado",
						"texto"=>"Las CLAVES no coinciden con el aa solicitado",
						"icono"=>"error"
					];
					return json_encode($alerta);
			        
			    }else{
			    	if($clave1!=$clave2){
						$alerta=[
							"tipo"=>"simple",
							"titulo"=>"Ocurrió un error inesperado",
							"texto"=>"Las nuevas CLAVES que acaba de ingresar no coinciden, por favor verifique e intente nuevamente",
							"icono"=>"error"
						];
						return json_encode($alerta);
						
			    	}else{
			    		$clave=password_hash($clave1,PASSWORD_BCRYPT,["cost"=>10]);
			    	}
			    }
			}else{
				$clave=$datos['usua_clave'];
            }

			try {
				$usuario_datos_up = [
					[
						"campo_nombre" => "usua_usuario",
						"campo_marcador" => ":Usuario",
						"campo_valor" => $usuarioActual
					],
					[
						"campo_nombre" => "correo",
						"campo_marcador" => ":Correo",
						"campo_valor" => $correoActual
					],
					[
						"campo_nombre" => "usua_clave",
						"campo_marcador" => ":Clave",
						"campo_valor" => $clave
					],
					[
						"campo_nombre" => "usuario_actualizado",
						"campo_marcador" => ":Actualizado",
						"campo_valor" => date("Y-m-d H:i:s")
					]
				];
			
				$condicionUsuario = [
					"condicion_campo" => "usua_codigo",
					"condicion_marcador" => ":UsuarioID",
					"condicion_valor" => $usua_codigo
				];
			
			
				if (!$this->actualizarDatos("usuario", $usuario_datos_up, $condicionUsuario)) {
					throw new \Exception("No se pudieron actualizar los datos del usuario " . $datos['usua_usuario']);
				}

				$persona_datos_up = [
					[
						"campo_nombre" => "identificacion",
						"campo_marcador" => ":IDPersona",
						"campo_valor" => $idActual
					],
					[
						"campo_nombre" => "tipoID",
						"campo_marcador" => ":TipoID",
						"campo_valor" => $tipoIDActual
					],
					[
						"campo_nombre" => "nombre",
						"campo_marcador" => ":Nombre",
						"campo_valor" => $nombreActual
					],
					[
						"campo_nombre" => "apellido",
						"campo_marcador" => ":Apellido",
						"campo_valor" => $apellidoActual
					],
					[
						"campo_nombre" => "edad",
						"campo_marcador" => ":Edad",
						"campo_valor" => $edadActual
					],
					[
						"campo_nombre" => "celular",
						"campo_marcador" => ":Celular",
						"campo_valor" => $celularActual
					],
					[
						"campo_nombre" => "direccion",
						"campo_marcador" => ":Direccion",
						"campo_valor" => $direccionActual
					],
					[
						"campo_nombre" => "telef2",
						"campo_marcador" => ":Telefono2",
						"campo_valor" => $telef2Actual
					]
				];
			
				$condicionPersona = [
					"condicion_campo" => "usua_codigo_fk",
					"condicion_marcador" => ":UsuarioIDPersona", 
					"condicion_valor" => $usua_codigo
				];
			
				if (!$this->actualizarDatos("Persona", $persona_datos_up, $condicionPersona)) {
					throw new \Exception("No se pudieron actualizar los datos de la persona");
				}

        		if ($usua_codigo == $_SESSION['codigo']) {
        	    $_SESSION['usuario'] = $usuarioActual;
        	    $_SESSION['correo'] = $correoActual;
				$_SESSION['nombre'] = $nombreActual;
				$_SESSION['apellido'] = $apellidoActual;
			}

			$alerta = [
				"tipo" => "recargar",
				"titulo" => "Datos de Usuario y Persona actualizados",
				"texto" => "Los datos del Usuario " . $usuarioActual . " asociados a " . $nombreActual . " " . $apellidoActual . " se actualizaron correctamente",
				"icono" => "success"
			];
			return json_encode($alerta);
			
    		} catch (\Exception $e) {
    		    $alerta = [
    		        "tipo" => "simple",
    		        "titulo" => "Ocurrió un error inesperado",
    		        "texto" => $e->getMessage(),
    		        "icono" => "error"
    		    ];
    		    return json_encode($alerta);
    		}
	}

	public function eliminarUsuarioPersona(){

		$usua_codigo=$this->limpiarCadena($_POST['usua_codigo']);

		if($usua_codigo==1){
			$alerta=[
				"tipo"=>"simple",
				"titulo"=>"Ocurrió un error inesperado",
				"texto"=>"No podemos eliminar el usuario principal del sistema",
				"icono"=>"error"
			];
			return json_encode($alerta);
			exit();
		}

		$datos=$this->ejecutarConsulta("SELECT * FROM usuario u INNER JOIN persona pe ON u.usua_codigo = pe.usua_codigo_fk WHERE u.usua_codigo='$usua_codigo'");
		if($datos->rowCount()<=0){
			$alerta=[
				"tipo"=>"simple",
				"titulo"=>"Ocurrió un error inesperado",
				"texto"=>"No hemos encontrado el usuario en el sistema",
				"icono"=>"error"
			];
			return json_encode($alerta);
			exit();
		}else{
			$datos=$datos->fetch();
		}

		$eliminarUsuario=$this->eliminarRegistro("Usuario","usua_codigo",$usua_codigo);

		if($eliminarUsuario->rowCount()==1){

			if(is_file("../views/fotos/".$datos['usuario_foto'])){
				chmod("../views/fotos/".$datos['usuario_foto'],0777);
				unlink("../views/fotos/".$datos['usuario_foto']);
			}

			$alerta=[
				"tipo"=>"recargar",
				"titulo"=>"Usuario eliminado",
				"texto"=>$datos['nombre']." ".$datos['apellido'].", tu cuenta ha sido eliminada",
				"icono"=>"success"
			];

		}else{

			$alerta=[
				"tipo"=>"simple",
				"titulo"=>"Ocurrió un error inesperado",
				"texto"=>"No hemos podido eliminar el usuario ".$datos['usua_usuario']." del sistema, por favor intente nuevamente",
				"icono"=>"error"
			];
		}

		return json_encode($alerta);
	}
}