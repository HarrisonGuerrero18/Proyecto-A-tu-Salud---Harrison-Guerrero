<?php
namespace app\controllers;
use app\models\modelCrud;

class controllerEspecialidad extends modelCrud {

	public function registrarEspecialidad() {
		$nombre = $this->limpiarCadena($_POST['especialidadNombre']);
		$descripcion = $this->limpiarCadena($_POST['descripcion']);
		$duracion = $_POST['duracion']; 
		$costo = $this->limpiarCadena($_POST['costo']);
		$diaSemana = $this->limpiarCadena($_POST['diaSemana']);
	
		if ($nombre == "" || $descripcion == "" || $duracion == "" || $costo == "" || $diaSemana == "") {
			$alerta = [
				"tipo" => "simple",
				"titulo" => "Ocurrió un error inesperado",
				"texto" => "No has llenado todos los campos obligatorios para la Especialidad",
				"icono" => "error"
			];
			return json_encode($alerta);
		}
	
		if ($this->verificarDatos("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]{5,30}", $nombre)) {
			$alerta = [
				"tipo" => "simple",
				"titulo" => "Ocurrió un error inesperado",
				"texto" => "El NOMBRE DE LA ESPECIALIDAD no coincide con el formato solicitado",
				"icono" => "error"
			];
			return json_encode($alerta);
		}	
		
		$consulta_nombre = $this->ejecutarConsulta("SELECT especialidadNombre FROM especialidad WHERE especialidadNombre='$nombre'");
		if ($consulta_nombre->rowCount() > 0) {
			$alerta = [
				"tipo" => "simple",
				"titulo" => "Ocurrió un error inesperado",
				"texto" => "El NOMBRE DE LA ESPECIALIDAD ya está registrado",
				"icono" => "error"
			];
			return json_encode($alerta);
		}
	
		if (strlen($descripcion) > 255) {
			$alerta = [
				"tipo" => "simple",
				"titulo" => "Ocurrió un error inesperado",
				"texto" => "La DESCRIPCIÓN no debe exceder los 255 caracteres",
				"icono" => "error"
			];
			return json_encode($alerta);
		}

		$consulta_descripcion = $this->ejecutarConsulta("SELECT descripcion FROM especialidad WHERE descripcion='$descripcion'");
		if ($consulta_descripcion->rowCount() > 0) {
			$alerta=[
				"tipo"=>"simple",
				"titulo"=>"Ocurrió un error inesperado",
				"texto"=>"La DESCRIPCIÓN DE LA ESPECIALIDAD ingresada ya se encuentra registrada, verifique que la descripción sea la correcta",
				"icono"=>"error"
			];
			return json_encode($alerta);
		}
	
		if (!preg_match("/^([01][0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]$/", $duracion)) {
			$alerta = [
				"tipo" => "simple",
				"titulo" => "Ocurrió un error inesperado",
				"texto" => "La DURACIÓN no tiene el formato correcto (HH:MM:SS)",
				"icono" => "error"
			];
			return json_encode($alerta);
		}
				
		if ($costo <= 0) {
			$alerta = [
				"tipo" => "simple",
				"titulo" => "Ocurrió un error inesperado",
				"texto" => "El COSTO debe ser un valor mayor a 0",
				"icono" => "error"
			];
			return json_encode($alerta);
		}

		$diasValidos = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];

		$diasIngresados = array_map('trim', explode(',', $diaSemana));

		foreach ($diasIngresados as $dia) {
		    if (!in_array($dia, $diasValidos)) {
		        $alerta = [
		            "tipo" => "simple",
		            "titulo" => "Ocurrió un error inesperado",
		            "texto" => "Uno o más de los días ingresados no son válidos. Asegúrate de ingresar días reales.",
		            "icono" => "error"
		        ];
		        return json_encode($alerta);
		    }
		}	

		// Directorio de imágenes
		$img_dir = "../views/fotos/";
		// Comprobar si se selecciona una imagen
		if($_FILES['especialidad_foto']['name']!="" && $_FILES['especialidad_foto']['size']>0){
	
			# Creando directorio #
			if(!file_exists($img_dir)){
				if(!mkdir($img_dir,0777)){
					$alerta=[
					 "tipo"=>"simple",
					 "titulo"=>"Ocurrió un error inesperado",
					 "texto"=>"Error al crear el directorio",
					 "icono"=>"error"
					];
					return json_encode($alerta);
			 	} 
			}
	
			# Verificando formato de imagenes #
			if(mime_content_type($_FILES['especialidad_foto']['tmp_name'])!="image/jpeg" && mime_content_type($_FILES['especialidad_foto']['tmp_name'])!="image/png"){
				$alerta=[
					"tipo"=>"simple",
					"titulo"=>"Ocurrió un error inesperado",
					"texto"=>"La imagen que ha seleccionado es de un formato no permitido",
					"icono"=>"error"
				];
				return json_encode($alerta);
			}

			# Verificando peso de imagen #
			if(($_FILES['especialidad_foto']['size']/1024)>5120){
				$alerta=[
				 "tipo"=>"simple",
				 "titulo"=>"Ocurrió un error inesperado",
				 "texto"=>"La imagen que ha seleccionado supera el peso permitido",
				 "icono"=>"error"
				];
				return json_encode($alerta); 
			}

			# Nombre de la foto #
			$foto=str_ireplace(" ","_",$nombre);
			$foto=$foto."_".rand(0,100);

			# Extension de la imagen #
			switch(mime_content_type($_FILES['especialidad_foto']['tmp_name'])){
				case 'image/jpeg':
					$foto=$foto.".jpg";
			break;
				case 'image/png':
					$foto=$foto.".png";
			break;
			}

			chmod($img_dir,0777);

			# Moviendo imagen al directorio #
			if(!move_uploaded_file($_FILES['especialidad_foto']['tmp_name'],$img_dir.$foto)){
				$alerta=[
				 "tipo"=>"simple",
				 "titulo"=>"Ocurrió un error inesperado",
				 "texto"=>"No podemos subir la imagen al sistema en este momento",
				 "icono"=>"error"
				];
				return json_encode($alerta);
			}

		}else{
			$foto="";
		}	
	
		try {
			
			$conexion = $this->conectar();
	
			$especialidad_datos_reg = [
				[
					"campo_nombre" => "especialidadNombre",
					"campo_marcador" => ":Nombre",
					"campo_valor" => $nombre
				],
				[
					"campo_nombre" => "descripcion",
					"campo_marcador" => ":Descripcion",
					"campo_valor" => $descripcion
				],
				[
					"campo_nombre" => "duracion", 
					"campo_marcador" => ":Duracion",
					"campo_valor" => $duracion
				],
				[
					"campo_nombre" => "costo",
					"campo_marcador" => ":Costo",
					"campo_valor" => $costo
				],
				[
					"campo_nombre" => "diaSemana",
					"campo_marcador" => ":Dia",
					"campo_valor" => $diaSemana
				],
				[
					"campo_nombre" => "especialidad_foto",
					"campo_marcador" => ":Foto",
					"campo_valor" => $foto
				],
				[
					"campo_nombre" => "especialidad_creada",
					"campo_marcador" => ":Creada",
					"campo_valor" => date("Y-m-d H:i:s")
				],
				[
					"campo_nombre" => "especialidad_actualizada",
					"campo_marcador" => ":Actualizada",
					"campo_valor" => date("Y-m-d H:i:s")
				]
			];
				
			$guardar_especialidad = $this->guardarDatos("Especialidad", $especialidad_datos_reg, $conexion);

			if ($guardar_especialidad->rowCount() == 1) {
				$alerta = [
					"tipo" => "simple",
					"titulo" => "Registro extoso",
					"texto" => "La Especialidad '".$nombre."' se ha registrado exitosamente",
					"icono" => "success"
				];
				return json_encode($alerta);
			}elseif($guardar_especialidad->rowCount() <= 0){
				$alerta = [
					"tipo" => "simple",
					"titulo" => "Error",
					"texto" => "No se pudo registrar la Especialidad '".$nombre."' por favor intente nuevamente",
					"icono" => "error"
				];
				return json_encode($alerta);
			}else{
				$alerta = [
					"tipo" => "simple",
					"titulo" => "Error",
					"texto" => "No se pudo registrar la Especialidad, por favor intente nuevamente",
					"icono" => "error"
				];
				return json_encode($alerta);
			}	
		} catch (\Exception $e) {
			$alerta = [
				"tipo" => "simple",
				"titulo" => "Error",
				"texto" => $e->getMessage(),
				"icono" => "error"
			];
			return json_encode($alerta);
		}
	}

	public function actualizarEspecialidad(){

		$especialidadCodigo = $this->limpiarCadena($_POST['especialidadCodigo']);
	
		$datos = $this->ejecutarConsulta("SELECT * FROM especialidad WHERE especialidadCodigo = '$especialidadCodigo'");
			if($datos->rowCount()<=0){
				$alerta=[
					"tipo"=>"simple",
					"titulo"=>"Ocurrió un error inesperado",
					"texto"=>"No hemos encontrado la especialidad en el sistema",
					"icono"=>"error"
				];
				return json_encode($alerta);
			}else{
				$datos=$datos->fetch();
				$nombreAnterior = $datos['especialidadNombre']; 
				$descripcionAnterior = $datos['descripcion']; 
			}
	
			$admin_usuario_correo=$this->limpiarCadena($_POST['administrador_usuario']);
			$admin_clave=$this->limpiarCadena($_POST['administrador_clave']);
	
			if($admin_usuario_correo=="" || $admin_clave==""){
				$alerta=[
					"tipo"=>"simple",
					"titulo"=>"Ocurrió un error inesperado",
					"texto"=>"No ha llenado todos los campos que son obligatorios, que corresponden a su 'USUARIO o CORREO' y 'CLAVE'",
					"icono"=>"error"
				];
				return json_encode($alerta);
			}
	
			if($this->verificarDatos("[a-zA-Z0-9\s@.]{8,35}",$admin_usuario_correo)){
				$alerta=[
					"tipo"=>"simple",
					"titulo"=>"Ocurrió un error inesperado",
					"texto"=>"Su USUARIO o CORREO de Administrador no coincide con el formato solicitado",
					"icono"=>"error"
				];
				return json_encode($alerta);
			}
	
			if($this->verificarDatos("[a-zA-Z0-9$@.-]{3,100}",$admin_clave)){
				$alerta=[
					"tipo"=>"simple",
					"titulo"=>"Ocurrió un error inesperado",
					"texto"=>"Su CLAVE de Administrador no coincide con el formato solicitado",
					"icono"=>"error"
				];
				return json_encode($alerta);
			}
	
			$consulta_admin=$this->ejecutarConsulta("SELECT * FROM administrador a INNER JOIN usuario u ON a.usua_codigo_fk = u.usua_codigo INNER JOIN persona pe ON a.personaCodigo_fk = pe.personaCodigo 
			WHERE (u.usua_usuario = '$admin_usuario_correo' OR u.correo = '$admin_usuario_correo') AND u.usua_codigo = '".$_SESSION['codigo']."'");
				
			if($consulta_admin->rowCount()==1){
				$consulta_admin=$consulta_admin->fetch();

				if ((!($consulta_admin['usua_usuario'] == $admin_usuario_correo || $consulta_admin['correo'] == $admin_usuario_correo)) || !password_verify($admin_clave, $consulta_admin['usua_clave'])) {
					$alerta=[
						"tipo"=>"simple",
						"titulo"=>"Ocurrió un error inesperado",
						"texto"=>"'USUARIO o CORREO' o 'CLAVE' de Administrador son incorrectos",
						"icono"=>"error"
					];
					return json_encode($alerta);
				}
			}else{
				$alerta=[
					"tipo"=>"simple",
					"titulo"=>"Ocurrió un error inesperado",
					"texto"=>"'USUARIO o CORREO' o 'CLAVE' de Administrador son incorrectos",
					"icono"=>"error"
				];
				return json_encode($alerta);
			}
	
			$nombreActual = $this->limpiarCadena($_POST['especialidadNombre']);
			$descripcionActual = $this->limpiarCadena($_POST['descripcion']);
			$duracionActual = $this->limpiarCadena($_POST['duracion']);
			$costoActual = $this->limpiarCadena($_POST['costo']);
			$diaSemanaActual = $this->limpiarCadena($_POST['diaSemana']);
				
			if($nombreActual=="" || $descripcionActual=="" || $duracionActual=="" || $costoActual=="" || $diaSemanaActual==""){
				$alerta=[
					"tipo"=>"simple",
					"titulo"=>"Ocurrió un error inesperado",
					"texto"=>"No has llenado todos los campos que son obligatorios",
					"icono"=>"error"
				];
				return json_encode($alerta);
			}
	
			if ($this->verificarDatos("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]{5,30}", $nombreActual)) {
				$alerta = [
					"tipo" => "simple",
					"titulo" => "Ocurrió un error inesperado",
					"texto" => "El NOMBRE DE LA ESPECIALIDAD no coincide con el formato solicitado",
					"icono" => "error"
				];
				return json_encode($alerta);
			}	
			
			if($nombreActual != $nombreAnterior){
				$consulta_nombre = $this->ejecutarConsulta("SELECT especialidadNombre FROM especialidad WHERE especialidadNombre = '$nombreActual'");
				if ($consulta_nombre->rowCount() > 0) {
					$alerta = [
						"tipo" => "simple",
						"titulo" => "Ocurrió un error inesperado",
						"texto" => "El NOMBRE DE LA ESPECIALIDAD ya está registrado",
						"icono" => "error"
					];
					return json_encode($alerta);
				}
			}	
				
			if (strlen($descripcionActual) > 255) {
				$alerta = [
					"tipo" => "simple",
					"titulo" => "Ocurrió un error inesperado",
					"texto" => "La DESCRIPCIÓN no debe exceder los 255 caracteres",
					"icono" => "error"
				];
				return json_encode($alerta);
			}
	
			if ($descripcionAnterior !== $descripcionActual) {
				$consulta_descripcion = $this->ejecutarConsulta("SELECT descripcion FROM especialidad WHERE descripcion = '$descripcionActual'");
				if ($consulta_descripcion->rowCount() > 0) {
					$alerta = [
						"tipo" => "simple",
						"titulo" => "Ocurrió un error inesperado",
						"texto" => "La DESCRIPCIÓN ingresada ya se encuentra registrada, verifique que la descripción sea la correcta",
						"icono" => "error"
					];
					return json_encode($alerta);
				}
			}

			if (!preg_match("/^([01][0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]$/", $duracionActual)) {
				$alerta = [
					"tipo" => "simple",
					"titulo" => "Ocurrió un error inesperado",
					"texto" => "La DURACIÓN no tiene el formato correcto (HH:MM:SS)",
					"icono" => "error"
				];
				return json_encode($alerta);
			}
						
			if ($costoActual <= 0) {
				$alerta = [
					"tipo" => "simple",
					"titulo" => "Ocurrió un error inesperado",
					"texto" => "El COSTO debe ser un valor mayor a 0",
					"icono" => "error"
				];
				return json_encode($alerta);
			}
			
			$diasValidos = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];
			$diasIngresados = array_map('trim', explode(',', $diaSemanaActual));

			foreach ($diasIngresados as $dia) {
				if (!in_array($dia, $diasValidos)) {
					$alerta = [
						"tipo" => "simple",
						"titulo" => "Ocurrió un error inesperado",
						"texto" => "Uno o más de los días ingresados no son válidos. Asegúrate de ingresar días reales.",
						"icono" => "error"
					];
					return json_encode($alerta);
				}
			}	
	
			try {
				$especialidad_datos_up = [
					[
						"campo_nombre" => "especialidadNombre",
						"campo_marcador" => ":Nombre",
						"campo_valor" => $nombreActual
					],
					[
						"campo_nombre" => "descripcion",
						"campo_marcador" => ":Descripcion",
						"campo_valor" => $descripcionActual
					],
					[
						"campo_nombre" => "duracion", 
						"campo_marcador" => ":Duracion",
						"campo_valor" => $duracionActual
					],
					[
						"campo_nombre" => "costo",
						"campo_marcador" => ":Costo",
						"campo_valor" => $costoActual
					],
					[
						"campo_nombre" => "diaSemana",
						"campo_marcador" => ":Dia",
						"campo_valor" => $diaSemanaActual
					],
					[
						"campo_nombre" => "especialidad_actualizada",
						"campo_marcador" => ":Actualizada",
						"campo_valor" => date("Y-m-d H:i:s")
					]
				];
				
				$condicionEspecialidad = [
					"condicion_campo" => "especialidadCodigo",
					"condicion_marcador" => ":ID", 
					"condicion_valor" => $especialidadCodigo
				];
				
				if (!$this->actualizarDatos("Especialidad", $especialidad_datos_up, $condicionEspecialidad)) {
					throw new \Exception("No se pudieron actualizar los datos de la Especialidad");
				}

				$alerta = [
					"tipo" => "recargar",
					"titulo" => "Datos de Especialidad actualizados",
					"texto" => "Los datos de la Especialidad '" . $nombreActual . "' se actualizaron correctamente",
					"icono" => "success"
				];
				return json_encode($alerta);
				
			} catch (\Exception $e) {
				$alerta = [
					"tipo" => "simple",
					"titulo" => "Ocurrió un error inesperado",
					"texto" => $e->getMessage(),
					"icono" => "error"
				];
				return json_encode($alerta);
			}
	}
	
	public function eliminarEspecialidad(){

		$especialidadCodigo=$this->limpiarCadena($_POST['especialidadCodigo']);

		$datos=$this->ejecutarConsulta("SELECT * FROM especialidad WHERE especialidadCodigo='$especialidadCodigo'");
		if($datos->rowCount()<=0){
			$alerta=[
				"tipo"=>"simple",
				"titulo"=>"Ocurrió un error inesperado",
				"texto"=>"No hemos encontrado la especialidad en el sistema",
				"icono"=>"error"
			];
			return json_encode($alerta);
		}else{
			$datos=$datos->fetch();
		}
			
		$eliminarEspecialidad=$this->eliminarRegistro("Especialidad","especialidadCodigo",$especialidadCodigo);

		if($eliminarEspecialidad->rowCount()==1){
			if(is_file("../views/fotos/".$datos['especialidad_foto'])){
				chmod("../views/fotos/".$datos['especialidad_foto'],0777);
				unlink("../views/fotos/".$datos['especialidad_foto']);
			}
			$alerta=[
				"tipo"=>"recargar",
				"titulo"=>"Especialidad eliminada",
				"texto"=>"La Especialidad '".$datos['especialidadNombre']."' ha sido eliminada del sistema correctamente",
				"icono"=>"success"
			];
		}else{
			$alerta=[
				"tipo"=>"simple",
				"titulo"=>"Ocurrió un error inesperado",
				"texto"=>"No hemos podido eliminar la Especialidad '".$datos['especialidadNombre']."' del sistema, por favor intente nuevamente",
				"icono"=>"error"
			];
		}
		return json_encode($alerta);
	}
        
    public function listarEspecialidad($pagina, $registros, $url, $busqueda) {
	    if ($_SESSION['codigo'] != 1) {
	    		session_destroy();
	    		header("Location: " . APP_URL . "app/views/content/404-vista");
	    		exit();
	    }

	    $pagina = $this->limpiarCadena($pagina);
	    $registros = $this->limpiarCadena($registros);
	    $url = $this->limpiarCadena($url);
	    $url = APP_URL . $url . "/";
	    $busqueda = $this->limpiarCadena($busqueda);
		
	    $tabla = "";
		
	    $pagina = (isset($pagina) && $pagina > 0) ? (int)$pagina : 1;
	    $inicio = ($pagina > 0) ? (($pagina * $registros) - $registros) : 0;
    
	    if (isset($busqueda) && $busqueda != "") {
        
	    $consulta_datos="SELECT * FROM especialidad WHERE ((especialidadNombre LIKE '%$busqueda%' OR costo LIKE '%$busqueda%' OR diaSemana LIKE '%$busqueda%')) ORDER BY especialidadNombre ASC LIMIT $inicio,$registros";
    
	    $consulta_total="SELECT COUNT(especialidadCodigo) FROM especialidad WHERE ((especialidadNombre LIKE '%$busqueda%' OR costo LIKE '%$busqueda%' OR diaSemana LIKE '%$busqueda%'))";
        
	    }else{
			
	    	$consulta_datos="SELECT * FROM especialidad ORDER BY especialidadNombre ASC LIMIT $inicio,$registros";
		
	    	$consulta_total="SELECT COUNT(especialidadCodigo) FROM especialidad";
			
	    }
    
	    $datos = $this->ejecutarConsulta($consulta_datos);
	    $datos = $datos->fetchAll();
		
	    $total = $this->ejecutarConsulta($consulta_total);
	    $total = (int)$total->fetchColumn();
		
	    $numeroPaginas = ceil($total / $registros);
		
	    $tabla .= '
			<div class="table-container">
	    		<table class="table is-bordered is-striped is-narrow is-hoverable is-fullwidth">
	    			<thead>
	    				<tr>
	    					<th class="has-text-centered">#</th>
	    					<th class="has-text-centered">Nombres de la Especialidad</th>
	    					<th class="has-text-centered">Descripción</th>
	    					<th class="has-text-centered">Duración</th>
	    					<th class="has-text-centered">Costo</th>
	    					<th class="has-text-centered">Día(s) en que se realiza</th>
							<th class="has-text-centered">Creado</th>
							<th class="has-text-centered">Actualizado</th>
	    					<th class="has-text-centered" colspan="4">Opciones</th>
	    				</tr>
	    			</thead>
	    			<tbody>
	    ';
    
	    if ($total >= 1 && $pagina <= $numeroPaginas) {
	    	$contador = $inicio + 1;
	    	$pag_inicio = $inicio + 1;
	    	foreach ($datos as $filas) {
	    		$tabla .= '
	    			<tr class="has-text-centered">
	    				<td>' . $contador . '</td>
	    				<td>' . $filas['especialidadNombre'] . '</td>
	    				<td>' . $filas['descripcion'] . '</td>
	    				<td>' . $filas['duracion'] . '</td>
	    				<td>' . $filas['costo'] . '</td>
	    				<td>' . $filas['diaSemana'] . '</td>
						<td>' . $filas['especialidad_creada'] . '</td>
						<td>' . $filas['especialidad_actualizada'] . '</td>
	    				<td>
	    					<a href="' . APP_URL . 'especialidadFoto/' . $filas['especialidadCodigo'] . '/" class="button is-info is-rounded is-small">Historial</a>
	    				</td>
	    				<td>
	    					<a href="' . APP_URL . 'especialidadFoto/' . $filas['especialidadCodigo'] . '/" class="button is-info is-rounded is-small">Foto</a>
	    				</td>
	    				<td>
	    					<a href="' . APP_URL . 'especialidadActualizar/' . $filas['especialidadCodigo'] . '/" class="button is-success is-rounded is-small">Actualizar</a>
	    				</td>
	    				 <td>
	    	                	<form class="FormularioAjax" action="'.APP_URL.'app/ajax/especialidadAjax.php" method="POST" autocomplete="off" >
            
	    	                		<input type="hidden" name="modulo_especialidad" value="eliminar">
	    	                		<input type="hidden" name="especialidadCodigo" value="'.$filas['especialidadCodigo'].'">
            
	    	                    	<button type="submit" class="button is-danger is-rounded is-small">Eliminar</button>
	    	                    </form>
	    	                </td>
	    			</tr>
	    		';
	    		$contador++;
	    	}
	    	
			$pag_final = $contador - 1;

		} else {
	    	if ($total >= 1) {
	    		$tabla .= '
	    			<tr class="has-text-centered">
	    				<td colspan="13">
	    					<a href="' . $url . '1/" class="button is-link is-rounded is-small mt-4 mb-4">
	    						Haga clic acá para recargar el listado
	    					</a>
	    				</td>
	    			</tr>
	    		';
	    	} else {
	    		$tabla .= '
	    			<tr class="has-text-centered">
	    				<td colspan="13">
	    					No hay registros en el sistema
	    				</td>
	    			</tr>
	    		';
	    	}
	    }
    
	    $tabla .= '</tbody></table></div>';
		
	    ### Paginación ###
	    if ($total > 0 && $pagina <= $numeroPaginas) {
	    	$tabla .= '<p class="has-text-right">Mostrando Especialidades <strong>' . $pag_inicio . '</strong> al <strong>' . $pag_final . '</strong> de un <strong>total de ' . $total . '</strong></p>';
	    	$tabla .= $this->paginadorTablas($pagina, $numeroPaginas, $url, 7);
	    }
	    return $tabla;
	}
}