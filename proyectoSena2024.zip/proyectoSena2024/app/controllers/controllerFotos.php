<?php
namespace app\controllers;
use app\models\modelCrud;

class controllerFotos extends modelCrud {

    public function eliminarFotoUsuario(){
        
        $usua_codigo=$this->limpiarCadena($_POST['usua_codigo']);
        
        $datos=$this->ejecutarConsulta("SELECT * FROM usuario WHERE usua_codigo ='$usua_codigo'");
        if($datos->rowCount()<=0){
            $alerta=[
                "tipo"=>"simple",
                "titulo"=>"Ocurrió un error inesperado",
                "texto"=>"No hemos encontrado el Usuario en el sistema",
                "icono"=>"error"
            ];
            return json_encode($alerta);
            exit();
        }else{
            $datos=$datos->fetch();
        }

        # Directorio de imagenes #
        $img_dir="../views/fotos/";

        chmod($img_dir,0777);

        if(is_file($img_dir.$datos['usuario_foto'])){
        
            chmod($img_dir.$datos['usuario_foto'],0777);
        
            if(!unlink($img_dir.$datos['usuario_foto'])){
                $alerta=[
                    "tipo"=>"simple",
                    "titulo"=>"Ocurrió un error inesperado",
                    "texto"=>"Error al intentar eliminar la foto del usuario, por favor intente nuevamente",
                    "icono"=>"error"
                ];
                return json_encode($alerta);
                exit();
            }
        }else{
            $alerta=[
                "tipo"=>"simple",
                "titulo"=>"Ocurrió un error inesperado",
                "texto"=>"No hemos encontrado la foto del usuario en el sistema",
                "icono"=>"error"
            ];
            return json_encode($alerta);
            exit();
        }

        $usuario_datos_up=[
            [
                "campo_nombre"=>"usuario_foto",
                "campo_marcador"=>":Foto",
                "campo_valor"=>""
            ],
            [
                "campo_nombre"=>"usuario_actualizado",
                "campo_marcador"=>":Actualizado",
                "campo_valor"=>date("Y-m-d H:i:s")
            ]
        ];

        $condicion=[
            "condicion_campo"=>"usua_codigo",
            "condicion_marcador"=>":ID",
            "condicion_valor"=>$usua_codigo
        ];

        if($this->actualizarDatos("usuario",$usuario_datos_up,$condicion)){
        
            if($usua_codigo==$_SESSION['codigo']){
                $_SESSION['foto']="";
            }
        
            $alerta=[
                "tipo"=>"recargar",
                "titulo"=>"Foto eliminada",
                "texto"=>"La foto del usuario ".$datos['usua_usuario']." se eliminó correctamente",
                "icono"=>"success"
            ];
        }else{
            $alerta=[
                "tipo"=>"recargar",
                "titulo"=>"Foto eliminada",
                "texto"=>"No hemos podido actualizar algunos datos del usuario ".$datos['usua_usuario'].", sin embargo la foto ha sido eliminada correctamente",
                "icono"=>"warning"
            ];
        }
        return json_encode($alerta);
    }

    public function actualizarFotoUsuario(){

        $usua_codigo=$this->limpiarCadena($_POST['usua_codigo']);

        $datos=$this->ejecutarConsulta("SELECT * FROM usuario WHERE usua_codigo ='$usua_codigo'");
        if($datos->rowCount()<=0){
            $alerta=[
                "tipo"=>"simple",
                "titulo"=>"Ocurrió un error inesperado",
                "texto"=>"No hemos encontrado el usuario en el sistema",
                "icono"=>"error"
            ];
            return json_encode($alerta);
            exit();
        }else{
            $datos=$datos->fetch();
        }
    
        # Directorio de imagenes #
        $img_dir="../views/fotos/";

        # Comprobar si se selecciono una imagen #
        if($_FILES['usuario_foto']['name']=="" && $_FILES['usuario_foto']['size']<=0){
            $alerta=[
                "tipo"=>"simple",
                "titulo"=>"Ocurrió un error inesperado",
                "texto"=>"No ha seleccionado una foto para el usuario",
                "icono"=>"error"
            ];
            return json_encode($alerta);
            exit();
        }
    
        # Creando directorio #
        if(!file_exists($img_dir)){
            if(!mkdir($img_dir,0777)){
                $alerta=[
                    "tipo"=>"simple",
                    "titulo"=>"Ocurrió un error inesperado",
                    "texto"=>"Error al crear el directorio",
                    "icono"=>"error"
                ];
                return json_encode($alerta);
                exit();
            } 
        }
    
        # Verificando formato de imagenes #
        if(mime_content_type($_FILES['usuario_foto']['tmp_name'])!="image/jpeg" && mime_content_type($_FILES['usuario_foto']['tmp_name'])!="image/png"){
            $alerta=[
                "tipo"=>"simple",
                "titulo"=>"Ocurrió un error inesperado",
                "texto"=>"La imagen que ha seleccionado es de un formato no permitido",
                "icono"=>"error"
            ];
            return json_encode($alerta);
            exit();
        }
    
        # Verificando peso de imagen #
        if($_FILES['usuario_foto']['size'] > (5 * 1024 * 1024)) { // 5MB
            $alerta = [
                "tipo" => "simple",
                "titulo" => "Ocurrió un error inesperado",
                "texto" => "La imagen que ha seleccionado supera el peso permitido",
                "icono" => "error"
            ];
            return json_encode($alerta);
            exit();
        }

        # Nombre de la foto #
        if($datos['usuario_foto']!=""){
            $foto=explode(".", $datos['usuario_foto']);
            $foto=$foto[0];
        }else{
            $foto=str_ireplace(" ","_",$datos['usua_usuario']);
            $foto=$foto."_".rand(0,100);
        }
            
        # Extension de la imagen #
        switch(mime_content_type($_FILES['usuario_foto']['tmp_name'])){
            case 'image/jpeg':
                $foto=$foto.".jpg";
            break;
            case 'image/png':
                $foto=$foto.".png";
            break;
        }

        chmod($img_dir,0777);
    
        # Moviendo imagen al directorio #
        if(!move_uploaded_file($_FILES['usuario_foto']['tmp_name'],$img_dir.$foto)){
            $alerta=[
                "tipo"=>"simple",
                "titulo"=>"Ocurrió un error inesperado",
                "texto"=>"No podemos subir la imagen al sistema en este momento",
                "icono"=>"error"
            ];
            return json_encode($alerta);
            exit();
        }
    
        # Eliminando imagen anterior #
        if(is_file($img_dir.$datos['usuario_foto']) && $datos['usuario_foto']!=$foto){
            chmod($img_dir.$datos['usuario_foto'], 0777);
            unlink($img_dir.$datos['usuario_foto']);
        }
    
        $usuario_datos_up=[
            [
                "campo_nombre"=>"usuario_foto",
                "campo_marcador"=>":Foto",
                "campo_valor"=>$foto
            ],
            [
                "campo_nombre"=>"usuario_actualizado",
                "campo_marcador"=>":Actualizado",
                "campo_valor"=>date("Y-m-d H:i:s")
            ]
        ];
    
        $condicion=[
            "condicion_campo"=>"usua_codigo",
            "condicion_marcador"=>":ID",
            "condicion_valor"=>$usua_codigo
        ];
    
        if($this->actualizarDatos("usuario",$usuario_datos_up,$condicion)){
    
            if($usua_codigo==$_SESSION['codigo']){
                $_SESSION['foto']=$foto;
            }
    
            $alerta=[
                "tipo"=>"recargar",
                "titulo"=>"Foto actualizada",
                "texto"=>"La foto del usuario ".$datos['usua_usuario']." se actualizo correctamente",
                "icono"=>"success"
            ];
        }else{
            $alerta=[
                "tipo"=>"recargar",
                "titulo"=>"Foto actualizada",
                "texto"=>"No hemos podido actualizar algunos datos del usuario ".$datos['usua_usuario']." , sin embargo la foto ha sido actualizada",
                "icono"=>"warning"
            ];
        }
    
        return json_encode($alerta);
    }	

    public function eliminarFotoEspecialidad(){

        $especialidadCodigo=$this->limpiarCadena($_POST['especialidadCodigo']);
    
        $datos=$this->ejecutarConsulta("SELECT * FROM especialidad WHERE especialidadCodigo ='$especialidadCodigo'");
        if($datos->rowCount()<=0){
            $alerta=[
                "tipo"=>"simple",
                "titulo"=>"Ocurrió un error inesperado",
                "texto"=>"No hemos encontrado la Especialidad en el sistema",
                "icono"=>"error"
            ];
            return json_encode($alerta);
            exit();
        }else{
            $datos=$datos->fetch();
        }
    
        # Directorio de imagenes #
        $img_dir="../views/fotos/";

        chmod($img_dir,0777);

        if(is_file($img_dir.$datos['especialidad_foto'])){

            chmod($img_dir.$datos['especialidad_foto'],0777);

            if(!unlink($img_dir.$datos['especialidad_foto'])){
                $alerta=[
                    "tipo"=>"simple",
                    "titulo"=>"Ocurrió un error inesperado",
                    "texto"=>"Error al intentar eliminar la foto de la especialidad, por favor intente nuevamente",
                    "icono"=>"error"
                ];
                return json_encode($alerta);
                exit();
            }
        }else{
            $alerta=[
                "tipo"=>"simple",
                "titulo"=>"Ocurrió un error inesperado",
                "texto"=>"No hemos encontrado la foto de la especialidad en el sistema",
                "icono"=>"error"
            ];
            return json_encode($alerta);
            exit();
        }
    
        $especialidad_datos_up=[
            [
                "campo_nombre"=>"especialidad_foto",
                "campo_marcador"=>":Foto",
                "campo_valor"=>""
            ],
            [
                "campo_nombre"=>"especialidad_actualizada",
                "campo_marcador"=>":Actualizado",
                "campo_valor"=>date("Y-m-d H:i:s")
            ]
        ];
    
        $condicion=[
            "condicion_campo"=>"especialidadCodigo",
            "condicion_marcador"=>":ID",
            "condicion_valor"=>$especialidadCodigo
        ];
    
        if($this->actualizarDatos("especialidad",$especialidad_datos_up,$condicion)){
    
            if (isset($_SESSION['especialidadCodigo']) && $especialidadCodigo == $_SESSION['especialidadCodigo']) {
                $_SESSION['especialidad_foto'] =$foto;
            }
    
            $alerta=[
                "tipo"=>"recargar",
                "titulo"=>"Foto eliminada",
                "texto"=>"La foto de la especialidad '".$datos['especialidadNombre']."' se eliminó correctamente",
                "icono"=>"success"
            ];
        }else{
            $alerta=[
                "tipo"=>"recargar",
                "titulo"=>"Foto eliminada",
                "texto"=>"No hemos podido actualizar algunos datos de la especialidad '".$datos['especialidadNombre']."', sin embargo la foto ha sido eliminada correctamente",
                "icono"=>"warning"
            ];
        }
    
        return json_encode($alerta);
    }

    public function actualizarFotoEspecialidad(){

        $especialidadCodigo=$this->limpiarCadena($_POST['especialidadCodigo']);
    
        $datos=$this->ejecutarConsulta("SELECT * FROM especialidad WHERE especialidadCodigo ='$especialidadCodigo'");
        if($datos->rowCount()<=0){
                $alerta=[
                    "tipo"=>"simple",
                    "titulo"=>"Ocurrió un error inesperado",
                    "texto"=>"No hemos encontrado la especialidad en el sistema",
                    "icono"=>"error"
                ];
                return json_encode($alerta);
                exit();
        } else {
            $datos=$datos->fetch();
        }
    
        # Directorio de imagenes #
        $img_dir="../views/fotos/";

        # Comprobar si se selecciono una imagen #
        if($_FILES['especialidad_foto']['name']=="" && $_FILES['especialidad_foto']['size']<=0){
            $alerta=[
                "tipo"=>"simple",
                "titulo"=>"Ocurrió un error inesperado",
                "texto"=>"No ha seleccionado una foto para la especialidad",
                "icono"=>"error"
            ];
            return json_encode($alerta);
            exit();
        }
    
        # Creando directorio #
        if(!file_exists($img_dir)){
            if(!mkdir($img_dir,0777)){
                $alerta=[
                    "tipo"=>"simple",
                    "titulo"=>"Ocurrió un error inesperado",
                    "texto"=>"Error al crear el directorio",
                    "icono"=>"error"
                ];
                return json_encode($alerta);
                exit();
            } 
        }
    
        # Verificando formato de imagenes #
        if(mime_content_type($_FILES['especialidad_foto']['tmp_name'])!="image/jpeg" && mime_content_type($_FILES['especialidad_foto']['tmp_name'])!="image/png"){
            $alerta=[
                "tipo"=>"simple",
                "titulo"=>"Ocurrió un error inesperado",
                "texto"=>"La imagen que ha seleccionado es de un formato no permitido",
                "icono"=>"error"
            ];
            return json_encode($alerta);
            exit();
        }
    
        # Verificando peso de imagen #
        if($_FILES['especialidad_foto']['size'] > (5 * 1024 * 1024)) { // 5MB
            $alerta = [
                "tipo" => "simple",
                "titulo" => "Ocurrió un error inesperado",
                "texto" => "La imagen que ha seleccionado supera el peso permitido",
                "icono" => "error"
            ];
            return json_encode($alerta);
            exit();
        }
    
        # Nombre de la foto #
        if($datos['especialidad_foto']!=""){
            $foto=explode(".", $datos['especialidad_foto']);
            $foto=$foto[0];
        }else{
            $foto=str_ireplace(" ","_",$datos['especialidadNombre']);
            $foto=$foto."_".rand(0,100);
        }
            
        # Extension de la imagen #
        switch(mime_content_type($_FILES['especialidad_foto']['tmp_name'])){
            case 'image/jpeg':
                $foto=$foto.".jpg";
            break;
            case 'image/png':
                $foto=$foto.".png";
            break;
        }
    
        chmod($img_dir,0777);
    
        # Moviendo imagen al directorio #
        if(!move_uploaded_file($_FILES['especialidad_foto']['tmp_name'],$img_dir.$foto)){
            $alerta=[
                "tipo"=>"simple",
                "titulo"=>"Ocurrió un error inesperado",
                "texto"=>"No podemos subir la imagen al sistema en este momento",
                "icono"=>"error"
            ];
            return json_encode($alerta);
            exit();
        }
    
        # Eliminando imagen anterior #
        if(is_file($img_dir.$datos['especialidad_foto']) && $datos['especialidad_foto']!=$foto){
            chmod($img_dir.$datos['especialidad_foto'], 0777);
            unlink($img_dir.$datos['especialidad_foto']);
        }
    
        $especialidad_datos_up=[
            [
                "campo_nombre"=>"especialidad_foto",
                "campo_marcador"=>":Foto",
                "campo_valor"=>$foto
            ],
            [
                "campo_nombre"=>"especialidad_actualizada",
                "campo_marcador"=>":Actualizado",
                "campo_valor"=>date("Y-m-d H:i:s")
            ]
        ];
    
        $condicion=[
            "condicion_campo"=>"especialidadCodigo",
            "condicion_marcador"=>":ID",
            "condicion_valor"=>$especialidadCodigo
        ];
    
        if($this->actualizarDatos("especialidad",$especialidad_datos_up,$condicion)){

            if (isset($_SESSION['especialidadCodigo']) && $especialidadCodigo == $_SESSION['especialidadCodigo']) {
                $_SESSION['especialidad_foto'] =$foto;
            }
            
            $alerta=[
                "tipo"=>"recargar",
                "titulo"=>"Foto actualizada",
                "texto"=>"La foto de la especialidad '".$datos['especialidadNombre']."' se actualizó correctamente",
                "icono"=>"success"
            ];
        }else{
            $alerta=[
                "tipo"=>"recargar",
                "titulo"=>"Foto actualizada",
                "texto"=>"No hemos podido actualizar algunos datos de la especialidad '".$datos['especialidadNombre']."' , sin embargo la foto ha sido actualizada",
                "icono"=>"warning"
            ];
        }
            return json_encode($alerta);
    }
}