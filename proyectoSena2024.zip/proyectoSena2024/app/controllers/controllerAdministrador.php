<?php 
namespace app\controllers;
use app\models\modelCrud;

class controllerAdministrador extends modelCrud {

	public function registrarUsuarioPersona(){

		$usuario = $this->limpiarCadena($_POST['usua_usuario']);
		$correo = $this->limpiarCadena($_POST['correo']);
		$clave1 = $this->limpiarCadena($_POST['usua_clave1']);	
		$clave2 = $this->limpiarCadena($_POST['usua_clave2']);
		$rol = $this->limpiarCadena($_POST['rol']);
		$nombre = $this->limpiarCadena($_POST['nombre']);
		$apellido = $this->limpiarCadena($_POST['apellido']);
		$id = $this->limpiarCadena($_POST['identificacion']);
		$edad = $this->limpiarCadena($_POST['edad']);
		$celular = $this->limpiarCadena($_POST['celular']);
		$telef2 = $this->limpiarCadena($_POST['telef2']);
		$direccion = $this->limpiarCadena($_POST['direccion']);
		$tipoID = $this->limpiarCadena($_POST['tipoID']);
		$sexo = $this->limpiarCadena($_POST['sexo']);

		if ($rol === 'Especialista') {
    		if (isset($_POST['especialidad'])) { 
    	    	$especialidadCodigo_fk = $this->limpiarCadena($_POST['especialidad']);
				if (empty($especialidadCodigo_fk)) {
					$alerta = [
						"tipo" => "simple",
						"titulo" => "Ocurrió un error inesperado",
						"texto" => "No has elegido una Especialidad para el Especialista",
						"icono" => "error"
					];
					return json_encode($alerta);
				}
    		} else {
				$alerta = [
					"tipo" => "simple",
					"titulo" => "Ocurrió un error inesperado",
					"texto" => "No se ha recibido la especialidad",
					"icono" => "error"
				];
				return json_encode($alerta);
    		}
		}
			
        if ($usuario == "" || $correo == "" || $clave1 == "" || $clave2 == "" || $rol == "") {
            $alerta=[
                "tipo"=>"simple",
                "titulo"=>"Ocurrió un error inesperado",
                "texto"=>"No has llenado todos los campos que son obligatorios para el Usuario",
                "icono"=>"error"
            ];
            return json_encode($alerta);
        }

		if ($this->verificarDatos("[a-zA-Z0-9\s ]{8,35}", $usuario)) {
            $alerta=[
                "tipo"=>"simple",
                "titulo"=>"Ocurrió un error inesperado",
                "texto"=>"El NOMBRE DE USUARIO no coincide con el formato solicitado",
                "icono"=>"error"
            ];
            return json_encode($alerta);
        }

		$consulta_usuario = $this->ejecutarConsulta("SELECT usua_usuario FROM usuario WHERE usua_usuario='$usuario'");
        if ($consulta_usuario->rowCount() > 0) {
            $alerta=[
                "tipo"=>"simple",
                "titulo"=>"Ocurrió un error inesperado",
                "texto"=>"El NOMBRE DE USUARIO ingresado ya se encuentra registrado, por favor elija otro",
                "icono"=>"error"
            ];
            return json_encode($alerta);        
        }

		if($correo!=""){
            if(filter_var($correo, FILTER_VALIDATE_EMAIL)){
                $consulta_correo=$this->ejecutarConsulta("SELECT correo FROM usuario WHERE correo ='$correo'");
                if($consulta_correo->rowCount()>0){
                    $alerta=[
                        "tipo"=>"simple",
                        "titulo"=>"Ocurrió un error inesperado",
                        "texto"=>"El CORREO que acaba de ingresar ya se encuentra registrado en el sistema, por favor verifique e intente nuevamente",
                        "icono"=>"error"
                    ];
                    return json_encode($alerta);
                }
            }else{
                $alerta=[
                    "tipo"=>"simple",
                    "titulo"=>"Ocurrió un error inesperado",
                    "texto"=>"Ha ingresado un correo electrónico no valido",
                    "icono"=>"error"
                ];
                return json_encode($alerta);           
            }
        }
		
        if ($this->verificarDatos("[a-zA-Z0-9$@.-]{3,100}", $clave1) || $this->verificarDatos("[a-zA-Z0-9$@.-]{3,100}", $clave2)) {
            $alerta=[
                "tipo"=>"simple",
                "titulo"=>"Ocurrió un error inesperado",
                "texto"=>"Las CLAVES no coinciden con el formato solicitado",
                "icono"=>"error"
            ];
            return json_encode($alerta);
        }

        if ($clave1 != $clave2) {
            $alerta=[
                "tipo"=>"simple",
                "titulo"=>"Ocurrió un error inesperado",
                "texto"=>"Las contraseñas que acaba de ingresar no coinciden, por favor verifique e intente nuevamente",
                "icono"=>"error"
            ];
            return json_encode($alerta);
            
        } else {
            $clave = password_hash($clave1, PASSWORD_BCRYPT, ["cost" => 10]);
        }

        // Directorio de imágenes
        $img_dir = "../views/fotos/";

        // Comprobar si se selecciona una imagen
        if($_FILES['usuario_foto']['name']!="" && $_FILES['usuario_foto']['size']>0){

            # Creando directorio #
            if(!file_exists($img_dir)){
                if(!mkdir($img_dir,0777)){
                    $alerta=[
                        "tipo"=>"simple",
                        "titulo"=>"Ocurrió un error inesperado",
                        "texto"=>"Error al crear el directorio",
                        "icono"=>"error"
                    ];
                    return json_encode($alerta);
                } 
            }

            # Verificando formato de imagenes #
            if(mime_content_type($_FILES['usuario_foto']['tmp_name'])!="image/jpeg" && mime_content_type($_FILES['usuario_foto']['tmp_name'])!="image/png"){
                $alerta=[
                    "tipo"=>"simple",
                    "titulo"=>"Ocurrió un error inesperado",
                    "texto"=>"La imagen que ha seleccionado es de un formato no permitido",
                    "icono"=>"error"
                ];
                return json_encode($alerta);
            }

            # Verificando peso de imagen #
            if(($_FILES['usuario_foto']['size']/1024)>5120){
                $alerta=[
                    "tipo"=>"simple",
                    "titulo"=>"Ocurrió un error inesperado",
                    "texto"=>"La imagen que ha seleccionado supera el peso permitido",
                    "icono"=>"error"
                ];
                return json_encode($alerta);
                
            }

            # Nombre de la foto #
            $foto=str_ireplace(" ","_",$usuario);
            $foto=$foto."_".rand(0,100);

            # Extension de la imagen #
            switch(mime_content_type($_FILES['usuario_foto']['tmp_name'])){
                case 'image/jpeg':
                    $foto=$foto.".jpg";
                break;
                case 'image/png':
                    $foto=$foto.".png";
                break;
            }

            chmod($img_dir,0777);

            # Moviendo imagen al directorio #
            if(!move_uploaded_file($_FILES['usuario_foto']['tmp_name'],$img_dir.$foto)){
                $alerta=[
                    "tipo"=>"simple",
                    "titulo"=>"Ocurrió un error inesperado",
                    "texto"=>"No podemos subir la imagen al sistema en este momento",
                    "icono"=>"error"
                ];
                return json_encode($alerta);
            }

        }else{
            $foto="";
        }

		if ($nombre == "" || $apellido == "" || $id == "" || $edad == "" || $celular == "" || $tipoID == "" || $sexo == "") {
			$alerta=[
                "tipo"=>"simple",
                "titulo"=>"Ocurrió un error inesperado",
                "texto"=>"No has llenado todos los campos que son obligatorios en 'Campos Adicionales'",
                "icono"=>"error"
            ];
            return json_encode($alerta);
        }

		if ($this->verificarDatos("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]{3,40}", $nombre) || $this->verificarDatos("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]{3,40}", $apellido) ) {
            $alerta=[
                "tipo"=>"simple",
                "titulo"=>"Ocurrió un error inesperado",
                "texto"=>"Los NOMBRES ó APELLIDOS no coincide con el formato solicitado",
                "icono"=>"error"
            ];
            return json_encode($alerta);
        }

		if ($this->verificarDatos("[0-9]{8,13}", $id)) {
            $alerta=[
                "tipo"=>"simple",
                "titulo"=>"Ocurrió un error inesperado",
                "texto"=>"El NÚMERO DE IDENTIFICACIÓN no coincide con el formato solicitado",
                "icono"=>"error"
            ];
            return json_encode($alerta);
        }

		$consulta_personaID = $this->ejecutarConsulta("SELECT identificacion FROM persona WHERE identificacion='$id'");
        if ($consulta_personaID->rowCount() > 0) {
            $alerta=[
                "tipo"=>"simple",
                "titulo"=>"Ocurrió un error inesperado",
                "texto"=>"El NÚMERO DE IDENTIFICACIÓN ingresado ya se encuentra registrado, en caso de tener una cuenta asociada a esta persona seleccione la Opción '¿Olvidaste tu Contraseña?' que está en el Inicio de Sesión",
                "icono"=>"error"
            ];
            return json_encode($alerta);
        }

        if ($this->verificarDatos("[0-9]{1,2}", $edad)) {
            $alerta=[
                "tipo"=>"simple",
                "titulo"=>"Ocurrió un error inesperado",
                "texto"=>"La EDAD no coincide con el formato solicitado",
                "icono"=>"error"
            ];
            return json_encode($alerta);
	
        }

        if ($this->verificarDatos("[0-9]{10}", $celular)) {
            $alerta=[
                "tipo"=>"simple",
                "titulo"=>"Ocurrió un error inesperado",
                "texto"=>"El CELULAR no coincide con el formato solicitado",
                "icono"=>"error"
            ];
            return json_encode($alerta);
        }

		$consulta_personaCelular = $this->ejecutarConsulta("SELECT celular FROM persona WHERE celular = '$celular'");
        if ($consulta_personaCelular->rowCount() > 0) {
            $alerta=[
                "tipo"=>"simple",
                "titulo"=>"Ocurrió un error inesperado",
                "texto"=>"El NÚMERO CELULAR ingresado ya se encuentra registrado, en caso de tener una cuenta asociada a esta número seleccione la Opción '¿Olvidaste tu Contraseña?' que está en el Inicio de Sesión o elija otro número",
                "icono"=>"error"
            ];
            return json_encode($alerta);
        }

		if (!empty($telef2)) {
			if ($this->verificarDatos("[0-9]{10}", $telef2)) {
				$alerta = [
					"tipo" => "simple",
					"titulo" => "Ocurrió un error inesperado",
					"texto" => "El NÚMERO DE TELÉFONO 2 no coincide con el formato solicitado",
					"icono" => "error"
				];
				return json_encode($alerta);
			}
		
			$consulta_persona_Telef2 = $this->ejecutarConsulta("SELECT telef2 FROM persona WHERE telef2='$telef2'");
			if ($consulta_persona_Telef2->rowCount() > 0) {
				$alerta = [
					"tipo" => "simple",
					"titulo" => "Ocurrió un error inesperado",
					"texto" => "El NÚMERO DE TELÉFONO 2 ingresado ya se encuentra registrado. Si ya tiene una cuenta, seleccione la opción 'Recuperar Cuenta' en el inicio de sesión o elija otro número",
					"icono" => "error"
				];
				return json_encode($alerta);
			}
		}
	
		if (!empty($direccion)){
			if($this->verificarDatos("^[a-zA-Z0-9\s#\\-]{10,100}$", $direccion)){
				$alerta = [
					"tipo" => "simple",
					"titulo" => "Ocurrió un error inesperado",
					"texto" => "La DIRECCIÓN no coincide con el formato solicitado",
					"icono" => "error"
				];
				return json_encode($alerta);
			}
		}  
		
		if (($edad < 18 && $tipoID == "CC") || ($edad >= 18 && $tipoID == "TI")) {
			$alerta = [
				"tipo" => "simple",
				"titulo" => "Ocurrió un error inesperado",
				"texto" => $edad < 18 
					? "Al ser menor de edad debe seleccionar 'Tarjeta de Identidad', no 'Cédula de Ciudadanía'" 
					: "Al ser mayor de edad debe seleccionar 'Cédula de Ciudadanía', no 'Tarjeta de Identidad'",
				"icono" => "error"
			];
			return json_encode($alerta);
		}

		if ($rol==="Especialista" && $edad < 18) {
			$alerta = [
				"tipo" => "simple",
				"titulo" => "Ocurrió un error inesperado",
				"texto" => "Al ser menor de edad no puede ser un Especialista", 
				"icono" => "error"
			];
			return json_encode($alerta);
		}

		$conexion = $this->conectar();
		$conexion->beginTransaction();
		
		try {
			$usuario_datos_reg = [
				[
				    "campo_nombre" => "usua_usuario",
				    "campo_marcador" => ":Usua_usuario",
				    "campo_valor" => $usuario
				],
				[
				    "campo_nombre" => "correo",
				    "campo_marcador" => ":Correo",
				    "campo_valor" => $correo
				],
				[
				    "campo_nombre" => "usua_clave",
				    "campo_marcador" => ":Usua_clave",
				    "campo_valor" => $clave
				],
				[
				    "campo_nombre" => "rol",
				    "campo_marcador" => ":Rol",
				    "campo_valor" => $rol
				],
				[
				    "campo_nombre" => "usuario_foto",
				    "campo_marcador" => ":Foto",
				    "campo_valor" => $foto
				],
				[
				    "campo_nombre" => "usuario_creado",
				    "campo_marcador" => ":Creado",
				    "campo_valor" => date("Y-m-d H:i:s")
				],
				[
				    "campo_nombre" => "usuario_actualizado",
				    "campo_marcador" => ":Actualizado",
				    "campo_valor" => date("Y-m-d H:i:s")
				]
			];

			$guardar_usuario = $this->guardarDatos("Usuario", $usuario_datos_reg, $conexion);

			if ($guardar_usuario->rowCount() != 1) {
				$alerta = [
        			"tipo" => "simple",
    			    "titulo" => "Error",
    			    "texto" => "No se pudo registrar el usuario ".$usuario." por favor intente nuevamente",
    			    "icono" => "error"
    			];
    			return json_encode($alerta);
			}

			$usua_codigo_fk = $conexion->lastInsertId();

			$persona_datos_reg = [
				[            
					"campo_nombre" => "usua_codigo_fk",
					"campo_marcador" => ":Usua_codigo_fk",
					"campo_valor" => $usua_codigo_fk
				],
				[
					"campo_nombre" => "identificacion",
					"campo_marcador" => ":idPersona",
					"campo_valor" => $id
				],
				[
					"campo_nombre" => "tipoID",
					"campo_marcador" => ":TipoID",
					"campo_valor" => $tipoID
				],
				[
					"campo_nombre" => "nombre",
					"campo_marcador" => ":Nombre",
					"campo_valor" => $nombre
				],
				[
					"campo_nombre" => "apellido",
					"campo_marcador" => ":Apellido",
					"campo_valor" => $apellido
				],
				[
					"campo_nombre" => "edad",
					"campo_marcador" => ":Edad",
					"campo_valor" => $edad
				], 
				[
					"campo_nombre" => "sexo",
					"campo_marcador" => ":Sexo",
					"campo_valor" => $sexo
				],
				[  
					"campo_nombre" => "celular",
					"campo_marcador" => ":Celular",
					"campo_valor" => $celular
				],
				[            
					"campo_nombre" => "direccion",
					"campo_marcador" => ":Direccion",
					"campo_valor" => $direccion
				],
				[            
					"campo_nombre" => "telef2",
					"campo_marcador" => ":Telef2",
					"campo_valor" => $telef2
				]
			];
	
			$guardar_persona = $this->guardarDatos("Persona", $persona_datos_reg,$conexion);

			if ($guardar_persona->rowCount() != 1) {
				$alerta = [
					"tipo" => "simple",
					"titulo" => "Ocurrió un error inesperado",
					"texto" => "No se pudo registrar la persona, por favor intente nuevamente, código:".$usua_codigo_fk,
					"icono" => "error"
				];
				return json_encode($alerta); 
			}

			$personaCodigo_fk = $conexion->lastInsertId();

			switch ($rol) {
				case 'Administrador':
					$this->registrarAdministrador($usua_codigo_fk, $personaCodigo_fk, $conexion);
					break;
				case 'Paciente':
					$this->registrarPaciente($usua_codigo_fk, $personaCodigo_fk, $conexion);
					break;	
				case 'Especialista':
					if (empty($especialidadCodigo_fk) || !is_numeric($especialidadCodigo_fk)) {
						$alerta = [
							"tipo" => "simple",
							"titulo" => "Ocurrió un error inesperado",
							"texto" => "Código de Especialidad no válido",
							"icono" => "error"
						];
						return json_encode($alerta);
					}
					$this->registrarEspecialista($usua_codigo_fk, $personaCodigo_fk, $especialidadCodigo_fk, $conexion);
					break;			
				default:
					throw new \Exception ("Rol no válido");
					break;
			}
			$conexion->commit();
			$alerta = [
				"tipo" => "simple",
				"titulo" => "Registro exitoso",
				"texto" => "El Usuario " . $usuario . " se ha registrado exitosamente.",
				"icono" => "success"
			];
			return json_encode($alerta);
		
		} catch (\Exception $e) {
			$conexion->rollBack();
			$alerta = [
				"tipo" => "simple",
				"titulo" => "Error",
				"texto" => $e->getMessage(),
				"icono" => "error"
			];
			return json_encode($alerta);
		}
	}

	public function listarUsuario($pagina, $registros, $url, $busqueda) {
		if ($_SESSION['rol'] != "Administrador") {
			session_destroy();
			header("Location: " . APP_URL . "app/views/content/404-vista");
			exit();
		}
		
		$pagina = $this->limpiarCadena($pagina);
		$registros = $this->limpiarCadena($registros);
		$url = $this->limpiarCadena($url);
		$url = APP_URL . $url . "/";
		$busqueda = $this->limpiarCadena($busqueda);
	
		$tabla = "";
	
		$pagina = (isset($pagina) && $pagina > 0) ? (int)$pagina : 1;
		$inicio = ($pagina > 0) ? (($pagina * $registros) - $registros) : 0;
	
		if (isset($busqueda) && $busqueda != "") {
			
			$consulta_datos="SELECT * FROM usuario u INNER JOIN persona p ON u.usua_codigo = p.usua_codigo_fk WHERE ((u.usua_codigo!='".$_SESSION['codigo']."' AND u.rol!='Administrador') AND (u.usua_usuario LIKE '%$busqueda%' OR u.correo LIKE '%$busqueda%' OR p.nombre LIKE '%$busqueda%' OR p.apellido LIKE '%$busqueda%')) ORDER BY p.apellido ASC LIMIT $inicio, $registros";

			$consulta_total="SELECT COUNT(u.usua_codigo) FROM usuario u INNER JOIN persona p ON u.usua_codigo = p.usua_codigo_fk WHERE ((u.usua_codigo!='".$_SESSION['codigo']."' AND u.rol!='Administrador') AND (u.usua_usuario LIKE '%$busqueda%' OR u.correo LIKE '%$busqueda%' OR p.nombre LIKE '%$busqueda%' OR p.apellido LIKE '%$busqueda%'))";

		}else{

			$consulta_datos="SELECT * FROM usuario u INNER JOIN persona p ON u.usua_codigo = p.usua_codigo_fk WHERE u.usua_codigo!='".$_SESSION['codigo']."' AND u.rol!='Administrador' ORDER BY p.apellido ASC LIMIT $inicio, $registros";

			$consulta_total="SELECT COUNT(u.usua_codigo) FROM usuario u INNER JOIN persona p ON u.usua_codigo = p.usua_codigo_fk WHERE u.usua_codigo!='".$_SESSION['codigo']."' AND u.rol!='Administrador'";

		}

		$datos = $this->ejecutarConsulta($consulta_datos);
		$datos = $datos->fetchAll();
	
		$total = $this->ejecutarConsulta($consulta_total);
		$total = (int)$total->fetchColumn();
	
		$numeroPaginas = ceil($total / $registros);
	
		$tabla .= '
			<div class="table-container">
			<table class="table is-bordered is-striped is-narrow is-hoverable is-fullwidth">
				<thead>
					<tr>
						<th class="has-text-centered">#</th>
						<th class="has-text-centered">Nombre de Usuario</th>
						<th class="has-text-centered">Correo</th>
						<th class="has-text-centered">Rol</th>
						<th class="has-text-centered">Creado</th>
						<th class="has-text-centered">Actualizado</th>
						<th class="has-text-centered" colspan="3">Opciones</th>
					</tr>
				</thead>
				<tbody>
		';
	
		if ($total >= 1 && $pagina <= $numeroPaginas) {
			$contador = $inicio + 1;
			$pag_inicio = $inicio + 1;
			foreach ($datos as $filas) {
				$tabla .= '
					<tr class="has-text-centered">
						<td>' . $contador . '</td>
						<td>' . $filas['usua_usuario'] . '</td>
						<td>' . $filas['correo'] . '</td>
						<td>' . $filas['rol'] . '</td>
						<td>' . date("d-m-Y  h:i:s A", strtotime($filas['usuario_creado'])) . '</td>
						<td>' . date("d-m-Y  h:i:s A", strtotime($filas['usuario_actualizado'])) . '</td>
						<td>
							<a href="' . APP_URL . 'usuarioFoto/' . $filas['usua_codigo'] . '/" class="button is-info is-rounded is-small">Foto</a>
						</td>
						<td>
							<a href="' . APP_URL . 'usuarioActualizar/' . $filas['usua_codigo'] . '/" class="button is-success is-rounded is-small">Actualizar</a>
						</td>
						 <td>
			                	<form class="FormularioAjax" action="'.APP_URL.'app/ajax/administradorAjax.php" method="POST" autocomplete="off" >
			                		<input type="hidden" name="modulo_administrador" value="eliminar">
			                		<input type="hidden" name="usua_codigo" value="'.$filas['usua_codigo'].'">

			                    	<button type="submit" class="button is-danger is-rounded is-small">Eliminar</button>
			                    </form>
			                </td>
					</tr>
				';
				$contador++;
			}
			$pag_final = $contador - 1;
		} else {
			if ($total >= 1) {
				$tabla .= '
					<tr class="has-text-centered">
						<td colspan="7">
							<a href="' . $url . '1/" class="button is-link is-rounded is-small mt-4 mb-4">
								Haga clic acá para recargar el listado
							</a>
						</td>
					</tr>
				';
			} else {
				$tabla .= '
					<tr class="has-text-centered">
						<td colspan="7">
							No hay registros en el sistema
						</td>
					</tr>
				';
			}
		}
	
		$tabla .= '</tbody></table></div>';
	
		if ($total > 0 && $pagina <= $numeroPaginas) {
			$tabla .= '<p class="has-text-right">Mostrando usuarios <strong>' . $pag_inicio . '</strong> al <strong>' . $pag_final . '</strong> de un <strong>total de ' . $total . '</strong></p>';
			$tabla .= $this->paginadorTablas($pagina, $numeroPaginas, $url, 7);
		}
		return $tabla;
	}

	public function listarPersona($pagina, $registros, $url) {
		if ($_SESSION['rol'] != "Administrador") {
			session_destroy();
			header("Location: " . APP_URL . "app/views/content/404-vista");
			exit();
		}
	
		$pagina = $this->limpiarCadena($pagina);
		$registros = $this->limpiarCadena($registros);
		$url = $this->limpiarCadena($url);
		$url = APP_URL . $url . "/";
	
		$tabla = "";
	
		$pagina = (isset($pagina) && $pagina > 0) ? (int)$pagina : 1;
		$inicio = ($pagina > 0) ? (($pagina * $registros) - $registros) : 0;

		$consulta_datos = "SELECT * FROM persona p INNER JOIN usuario u ON p.usua_codigo_fk = u.usua_codigo WHERE p.usua_codigo_fk != '".$_SESSION['codigo']."' AND p.usua_codigo_fk != '1' ORDER BY p.apellido ASC LIMIT $inicio, $registros;";
	
		$consulta_total = "SELECT COUNT(usua_codigo_fk) FROM persona p INNER JOIN usuario u ON p.usua_codigo_fk = u.usua_codigo WHERE p.usua_codigo_fk != '".$_SESSION['codigo']."' AND p.usua_codigo_fk != '1';";
	
		$datos = $this->ejecutarConsulta($consulta_datos);
		$datos = $datos->fetchAll();
	
		$total = $this->ejecutarConsulta($consulta_total);
		$total = (int)$total->fetchColumn();
	
		$numeroPaginas = ceil($total / $registros);
	
		$tabla .= '
			<div class="table-container">
			<table class="table is-bordered is-striped is-narrow is-hoverable is-fullwidth">
				<thead>
					<tr>
						<th class="has-text-centered">#</th>
						<th class="has-text-centered">Nombres y Apellidos</th>
						<th class="has-text-centered">ID</th>
						<th class="has-text-centered">Tipo ID</th>
						<th class="has-text-centered">Edad</th>
						<th class="has-text-centered">Sexo</th>
						<th class="has-text-centered">Celular</th>
						<th class="has-text-centered">Dirección</th>
						<th class="has-text-centered">Teléfono 2</th>
					</tr>
				</thead>
				<tbody>
		';
	
		if ($total >= 1 && $pagina <= $numeroPaginas) {
			$contador = $inicio + 1;
			$pag_inicio = $inicio + 1;
			foreach ($datos as $filas) {
				$tabla .= '
					<tr class="has-text-centered">
						<td>' . $contador . '</td>
						<td>' . $filas['nombre'] . ' ' . $filas['apellido'] . '</td>
						<td>' . $filas['identificacion'] . '</td>
						<td>' . $filas['tipoID'] . '</td>
						<td>' . $filas['edad'] . '</td>
						<td>' . $filas['sexo'] . '</td>
						<td>' . $filas['celular'] . '</td>
						<td>' . $filas['direccion'] . '</td>
						<td>' . $filas['telef2'] . '</td>
					</tr>
				';
				$contador++;
			}
			$pag_final = $contador - 1;
		} else {
			if ($total >= 1) {
				$tabla .= '
					<tr class="has-text-centered">
						<td colspan="9">
							<a href="' . $url . '1/" class="button is-link is-rounded is-small mt-4 mb-4">
								Haga clic acá para recargar el listado
							</a>
						</td>
					</tr>
				';
			} else {
				$tabla .= '
					<tr class="has-text-centered">
						<td colspan="9">
							No hay registros en el sistema
						</td>
					</tr>
				';
			}
		}
	
		$tabla .= '</tbody></table></div>';
	
		### Paginación ###
		if ($total > 0 && $pagina <= $numeroPaginas) {
			$tabla .= '<p class="has-text-right">Mostrando usuarios <strong>' . $pag_inicio . '</strong> al <strong>' . $pag_final . '</strong> de un <strong>total de ' . $total . '</strong></p>';
			$tabla .= $this->paginadorTablas($pagina, $numeroPaginas, $url, 9);
		}
	
		return $tabla;
	}

	public function registrarAdministrador($usua_codigo_fk, $personaCodigo_fk, $conexion) {
		if (empty($usua_codigo_fk) || empty($personaCodigo_fk) || !is_numeric($usua_codigo_fk) || !is_numeric($personaCodigo_fk)) {
			$alerta = [
				"tipo" => "simple",
				"titulo" => "Ocurrió un error inesperado",
				"texto" => "Datos de entrada inválidos para registrar al Administrador",
				"icono" => "error"
			];
			return json_encode($alerta);
		}
		
		$admin_datos_reg = [
			[
				"campo_nombre" => "usua_codigo_fk",
				"campo_marcador" => ":UsuarioID_fk",
				"campo_valor" => $usua_codigo_fk
			],
			[
				"campo_nombre" => "personaCodigo_fk",
				"campo_marcador" => ":PersonaID_fk",
				"campo_valor" => $personaCodigo_fk
			]
		];
	
		$registrar_administrador = $this->guardarDatos("Administrador", $admin_datos_reg, $conexion);

	}

	public function registrarEspecialista($usua_codigo_fk, $personaCodigo_fk, $especialidadCodigo_fk, $conexion) {
		if (empty($usua_codigo_fk) || empty($personaCodigo_fk) || empty($especialidadCodigo_fk) || 
			!is_numeric($usua_codigo_fk) || !is_numeric($personaCodigo_fk) || !is_numeric($especialidadCodigo_fk)) {
			$alerta = [
				"tipo" => "simple",
				"titulo" => "Ocurrió un error inesperado",
				"texto" => "Datos de entrada inválidos para registrar al especialista.",
				"icono" => "error"
			];
			return json_encode($alerta);
		}
	
		$especialista_datos_reg = [
			[
				"campo_nombre" => "usua_codigo_fk",
				"campo_marcador" => ":UsuarioID_fk",
				"campo_valor" => $usua_codigo_fk
			],
			[
				"campo_nombre" => "personaCodigo_fk",
				"campo_marcador" => ":PersonaID_fk",
				"campo_valor" => $personaCodigo_fk
			],
			[
				"campo_nombre" => "especialidadCodigo_fk",
				"campo_marcador" => ":EspecialidadID_fk",
				"campo_valor" => $especialidadCodigo_fk
			]
		];
	
		$guardar_especialista = $this->guardarDatos("Especialista", $especialista_datos_reg, $conexion);
	
		if ($guardar_especialista->rowCount() != 1) {
			$alerta = [
				"tipo" => "simple",
				"titulo" => "Ocurrió un error inesperado",
				"texto" => "No se pudo registrar al Especialista, por favor intente nuevamente",
				"icono" => "error"
			];
			return json_encode($alerta);
		}
	
		$especialistaCodigo = $conexion->lastInsertId();
		$this->registrarDisponibilidadEspecialista($especialistaCodigo, $especialidadCodigo_fk, $conexion);
	}

	public function registrarDisponibilidadEspecialista($especialistaCodigo, $especialidadCodigo_fk, $conexion) {
        $especialistaCodigo_fk = $especialistaCodigo;
        $especialidad = $this->obtenerDetallesEspecialidad($especialidadCodigo_fk, $conexion);
    
        if (!$especialidad) { 
            $alerta = [ 
                "tipo" => "simple", 
                "titulo" => "Error en la disponibilidad", 
                "texto" => "No se pudo obtener la información de la especialidad", 
                "icono" => "error" 
            ]; 
            return json_encode($alerta); 
        } 
        
        $diaSemana = $especialidad['diaSemana']; 
        
        $duracion = $especialidad['duracion']; 
        
        list($horas, $minutos, $segundos) = explode(':', $duracion);
        
        $duracionEnMinutos = ($horas * 60) + $minutos + ($segundos / 60); 
        
        $duracionTotalMinutos = $duracionEnMinutos * 10; 
        
        $horaInicio = '07:00:00';
        
        $horaFin = date('H:i:s', strtotime($horaInicio) + ($duracionTotalMinutos * 60));
        
        $disponibilidad_datos = [
            [
                "campo_nombre" => "especialistaCodigo_fk",
                "campo_marcador" => ":EspecialistaID_fk",
                "campo_valor" => $especialistaCodigo_fk
            ],
            [
                "campo_nombre" => "diaSemana",
                "campo_marcador" => ":DiaSemana",
                "campo_valor" => $diaSemana
            ],
            [
                "campo_nombre" => "horaInicio",
                "campo_marcador" => ":HoraInicio",
                "campo_valor" => $horaInicio
            ],
            [
                "campo_nombre" => "horaFin",
                "campo_marcador" => ":HoraFin",
                "campo_valor" => $horaFin
            ]
        ];
    
        $guardar_disponibilidad = $this->guardarDatos("disponibilidadEspecialista", $disponibilidad_datos, $conexion);
    
        if ($guardar_disponibilidad->rowCount() != 1) {
            $alerta = [
                "tipo" => "simple",
                "titulo" => "Ocurrió un error inesperado",
                "texto" => "No se pudo registrar la disponibilidad, por favor intente nuevamente",
                "icono" => "error"
            ];
            return json_encode($alerta);
        }
    }

	public function listarEspecialista($pagina, $registros, $url, $busqueda) {
		if ($_SESSION['rol'] != "Administrador") {
				session_destroy();
				header("Location: " . APP_URL . "app/views/content/404-vista");
				exit();
		}
		
		$pagina = $this->limpiarCadena($pagina);
		$registros = $this->limpiarCadena($registros);
		$url = $this->limpiarCadena($url);
		$url = APP_URL . $url . "/";
		$busqueda = $this->limpiarCadena($busqueda);
		
		$tabla = "";
		
		$pagina = (isset($pagina) && $pagina > 0) ? (int)$pagina : 1;
		$inicio = ($pagina > 0) ? (($pagina * $registros) - $registros) : 0;
		
		if (isset($busqueda) && $busqueda != "") {
			
			$consulta_datos="SELECT * FROM Especialista especialista INNER JOIN Especialidad especialidad ON especialista.especialidadCodigo_fk = especialidad.especialidadCodigo INNER JOIN persona p ON especialista.personaCodigo_fk = p.personaCodigo INNER JOIN usuario u ON especialista.usua_codigo_fk = u.usua_codigo WHERE ((especialista.usua_codigo_fk!='".$_SESSION['codigo']."' AND especialista.usua_codigo_fk!='1' AND u.rol = 'Especialista') AND (p.nombre LIKE '%$busqueda%' OR p.apellido LIKE '%$busqueda%' OR u.usua_usuario LIKE '%$busqueda%' OR u.correo LIKE '%$busqueda%')) ORDER BY p.apellido ASC LIMIT $inicio,$registros";
	
			$consulta_total="SELECT COUNT(especialista.personaCodigo_fk) FROM Especialista especialista INNER JOIN Especialidad especialidad ON especialista.especialidadCodigo_fk = especialidad.especialidadCodigo INNER JOIN persona p ON especialista.personaCodigo_fk = p.personaCodigo INNER JOIN usuario u ON especialista.usua_codigo_fk = u.usua_codigo WHERE ((p.nombre LIKE '%$busqueda%' OR p.apellido LIKE '%$busqueda%' OR u.usua_usuario LIKE '%$busqueda%' OR u.correo LIKE '%$busqueda%' OR especialidad.especialidadNombre LIKE '%$busqueda%'))";
	
		}else{
	
			$consulta_datos="SELECT * FROM Especialista especialista INNER JOIN Especialidad especialidad ON especialista.especialidadCodigo_fk = especialidad.especialidadCodigo INNER JOIN persona p ON especialista.personaCodigo_fk = p.personaCodigo INNER JOIN usuario u ON especialista.usua_codigo_fk = u.usua_codigo WHERE especialista.usua_codigo_fk!='".$_SESSION['codigo']."' AND especialista.usua_codigo_fk!='1' AND u.rol = 'Especialista' ORDER BY p.apellido ASC LIMIT $inicio,$registros";
	
			$consulta_total="SELECT COUNT(especialista.personaCodigo_fk) FROM Especialista especialista INNER JOIN Especialidad especialidad ON especialista.especialidadCodigo_fk = especialidad.especialidadCodigo INNER JOIN persona p ON especialista.personaCodigo_fk = p.personaCodigo INNER JOIN usuario u ON especialista.usua_codigo_fk = u.usua_codigo WHERE especialista.usua_codigo_fk!='".$_SESSION['codigo']."' AND u.rol!='Especialista'";
	
		}
	
		$datos = $this->ejecutarConsulta($consulta_datos);
		$datos = $datos->fetchAll();
	
		$total = $this->ejecutarConsulta($consulta_total);
		$total = (int)$total->fetchColumn();
	
		$numeroPaginas = ceil($total / $registros);
	
		$tabla .= '
			<div class="table-container">
				<table class="table is-bordered is-striped is-narrow is-hoverable is-fullwidth">
					<thead>
						<tr>
							<th class="has-text-centered">#</th>
							<th class="has-text-centered">Nombres y Apellidos</th>
							<th class="has-text-centered">Nombre de Usuario</th>
							<th class="has-text-centered">Correo</th>
							<th class="has-text-centered">Especialidad</th>
							<th class="has-text-centered">ID</th>
							<th class="has-text-centered">Tipo ID</th>
							<th class="has-text-centered">Edad</th>
							<th class="has-text-centered">Sexo</th>
							<th class="has-text-centered">Celular</th>
							<th class="has-text-centered">Dirección</th>
							<th class="has-text-centered">Teléfono 2</th>
							<th class="has-text-centered">Historial Citas</th>
						</tr>
					</thead>
					<tbody>
		';
	
		if ($total >= 1 && $pagina <= $numeroPaginas) {
			$contador = $inicio + 1;
			$pag_inicio = $inicio + 1;
			foreach ($datos as $filas) {
				$tabla .= '
					<tr class="has-text-centered">
						<td>' . $contador . '</td>
						<td>' . $filas['nombre'] . ' ' . $filas['apellido'] . '</td>
						<td>' . $filas['usua_usuario'] . '</td>
						<td>' . $filas['correo'] . '</td>
						<td>' . $filas['especialidadNombre'] . '</td>
						<td>' . $filas['identificacion'] . '</td>
						<td>' . $filas['tipoID'] . '</td>
						<td>' . $filas['edad'] . '</td>
						<td>' . $filas['sexo'] . '</td>
						<td>' . $filas['celular'] . '</td>
						<td>' . $filas['direccion'] . '</td>
						<td>' . $filas['telef2'] . '</td>
						<td>
							<a href="' . APP_URL . 'historialCita/' . $filas['usua_codigo'] . '/" class="button is-info is-rounded is-small">Historial</a>
						</td>
					</tr>
				';
				$contador++;
			}
				
			$pag_final = $contador - 1;
	
		} else {
			if ($total >= 1) {
				$tabla .= '
					<tr class="has-text-centered">
						<td colspan="13">
							<a href="' . $url . '1/" class="button is-link is-rounded is-small mt-4 mb-4">
								Haga clic acá para recargar el listado
							</a>
						</td>
					</tr>
				';
			} else {
				$tabla .= '
					<tr class="has-text-centered">
						<td colspan="13">
							No hay registros en el sistema
						</td>
					</tr>
				';
			}
		}
	
		$tabla .= '</tbody></table></div>';
	
		if ($total > 0 && $pagina <= $numeroPaginas) {
			$tabla .= '<p class="has-text-right">Mostrando Pacientes <strong>' . $pag_inicio . '</strong> al <strong>' . $pag_final . '</strong> de un <strong>total de ' . $total . '</strong></p>';
			$tabla .= $this->paginadorTablas($pagina, $numeroPaginas, $url, 7);
		}
		return $tabla;
	}

	public function registrarPaciente($usua_codigo_fk, $personaCodigo_fk, $conexion) {
		if (empty($usua_codigo_fk) || empty($personaCodigo_fk) || !is_numeric($usua_codigo_fk) || !is_numeric($personaCodigo_fk)) {
				$alerta = [
					"tipo" => "simple",
					"titulo" => "Ocurrió un error inesperado",
					"texto" => "Datos de entrada inválidos para registrar al Paciente",
					"icono" => "error"
				];
				return json_encode($alerta);
		}
			
		$paciente_datos_reg = [
			[
				"campo_nombre" => "usua_codigo_fk",
				"campo_marcador" => ":UsuarioID_fk",
				"campo_valor" => $usua_codigo_fk
			],
			[
				"campo_nombre" => "personaCodigo_fk",
				"campo_marcador" => ":PersonaID_fk",
				"campo_valor" => $personaCodigo_fk
			]
		];
		
		$registrar_paciente = $this->guardarDatos("Paciente", $paciente_datos_reg, $conexion);
			
	}

	public function listarPaciente($pagina, $registros, $url, $busqueda) {
		if ($_SESSION['rol'] != "Administrador") {
			session_destroy();
			header("Location: " . APP_URL . "app/views/content/404-vista");
			exit();
		}
	
		$pagina = $this->limpiarCadena($pagina);
		$registros = $this->limpiarCadena($registros);
		$url = $this->limpiarCadena($url);
		$url = APP_URL . $url . "/";
		$busqueda = $this->limpiarCadena($busqueda);
	
		$tabla = "";
	
		$pagina = (isset($pagina) && $pagina > 0) ? (int)$pagina : 1;
		$inicio = ($pagina > 0) ? (($pagina * $registros) - $registros) : 0;
	
		if (isset($busqueda) && $busqueda != "") {
			
			$consulta_datos="SELECT * FROM paciente pa INNER JOIN persona pe ON pa.personaCodigo_fk = pe.personaCodigo INNER JOIN usuario u ON pa.usua_codigo_fk = u.usua_codigo WHERE ((pa.usua_codigo_fk!='".$_SESSION['codigo']."' AND pa.usua_codigo_fk!='1' AND u.rol = 'Paciente') AND (pe.nombre LIKE '%$busqueda%' OR pe.apellido LIKE '%$busqueda%' OR u.usua_usuario LIKE '%$busqueda%' OR u.correo LIKE '%$busqueda%')) ORDER BY pe.apellido ASC LIMIT $inicio,$registros";

			$consulta_total="SELECT COUNT(personaCodigo_fk) FROM paciente pa INNER JOIN persona pe ON pa.personaCodigo_fk = pe.personaCodigo INNER JOIN usuario u ON pa.usua_codigo_fk = u.usua_codigo WHERE ((pe.nombre LIKE '%$busqueda%' OR pe.apellido LIKE '%$busqueda%' OR u.usua_usuario LIKE '%$busqueda%' OR u.correo LIKE '%$busqueda%'))";

		}else{

			$consulta_datos="SELECT * FROM paciente pa INNER JOIN persona pe ON pa.personaCodigo_fk = pe.personaCodigo INNER JOIN usuario u ON pa.usua_codigo_fk = u.usua_codigo WHERE pa.usua_codigo_fk!='".$_SESSION['codigo']."' AND pa.usua_codigo_fk!='1' AND u.rol = 'Paciente' ORDER BY pe.apellido ASC LIMIT $inicio,$registros";

			$consulta_total="SELECT COUNT(personaCodigo_fk) FROM paciente pa INNER JOIN persona pe ON pa.personaCodigo_fk = pe.personaCodigo INNER JOIN usuario u ON pa.usua_codigo_fk = u.usua_codigo WHERE pa.usua_codigo_fk!='".$_SESSION['codigo']."' AND pa.usua_codigo_fk!='1'";

		}

		$datos = $this->ejecutarConsulta($consulta_datos);
		$datos = $datos->fetchAll();
	
		$total = $this->ejecutarConsulta($consulta_total);
		$total = (int)$total->fetchColumn();
	
		$numeroPaginas = ceil($total / $registros);
		
		$tabla .= '
		<div class="table-container">
			<table class="table is-bordered is-striped is-narrow is-hoverable is-fullwidth">
				<thead>
					<tr>
						<th class="has-text-centered">#</th>
						<th class="has-text-centered">Nombres y Apellidos</th>
						<th class="has-text-centered">Nombre de Usuario</th>
						<th class="has-text-centered">Correo</th>
						<th class="has-text-centered">ID</th>
						<th class="has-text-centered">Tipo ID</th>
						<th class="has-text-centered">Edad</th>
						<th class="has-text-centered">Sexo</th>
						<th class="has-text-centered">Celular</th>
						<th class="has-text-centered">Dirección</th>
						<th class="has-text-centered">Teléfono 2</th>
						<th class="has-text-centered">Historial Citas</th>
					</tr>
				</thead>
				<tbody>
		';

		if ($total >= 1 && $pagina <= $numeroPaginas) {
			$contador = $inicio + 1;
			$pag_inicio = $inicio + 1;
			foreach ($datos as $filas) {
				$tabla .= '
					<tr class="has-text-centered">
						<td>' . $contador . '</td>
						<td>' . $filas['nombre'] . ' ' . $filas['apellido'] . '</td>
						<td>' . $filas['usua_usuario'] . '</td>
						<td>' . $filas['correo'] . '</td>
						<td>' . $filas['identificacion'] . '</td>
						<td>' . $filas['tipoID'] . '</td>
						<td>' . $filas['edad'] . '</td>
						<td>' . $filas['sexo'] . '</td>
						<td>' . $filas['celular'] . '</td>
						<td>' . $filas['direccion'] . '</td>
						<td>' . $filas['telef2'] . '</td>
						<td>
							<a href="' . APP_URL . 'historialCita/' . $filas['usua_codigo'] . '/" class="button is-info is-rounded is-small">Historial</a>
						</td>
					</tr>
				';
				$contador++;
			}
				
			$pag_final = $contador - 1;
			
		} else {
			if ($total >= 1) {
				$tabla .= '
					<tr class="has-text-centered">
						<td colspan="12">
							<a href="' . $url . '1/" class="button is-link is-rounded is-small mt-4 mb-4">
								Haga clic acá para recargar el listado
							</a>
						</td>
					</tr>
				';
			} else {
				$tabla .= '
					<tr class="has-text-centered">
						<td colspan="12">
							No hay registros en el sistema
						</td>
					</tr>
				';
			}
		}
	
		$tabla .= '</tbody></table></div>';
	
		### Paginación ###
		
		if ($total > 0 && $pagina <= $numeroPaginas) {
			$tabla .= '<p class="has-text-right">Mostrando Pacientes <strong>' . $pag_inicio . '</strong> al <strong>' . $pag_final . '</strong> de un <strong>total de ' . $total . '</strong></p>';
			$tabla .= $this->paginadorTablas($pagina, $numeroPaginas, $url, 7);
		}
		return $tabla;
	}   

	public function actualizarUsuarioPersona(){

		$usua_codigo_fk = $this->limpiarCadena($_POST['usua_codigo']);

		$datos = $this->ejecutarConsulta("SELECT * FROM usuario u INNER JOIN persona pe ON u.usua_codigo = pe.usua_codigo_fk WHERE u.usua_codigo = '$usua_codigo_fk'");
			if($datos->rowCount()<=0){
				$alerta=[
					"tipo"=>"simple",
					"titulo"=>"Ocurrió un error inesperado",
					"texto"=>"No hemos encontrado el usuario en el sistema",
					"icono"=>"error"
				];
				return json_encode($alerta);
			}else{
				$datos=$datos->fetch();
				$usuarioAnterior = $datos['usua_usuario']; 
				$idAnterior = $datos['identificacion']; 
				$celularAnterior = $datos['celular']; 
			}

			$admin_usuario_correo=$this->limpiarCadena($_POST['administrador_usuario']);
			$admin_clave=$this->limpiarCadena($_POST['administrador_clave']);

			if($admin_usuario_correo=="" || $admin_clave==""){
				$alerta=[
					"tipo"=>"simple",
					"titulo"=>"Ocurrió un error inesperado",
					"texto"=>"No ha llenado todos los campos que son obligatorios, que corresponden a su 'USUARIO o CORREO' y 'CLAVE'",
					"icono"=>"error"
				];
				return json_encode($alerta);
			}

			if($this->verificarDatos("[a-zA-Z0-9\s@.]{8,35}",$admin_usuario_correo)){
				$alerta=[
					"tipo"=>"simple",
					"titulo"=>"Ocurrió un error inesperado",
					"texto"=>"Su USUARIO o CORREO de Administrador no coincide con el formato solicitado",
					"icono"=>"error"
				];
				return json_encode($alerta);
			}

			if($this->verificarDatos("[a-zA-Z0-9$@.-]{3,100}",$admin_clave)){
				$alerta=[
					"tipo"=>"simple",
					"titulo"=>"Ocurrió un error inesperado",
					"texto"=>"Su CLAVE de Administrador no coincide con el formato solicitado",
					"icono"=>"error"
				];
				return json_encode($alerta);
			}

			$consulta_admin=$this->ejecutarConsulta("SELECT * FROM administrador a INNER JOIN usuario u ON a.usua_codigo_fk = u.usua_codigo INNER JOIN persona pe ON a.personaCodigo_fk = pe.personaCodigo 
			WHERE (u.usua_usuario = '$admin_usuario_correo' OR u.correo = '$admin_usuario_correo') AND u.usua_codigo = '".$_SESSION['codigo']."'");
			
			if($consulta_admin->rowCount()==1){
				$consulta_admin=$consulta_admin->fetch();

				if ((!($consulta_admin['usua_usuario'] == $admin_usuario_correo || $consulta_admin['correo'] == $admin_usuario_correo)) || !password_verify($admin_clave, $consulta_admin['usua_clave'])) {
					$alerta=[
						"tipo"=>"simple",
						"titulo"=>"Ocurrió un error inesperado",
						"texto"=>"'USUARIO o CORREO' o 'CLAVE' de Administrador son incorrectos",
						"icono"=>"error"
					];
					return json_encode($alerta);
				}
			}else{
				$alerta=[
					"tipo"=>"simple",
					"titulo"=>"Ocurrió un error inesperado",
					"texto"=>"'USUARIO o CORREO' o 'CLAVE' de Administrador son incorrectos",
					"icono"=>"error"
				];
				return json_encode($alerta);
			}

			$nombreActual = $this->limpiarCadena($_POST['nombre']);
			$apellidoActual = $this->limpiarCadena($_POST['apellido']);
			$usuarioActual = $this->limpiarCadena($_POST['usua_usuario']);
			$correoActual = $this->limpiarCadena($_POST['correo']);
			$idActual = $this->limpiarCadena($_POST['identificacion']);
			$tipoIDActual = $this->limpiarCadena($_POST['tipoID']);
			$edadActual = $this->limpiarCadena($_POST['edad']);
			$celularActual = $this->limpiarCadena($_POST['celular']);
			$direccionActual = $this->limpiarCadena($_POST['direccion']);
			$telef2Actual = $this->limpiarCadena($_POST['telef2']);
			$clave1 = $this->limpiarCadena($_POST['usuario_clave_1']);
			$clave2 = $this->limpiarCadena($_POST['usuario_clave_2']);

			if($nombreActual=="" || $apellidoActual=="" || $usuarioActual=="" || $correoActual=="" || $idActual=="" || $tipoIDActual=="" || $edadActual=="" || $celularActual==""){
				$alerta=[
					"tipo"=>"simple",
					"titulo"=>"Ocurrió un error inesperado",
					"texto"=>"No has llenado todos los campos que son obligatorios",
					"icono"=>"error"
				];
				return json_encode($alerta);
			}

			if ($this->verificarDatos("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]{3,40}", $nombreActual) || $this->verificarDatos("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]{3,40}", $apellidoActual) ) {
				$alerta=[
					"tipo"=>"simple",
					"titulo"=>"Ocurrió un error inesperado",
					"texto"=>"Los NOMBRES o APELLIDOS no coinciden con el formato solicitado",
					"icono"=>"error"
				];
				return json_encode($alerta);
			}

			if ($correoActual != "" && $correoActual != $datos['correo']) {
				if(filter_var($correoActual, FILTER_VALIDATE_EMAIL)){
					$check_correo=$this->ejecutarConsulta("SELECT correo FROM usuario WHERE correo='$correoActual'");
					if($check_correo->rowCount()>0){
						$alerta=[
							"tipo"=>"simple",
							"titulo"=>"Ocurrió un error inesperado",
							"texto"=>"El CORREO que acaba de ingresar ya se encuentra registrado en el sistema, por favor verifique e intente nuevamente",
							"icono"=>"error"
						];
						return json_encode($alerta);
					}
				}else{
					$alerta=[
						"tipo"=>"simple",
						"titulo"=>"Ocurrió un error inesperado",
						"texto"=>"Ha ingresado un correo electrónico no valido",
						"icono"=>"error"
					];
					return json_encode($alerta);
				}
			}

			if ($this->verificarDatos("[a-zA-Z0-9\s ]{8,35}", $usuarioActual)) {
				$alerta=[
					"tipo"=>"simple",
					"titulo"=>"Ocurrió un error inesperado",
					"texto"=>"El NOMBRE DE USUARIO no coincide con el formato solicitado",
					"icono"=>"error"
				];
				return json_encode($alerta);
			}

			if($usuarioAnterior != $usuarioActual){
				$consulta_usuario = $this->ejecutarConsulta("SELECT usua_usuario FROM usuario WHERE usua_usuario='$usuarioActual'");
				if($consulta_usuario->rowCount()>0){
					$alerta=[
						"tipo"=>"simple",
						"titulo"=>"Ocurrió un error inesperado",
						"texto"=>"El USUARIO ingresado ya se encuentra registrado, por favor elija otro",
						"icono"=>"error"
					];
					return json_encode($alerta);
					
				}
			}

			if ($this->verificarDatos("[0-9]{8,13}", $idActual)) {
				$alerta=[
					"tipo"=>"simple",
					"titulo"=>"Ocurrió un error inesperado",
					"texto"=>"El NÚMERO DE IDENTIFICACIÓN no coincide con el formato solicitado",
					"icono"=>"error"
				];
				return json_encode($alerta);
			}

			if ($idAnterior !== $idActual) {
				$consulta_personaID = $this->ejecutarConsulta("SELECT identificacion FROM persona WHERE identificacion = '$idActual'");
				if ($consulta_personaID->rowCount() > 0) {
					$alerta = [
						"tipo" => "simple",
						"titulo" => "Ocurrió un error inesperado",
						"texto" => "El NÚMERO DE IDENTIFICACIÓN ingresado ya se encuentra registrado, verifique que el Usuario le haya proporcionado el Número de Identificación correcto o cancele la Actualización",
						"icono" => "error"
					];
					return json_encode($alerta);
				}
			}

			if ($this->verificarDatos("[0-9]{1,2}", $edadActual)) {
				$alerta = [
					"tipo" => "simple",
					"titulo" => "Ocurrió un error inesperado",
					"texto" => "La EDAD no coincide con el formato solicitado",
					"icono" => "error"
				];
				return json_encode($alerta);
			}

			if ($this->verificarDatos("[0-9]{10}", $celularActual)) {
				$alerta=[
					"tipo"=>"simple",
					"titulo"=>"Ocurrió un error inesperado",
					"texto"=>"El CELULAR no coincide con el formato solicitado",
					"icono"=>"error"
				];
				return json_encode($alerta);
			}

			if ($celularActual !== $celularAnterior) {
				$consulta_personaCelular = $this->ejecutarConsulta("SELECT celular FROM persona WHERE celular = '$celularActual'");
				if ($consulta_personaCelular->rowCount() > 0) {
					$alerta = [
						"tipo" => "simple",
						"titulo" => "Ocurrió un error inesperado",
						"texto" => "El NÚMERO CELULAR ingresado ya se encuentra registrado, verifique que el Usuario le haya proporcionado el Número de Celular correcto o cancele la Actualización",
						"icono" => "error"
					];
					return json_encode($alerta);
					
				}
			}

			if (!empty($telef2Actual)) {
				if ($this->verificarDatos("[0-9]{10}", $telef2Actual)) {
					$alerta = [
						"tipo" => "simple",
						"titulo" => "Ocurrió un error inesperado",
						"texto" => "El NÚMERO DE TELÉFONO 2 no coincide con el formato solicitado",
						"icono" => "error"
					];
					return json_encode($alerta);
				}
			
				$consulta_persona_Telef2 = $this->ejecutarConsulta("SELECT telef2 FROM persona WHERE telef2='$telef2Actual'");
				if ($consulta_persona_Telef2->rowCount() > 0) {
					$alerta = [
						"tipo" => "simple",
						"titulo" => "Ocurrió un error inesperado",
						"texto" =>  "El NÚMERO DE TELÉFONO 2 ingresado ya se encuentra registrado, verifique que el Usuario le haya proporcionado el Número de Teléfono 2 correcto o cancele la Actualización",
						"icono" => "error"
					];
					return json_encode($alerta);
				}
			}
			
			if (!empty($direccionActual)){
				if($this->verificarDatos("^[a-zA-Z0-9\s#\\-]{10,100}$", $direccionActual)){
					$alerta = [
						"tipo" => "simple",
						"titulo" => "Ocurrió un error inesperado",
						"texto" => "La DIRECCIÓN no coincide con el formato solicitado",
						"icono" => "error"
					];
					return json_encode($alerta);
				}
			}  

			if (($edadActual < 18 && $tipoIDActual == "CC") || ($edadActual >= 18 && $tipoIDActual == "TI")) {
				$alerta = [
					"tipo" => "simple",
					"titulo" => "Ocurrió un error inesperado",
					"texto" => $edadActual < 18 
						? "Al ser menor de edad debe seleccionar 'Tarjeta de Identidad', no 'Cédula de Ciudadanía'" 
						: "Al ser mayor de edad debe seleccionar 'Cédula de Ciudadanía', no 'Tarjeta de Identidad'",
					"icono" => "error"
				];
				return json_encode($alerta);
			}

			if($clave1!="" || $clave2!=""){
            	if($this->verificarDatos("[a-zA-Z0-9$@.-]{3,100}",$clave1) || $this->verificarDatos("[a-zA-Z0-9$@.-]{3,100}",$clave2)){
			        $alerta=[
						"tipo"=>"simple",
						"titulo"=>"Ocurrió un error inesperado",
						"texto"=>"Las CLAVES no coinciden con el aa solicitado",
						"icono"=>"error"
					];
					return json_encode($alerta);
			        
			    }else{
			    	if($clave1!=$clave2){
						$alerta=[
							"tipo"=>"simple",
							"titulo"=>"Ocurrió un error inesperado",
							"texto"=>"Las nuevas CLAVES que acaba de ingresar no coinciden, por favor verifique e intente nuevamente",
							"icono"=>"error"
						];
						return json_encode($alerta);
						
			    	}else{
			    		$clave=password_hash($clave1,PASSWORD_BCRYPT,["cost"=>10]);
			    	}
			    }
			}else{
				$clave=$datos['usua_clave'];
            }

			try {
				$usuario_datos_up = [
					[
						"campo_nombre" => "usua_usuario",
						"campo_marcador" => ":Usuario",
						"campo_valor" => $usuarioActual
					],
					[
						"campo_nombre" => "correo",
						"campo_marcador" => ":Correo",
						"campo_valor" => $correoActual
					],
					[
						"campo_nombre" => "usua_clave",
						"campo_marcador" => ":Clave",
						"campo_valor" => $clave
					],
					[
						"campo_nombre" => "usuario_actualizado",
						"campo_marcador" => ":Actualizado",
						"campo_valor" => date("Y-m-d H:i:s")
					]
				];
			
				$condicionUsuario = [
					"condicion_campo" => "usua_codigo",
					"condicion_marcador" => ":UsuarioID",
					"condicion_valor" => $usua_codigo_fk
				];
			
			
				if (!$this->actualizarDatos("usuario", $usuario_datos_up, $condicionUsuario)) {
					throw new \Exception("No se pudieron actualizar los datos del usuario " . $datos['usua_usuario']);
				}

				$persona_datos_up = [
					[
						"campo_nombre" => "identificacion",
						"campo_marcador" => ":IDPersona",
						"campo_valor" => $idActual
					],
					[
						"campo_nombre" => "tipoID",
						"campo_marcador" => ":TipoID",
						"campo_valor" => $tipoIDActual
					],
					[
						"campo_nombre" => "nombre",
						"campo_marcador" => ":Nombre",
						"campo_valor" => $nombreActual
					],
					[
						"campo_nombre" => "apellido",
						"campo_marcador" => ":Apellido",
						"campo_valor" => $apellidoActual
					],
					[
						"campo_nombre" => "edad",
						"campo_marcador" => ":Edad",
						"campo_valor" => $edadActual
					],
					[
						"campo_nombre" => "celular",
						"campo_marcador" => ":Celular",
						"campo_valor" => $celularActual
					],
					[
						"campo_nombre" => "direccion",
						"campo_marcador" => ":Direccion",
						"campo_valor" => $direccionActual
					],
					[
						"campo_nombre" => "telef2",
						"campo_marcador" => ":Telefono2",
						"campo_valor" => $telef2Actual
					]
				];
			
				$condicionPersona = [
					"condicion_campo" => "usua_codigo_fk",
					"condicion_marcador" => ":UsuarioIDPersona", 
					"condicion_valor" => $usua_codigo_fk
				];
			
				if (!$this->actualizarDatos("Persona", $persona_datos_up, $condicionPersona)) {
					throw new \Exception("No se pudieron actualizar los datos de la persona");
				}

        		if ($usua_codigo_fk == $_SESSION['codigo']) {
        	    $_SESSION['usuario'] = $usuarioActual;
        	    $_SESSION['correo'] = $correoActual;
				$_SESSION['nombre'] = $nombreActual;
				$_SESSION['apellido'] = $apellidoActual;
			}

			$alerta = [
				"tipo" => "recargar",
				"titulo" => "Datos de Usuario y Persona actualizados",
				"texto" => "Los datos del Usuario " . $usuarioActual . " asociados a " . $nombreActual . " " . $apellidoActual . " se actualizaron correctamente",
				"icono" => "success"
			];
			return json_encode($alerta);
			
    		} catch (\Exception $e) {
    		    $alerta = [
    		        "tipo" => "simple",
    		        "titulo" => "Ocurrió un error inesperado",
    		        "texto" => $e->getMessage(),
    		        "icono" => "error"
    		    ];
    		    return json_encode($alerta);
    		}
	}

	public function eliminarUsuarioPersona(){

		$usua_codigo_fk=$this->limpiarCadena($_POST['usua_codigo']);

		if($usua_codigo_fk==1){
			$alerta=[
				"tipo"=>"simple",
				"titulo"=>"Ocurrió un error inesperado",
				"texto"=>"No podemos eliminar el usuario principal del sistema",
				"icono"=>"error"
			];
			return json_encode($alerta);
			exit();
		}

		$datos=$this->ejecutarConsulta("SELECT * FROM usuario u INNER JOIN persona pe ON u.usua_codigo = pe.usua_codigo_fk WHERE u.usua_codigo='$usua_codigo_fk'");
		if($datos->rowCount()<=0){
			$alerta=[
				"tipo"=>"simple",
				"titulo"=>"Ocurrió un error inesperado",
				"texto"=>"No hemos encontrado el usuario en el sistema",
				"icono"=>"error"
			];
			return json_encode($alerta);
			exit();
		}else{
			$datos=$datos->fetch();
		}

		$eliminarUsuario=$this->eliminarRegistro("Usuario","usua_codigo",$usua_codigo_fk);

		if($eliminarUsuario->rowCount()==1){
			if(is_file("../views/fotos/".$datos['usuario_foto'])){
				chmod("../views/fotos/".$datos['usuario_foto'],0777);
				unlink("../views/fotos/".$datos['usuario_foto']);
			}

			$alerta=[
				"tipo"=>"recargar",
				"titulo"=>"Usuario eliminado",
				"texto"=>"El usuario ".$datos['usua_usuario']." ha sido eliminado del sistema correctamente",
				"icono"=>"success"
			];
		}else{
			$alerta=[
				"tipo"=>"simple",
				"titulo"=>"Ocurrió un error inesperado",
				"texto"=>"No hemos podido eliminar el usuario ".$datos['usua_usuario']." del sistema, por favor intente nuevamente",
				"icono"=>"error"
			];
		}
		return json_encode($alerta);
	}

	public function registrarEspecialidad() {
		$nombre = $this->limpiarCadena($_POST['especialidadNombre']);
		$descripcion = $this->limpiarCadena($_POST['descripcion']);
		$duracion = $_POST['duracion']; 
		$costo = $this->limpiarCadena($_POST['costo']);
		$diaSemana = $this->limpiarCadena($_POST['diaSemana']);
	
		if ($nombre == "" || $descripcion == "" || $duracion == "" || $costo == "" || $diaSemana == "") {
			$alerta = [
				"tipo" => "simple",
				"titulo" => "Ocurrió un error inesperado",
				"texto" => "No has llenado todos los campos obligatorios para la Especialidad",
				"icono" => "error"
			];
			return json_encode($alerta);
		}
	
		if ($this->verificarDatos("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]{5,30}", $nombre)) {
			$alerta = [
				"tipo" => "simple",
				"titulo" => "Ocurrió un error inesperado",
				"texto" => "El NOMBRE DE LA ESPECIALIDAD no coincide con el formato solicitado",
				"icono" => "error"
			];
			return json_encode($alerta);
		}	
		
		$consulta_nombre = $this->ejecutarConsulta("SELECT especialidadNombre FROM especialidad WHERE especialidadNombre='$nombre'");
		if ($consulta_nombre->rowCount() > 0) {
			$alerta = [
				"tipo" => "simple",
				"titulo" => "Ocurrió un error inesperado",
				"texto" => "El NOMBRE DE LA ESPECIALIDAD ya está registrado",
				"icono" => "error"
			];
			return json_encode($alerta);
		}
	
		if (strlen($descripcion) > 255) {
			$alerta = [
				"tipo" => "simple",
				"titulo" => "Ocurrió un error inesperado",
				"texto" => "La DESCRIPCIÓN no debe exceder los 255 caracteres",
				"icono" => "error"
			];
			return json_encode($alerta);
		}

		$consulta_descripcion = $this->ejecutarConsulta("SELECT descripcion FROM especialidad WHERE descripcion='$descripcion'");
		if ($consulta_descripcion->rowCount() > 0) {
			$alerta=[
				"tipo"=>"simple",
				"titulo"=>"Ocurrió un error inesperado",
				"texto"=>"La DESCRIPCIÓN DE LA ESPECIALIDAD ingresada ya se encuentra registrada, verifique que la descripción sea la correcta",
				"icono"=>"error"
			];
			return json_encode($alerta);
		}
	
		if (!preg_match("/^([01][0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]$/", $duracion)) {
			$alerta = [
				"tipo" => "simple",
				"titulo" => "Ocurrió un error inesperado",
				"texto" => "La DURACIÓN no tiene el formato correcto (HH:MM:SS)",
				"icono" => "error"
			];
			return json_encode($alerta);
		}
				
		if ($costo <= 0) {
			$alerta = [
				"tipo" => "simple",
				"titulo" => "Ocurrió un error inesperado",
				"texto" => "El COSTO debe ser un valor mayor a 0",
				"icono" => "error"
			];
			return json_encode($alerta);
		}

		$diasValidos = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];

		$diasIngresados = array_map('trim', explode(',', $diaSemana));

		foreach ($diasIngresados as $dia) {
		    if (!in_array($dia, $diasValidos)) {
		        $alerta = [
		            "tipo" => "simple",
		            "titulo" => "Ocurrió un error inesperado",
		            "texto" => "Uno o más de los días ingresados no son válidos. Asegúrate de ingresar días reales.",
		            "icono" => "error"
		        ];
		        return json_encode($alerta);
		    }
		}	

		// Directorio de imágenes
		$img_dir = "../views/fotos/";
		// Comprobar si se selecciona una imagen
		if($_FILES['especialidad_foto']['name']!="" && $_FILES['especialidad_foto']['size']>0){
	
			# Creando directorio #
			if(!file_exists($img_dir)){
				if(!mkdir($img_dir,0777)){
					$alerta=[
					 "tipo"=>"simple",
					 "titulo"=>"Ocurrió un error inesperado",
					 "texto"=>"Error al crear el directorio",
					 "icono"=>"error"
					];
					return json_encode($alerta);
			 	} 
			}
	
			# Verificando formato de imagenes #
			if(mime_content_type($_FILES['especialidad_foto']['tmp_name'])!="image/jpeg" && mime_content_type($_FILES['especialidad_foto']['tmp_name'])!="image/png"){
				$alerta=[
					"tipo"=>"simple",
					"titulo"=>"Ocurrió un error inesperado",
					"texto"=>"La imagen que ha seleccionado es de un formato no permitido",
					"icono"=>"error"
				];
				return json_encode($alerta);
			}

			# Verificando peso de imagen #
			if(($_FILES['especialidad_foto']['size']/1024)>5120){
				$alerta=[
				 "tipo"=>"simple",
				 "titulo"=>"Ocurrió un error inesperado",
				 "texto"=>"La imagen que ha seleccionado supera el peso permitido",
				 "icono"=>"error"
				];
				return json_encode($alerta); 
			}

			# Nombre de la foto #
			$foto=str_ireplace(" ","_",$nombre);
			$foto=$foto."_".rand(0,100);

			# Extension de la imagen #
			switch(mime_content_type($_FILES['especialidad_foto']['tmp_name'])){
				case 'image/jpeg':
					$foto=$foto.".jpg";
			break;
				case 'image/png':
					$foto=$foto.".png";
			break;
			}

			chmod($img_dir,0777);

			# Moviendo imagen al directorio #
			if(!move_uploaded_file($_FILES['especialidad_foto']['tmp_name'],$img_dir.$foto)){
				$alerta=[
				 "tipo"=>"simple",
				 "titulo"=>"Ocurrió un error inesperado",
				 "texto"=>"No podemos subir la imagen al sistema en este momento",
				 "icono"=>"error"
				];
				return json_encode($alerta);
			}

		}else{
			$foto="";
		}	
	
		try {
			
			$conexion = $this->conectar();
	
			$especialidad_datos_reg = [
				[
					"campo_nombre" => "especialidadNombre",
					"campo_marcador" => ":Nombre",
					"campo_valor" => $nombre
				],
				[
					"campo_nombre" => "descripcion",
					"campo_marcador" => ":Descripcion",
					"campo_valor" => $descripcion
				],
				[
					"campo_nombre" => "duracion", 
					"campo_marcador" => ":Duracion",
					"campo_valor" => $duracion
				],
				[
					"campo_nombre" => "costo",
					"campo_marcador" => ":Costo",
					"campo_valor" => $costo
				],
				[
					"campo_nombre" => "diaSemana",
					"campo_marcador" => ":Dia",
					"campo_valor" => $diaSemana
				],
				[
					"campo_nombre" => "especialidad_foto",
					"campo_marcador" => ":Foto",
					"campo_valor" => $foto
				],
				[
					"campo_nombre" => "especialidad_creada",
					"campo_marcador" => ":Creada",
					"campo_valor" => date("Y-m-d H:i:s")
				],
				[
					"campo_nombre" => "especialidad_actualizada",
					"campo_marcador" => ":Actualizada",
					"campo_valor" => date("Y-m-d H:i:s")
				]
			];
				
			$guardar_especialidad = $this->guardarDatos("Especialidad", $especialidad_datos_reg, $conexion);

			if ($guardar_especialidad->rowCount() == 1) {
				$alerta = [
					"tipo" => "simple",
					"titulo" => "Registro extoso",
					"texto" => "La Especialidad '".$nombre."' se ha registrado exitosamente",
					"icono" => "success"
				];
				return json_encode($alerta);
			}elseif($guardar_especialidad->rowCount() <= 0){
				$alerta = [
					"tipo" => "simple",
					"titulo" => "Error",
					"texto" => "No se pudo registrar la Especialidad '".$nombre."' por favor intente nuevamente",
					"icono" => "error"
				];
				return json_encode($alerta);
			}else{
				$alerta = [
					"tipo" => "simple",
					"titulo" => "Error",
					"texto" => "No se pudo registrar la Especialidad, por favor intente nuevamente",
					"icono" => "error"
				];
				return json_encode($alerta);
			}	
		} catch (\Exception $e) {
			$alerta = [
				"tipo" => "simple",
				"titulo" => "Error",
				"texto" => $e->getMessage(),
				"icono" => "error"
			];
			return json_encode($alerta);
		}
	}

	public function listarEspecialidad($pagina, $registros, $url, $busqueda) {
	    if ($_SESSION['rol'] != "Administrador") {
	    		session_destroy();
	    		header("Location: " . APP_URL . "app/views/content/404-vista");
	    		exit();
	    }

	    $pagina = $this->limpiarCadena($pagina);
	    $registros = $this->limpiarCadena($registros);
	    $url = $this->limpiarCadena($url);
	    $url = APP_URL . $url . "/";
	    $busqueda = $this->limpiarCadena($busqueda);
		
	    $tabla = "";
		
	    $pagina = (isset($pagina) && $pagina > 0) ? (int)$pagina : 1;
	    $inicio = ($pagina > 0) ? (($pagina * $registros) - $registros) : 0;
    
	    if (isset($busqueda) && $busqueda != "") {
        
	    $consulta_datos="SELECT * FROM especialidad WHERE ((especialidadNombre LIKE '%$busqueda%' OR descripcion LIKE '%$busqueda%' OR costo LIKE '%$busqueda%' OR diaSemana LIKE '%$busqueda%')) ORDER BY especialidadNombre ASC LIMIT $inicio, $registros";
    
	    $consulta_total="SELECT COUNT(especialidadCodigo) FROM especialidad WHERE ((especialidadNombre LIKE '%$busqueda%' OR descripcion LIKE '%$busqueda%' OR costo LIKE '%$busqueda%' OR diaSemana LIKE '%$busqueda%'))";
        
	    }else{
			
	    	$consulta_datos="SELECT * FROM especialidad ORDER BY especialidadNombre ASC LIMIT $inicio,$registros";
		
	    	$consulta_total="SELECT COUNT(especialidadCodigo) FROM especialidad";
			
	    }
    
	    $datos = $this->ejecutarConsulta($consulta_datos);
	    $datos = $datos->fetchAll();
		
	    $total = $this->ejecutarConsulta($consulta_total);
	    $total = (int)$total->fetchColumn();
		
	    $numeroPaginas = ceil($total / $registros);
		
	    $tabla .= '
			<div class="table-container">
	    		<table class="table is-bordered is-striped is-narrow is-hoverable is-fullwidth">
	    			<thead>
	    				<tr>
	    					<th class="has-text-centered">#</th>
	    					<th class="has-text-centered">Nombres de la Especialidad</th>
	    					<th class="has-text-centered">Descripción</th>
	    					<th class="has-text-centered">Duración</th>
	    					<th class="has-text-centered">Costo</th>
	    					<th class="has-text-centered">Día(s) en que se realiza</th>
							<th class="has-text-centered">Creado</th>
							<th class="has-text-centered">Actualizado</th>
	    					<th class="has-text-centered" colspan="4">Opciones</th>
	    				</tr>
	    			</thead>
	    			<tbody>
	    ';
    
	    if ($total >= 1 && $pagina <= $numeroPaginas) {
	    	$contador = $inicio + 1;
	    	$pag_inicio = $inicio + 1;
	    	foreach ($datos as $filas) {
	    		$tabla .= '
	    			<tr class="has-text-centered">
	    				<td>' . $contador . '</td>
	    				<td>' . $filas['especialidadNombre'] . '</td>
	    				<td>' . $filas['descripcion'] . '</td>
	    				<td>' . $filas['duracion'] . '</td>
	    				<td>' . $filas['costo'] . '</td>
	    				<td>' . $filas['diaSemana'] . '</td>
						<td>' . $filas['especialidad_creada'] . '</td>
						<td>' . $filas['especialidad_actualizada'] . '</td>
	    				<td>
	    					<a href="' . APP_URL . 'especialidadFoto/' . $filas['especialidadCodigo'] . '/" class="button is-info is-rounded is-small">Historial</a>
	    				</td>
	    				<td>
	    					<a href="' . APP_URL . 'especialidadFoto/' . $filas['especialidadCodigo'] . '/" class="button is-info is-rounded is-small">Foto</a>
	    				</td>
	    				<td>
	    					<a href="' . APP_URL . 'especialidadActualizar/' . $filas['especialidadCodigo'] . '/" class="button is-success is-rounded is-small">Actualizar</a>
	    				</td>
	    				 <td>
	    	                	<form class="FormularioAjax" action="'.APP_URL.'app/ajax/especialidadAjax.php" method="POST" autocomplete="off" >
            
	    	                		<input type="hidden" name="modulo_especialidad" value="eliminar">
	    	                		<input type="hidden" name="especialidadCodigo" value="'.$filas['especialidadCodigo'].'">
            
	    	                    	<button type="submit" class="button is-danger is-rounded is-small">Eliminar</button>
	    	                    </form>
	    	                </td>
	    			</tr>
	    		';
	    		$contador++;
	    	}
	    	
			$pag_final = $contador - 1;

		} else {
	    	if ($total >= 1) {
	    		$tabla .= '
	    			<tr class="has-text-centered">
	    				<td colspan="9">
	    					<a href="' . $url . '1/" class="button is-link is-rounded is-small mt-4 mb-4">
	    						Haga clic acá para recargar el listado
	    					</a>
	    				</td>
	    			</tr>
	    		';
	    	} else {
	    		$tabla .= '
	    			<tr class="has-text-centered">
	    				<td colspan="9">
	    					No hay registros en el sistema
	    				</td>
	    			</tr>
	    		';
	    	}
	    }
    
	    $tabla .= '</tbody></table></div>';
		
	    ### Paginación ###
	    if ($total > 0 && $pagina <= $numeroPaginas) {
	    	$tabla .= '<p class="has-text-right">Mostrando Especialidades <strong>' . $pag_inicio . '</strong> al <strong>' . $pag_final . '</strong> de un <strong>total de ' . $total . '</strong></p>';
	    	$tabla .= $this->paginadorTablas($pagina, $numeroPaginas, $url, 7);
	    }
	    return $tabla;
	}

	public function actualizarEspecialidad(){

		$especialidadCodigo = $this->limpiarCadena($_POST['especialidadCodigo']);
	
		$datos = $this->ejecutarConsulta("SELECT * FROM especialidad WHERE especialidadCodigo = '$especialidadCodigo'");
			if($datos->rowCount()<=0){
				$alerta=[
					"tipo"=>"simple",
					"titulo"=>"Ocurrió un error inesperado",
					"texto"=>"No hemos encontrado la especialidad en el sistema",
					"icono"=>"error"
				];
				return json_encode($alerta);
			}else{
				$datos=$datos->fetch();
				$nombreAnterior = $datos['especialidadNombre']; 
				$descripcionAnterior = $datos['descripcion']; 
			}
	
			$admin_usuario_correo=$this->limpiarCadena($_POST['administrador_usuario']);
			$admin_clave=$this->limpiarCadena($_POST['administrador_clave']);
	
			if($admin_usuario_correo=="" || $admin_clave==""){
				$alerta=[
					"tipo"=>"simple",
					"titulo"=>"Ocurrió un error inesperado",
					"texto"=>"No ha llenado todos los campos que son obligatorios, que corresponden a su 'USUARIO o CORREO' y 'CLAVE'",
					"icono"=>"error"
				];
				return json_encode($alerta);
			}
	
			if($this->verificarDatos("[a-zA-Z0-9\s@.]{8,35}",$admin_usuario_correo)){
				$alerta=[
					"tipo"=>"simple",
					"titulo"=>"Ocurrió un error inesperado",
					"texto"=>"Su USUARIO o CORREO de Administrador no coincide con el formato solicitado",
					"icono"=>"error"
				];
				return json_encode($alerta);
			}
	
			if($this->verificarDatos("[a-zA-Z0-9$@.-]{3,100}",$admin_clave)){
				$alerta=[
					"tipo"=>"simple",
					"titulo"=>"Ocurrió un error inesperado",
					"texto"=>"Su CLAVE de Administrador no coincide con el formato solicitado",
					"icono"=>"error"
				];
				return json_encode($alerta);
			}
	
			$consulta_admin=$this->ejecutarConsulta("SELECT * FROM administrador a INNER JOIN usuario u ON a.usua_codigo_fk = u.usua_codigo INNER JOIN persona pe ON a.personaCodigo_fk = pe.personaCodigo 
			WHERE (u.usua_usuario = '$admin_usuario_correo' OR u.correo = '$admin_usuario_correo') AND u.usua_codigo = '".$_SESSION['codigo']."'");
				
			if($consulta_admin->rowCount()==1){
				$consulta_admin=$consulta_admin->fetch();

				if ((!($consulta_admin['usua_usuario'] == $admin_usuario_correo || $consulta_admin['correo'] == $admin_usuario_correo)) || !password_verify($admin_clave, $consulta_admin['usua_clave'])) {
					$alerta=[
						"tipo"=>"simple",
						"titulo"=>"Ocurrió un error inesperado",
						"texto"=>"'USUARIO o CORREO' o 'CLAVE' de Administrador son incorrectos",
						"icono"=>"error"
					];
					return json_encode($alerta);
				}
			}else{
				$alerta=[
					"tipo"=>"simple",
					"titulo"=>"Ocurrió un error inesperado",
					"texto"=>"'USUARIO o CORREO' o 'CLAVE' de Administrador son incorrectos",
					"icono"=>"error"
				];
				return json_encode($alerta);
			}
	
			$nombreActual = $this->limpiarCadena($_POST['especialidadNombre']);
			$descripcionActual = $this->limpiarCadena($_POST['descripcion']);
			$duracionActual = $this->limpiarCadena($_POST['duracion']);
			$costoActual = $this->limpiarCadena($_POST['costo']);
			$diaSemanaActual = $this->limpiarCadena($_POST['diaSemana']);
				
			if($nombreActual=="" || $descripcionActual=="" || $duracionActual=="" || $costoActual=="" || $diaSemanaActual==""){
				$alerta=[
					"tipo"=>"simple",
					"titulo"=>"Ocurrió un error inesperado",
					"texto"=>"No has llenado todos los campos que son obligatorios",
					"icono"=>"error"
				];
				return json_encode($alerta);
			}
	
			if ($this->verificarDatos("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]{5,30}", $nombreActual)) {
				$alerta = [
					"tipo" => "simple",
					"titulo" => "Ocurrió un error inesperado",
					"texto" => "El NOMBRE DE LA ESPECIALIDAD no coincide con el formato solicitado",
					"icono" => "error"
				];
				return json_encode($alerta);
			}	
			
			if($nombreActual != $nombreAnterior){
				$consulta_nombre = $this->ejecutarConsulta("SELECT especialidadNombre FROM especialidad WHERE especialidadNombre = '$nombreActual'");
				if ($consulta_nombre->rowCount() > 0) {
					$alerta = [
						"tipo" => "simple",
						"titulo" => "Ocurrió un error inesperado",
						"texto" => "El NOMBRE DE LA ESPECIALIDAD ya está registrado",
						"icono" => "error"
					];
					return json_encode($alerta);
				}
			}	
				
			if (strlen($descripcionActual) > 255) {
				$alerta = [
					"tipo" => "simple",
					"titulo" => "Ocurrió un error inesperado",
					"texto" => "La DESCRIPCIÓN no debe exceder los 255 caracteres",
					"icono" => "error"
				];
				return json_encode($alerta);
			}
	
			if ($descripcionAnterior !== $descripcionActual) {
				$consulta_descripcion = $this->ejecutarConsulta("SELECT descripcion FROM especialidad WHERE descripcion = '$descripcionActual'");
				if ($consulta_descripcion->rowCount() > 0) {
					$alerta = [
						"tipo" => "simple",
						"titulo" => "Ocurrió un error inesperado",
						"texto" => "La DESCRIPCIÓN ingresada ya se encuentra registrada, verifique que la descripción sea la correcta",
						"icono" => "error"
					];
					return json_encode($alerta);
				}
			}

			if (!preg_match("/^([01][0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]$/", $duracionActual)) {
				$alerta = [
					"tipo" => "simple",
					"titulo" => "Ocurrió un error inesperado",
					"texto" => "La DURACIÓN no tiene el formato correcto (HH:MM:SS)",
					"icono" => "error"
				];
				return json_encode($alerta);
			}
						
			if ($costoActual <= 0) {
				$alerta = [
					"tipo" => "simple",
					"titulo" => "Ocurrió un error inesperado",
					"texto" => "El COSTO debe ser un valor mayor a 0",
					"icono" => "error"
				];
				return json_encode($alerta);
			}
			
			$diasValidos = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];
			$diasIngresados = array_map('trim', explode(',', $diaSemanaActual));

			foreach ($diasIngresados as $dia) {
				if (!in_array($dia, $diasValidos)) {
					$alerta = [
						"tipo" => "simple",
						"titulo" => "Ocurrió un error inesperado",
						"texto" => "Uno o más de los días ingresados no son válidos. Asegúrate de ingresar días reales.",
						"icono" => "error"
					];
					return json_encode($alerta);
				}
			}	
	
			try {
				$especialidad_datos_up = [
					[
						"campo_nombre" => "especialidadNombre",
						"campo_marcador" => ":Nombre",
						"campo_valor" => $nombreActual
					],
					[
						"campo_nombre" => "descripcion",
						"campo_marcador" => ":Descripcion",
						"campo_valor" => $descripcionActual
					],
					[
						"campo_nombre" => "duracion", 
						"campo_marcador" => ":Duracion",
						"campo_valor" => $duracionActual
					],
					[
						"campo_nombre" => "costo",
						"campo_marcador" => ":Costo",
						"campo_valor" => $costoActual
					],
					[
						"campo_nombre" => "diaSemana",
						"campo_marcador" => ":Dia",
						"campo_valor" => $diaSemanaActual
					],
					[
						"campo_nombre" => "especialidad_actualizada",
						"campo_marcador" => ":Actualizada",
						"campo_valor" => date("Y-m-d H:i:s")
					]
				];
				
				$condicionEspecialidad = [
					"condicion_campo" => "especialidadCodigo",
					"condicion_marcador" => ":ID", 
					"condicion_valor" => $especialidadCodigo
				];
				
				if (!$this->actualizarDatos("Especialidad", $especialidad_datos_up, $condicionEspecialidad)) {
					throw new \Exception("No se pudieron actualizar los datos de la Especialidad");
				}

				$alerta = [
					"tipo" => "recargar",
					"titulo" => "Datos de Especialidad actualizados",
					"texto" => "Los datos de la Especialidad '" . $nombreActual . "' se actualizaron correctamente",
					"icono" => "success"
				];
				return json_encode($alerta);
				
			} catch (\Exception $e) {
				$alerta = [
					"tipo" => "simple",
					"titulo" => "Ocurrió un error inesperado",
					"texto" => $e->getMessage(),
					"icono" => "error"
				];
				return json_encode($alerta);
			}
	}
	
	public function eliminarEspecialidad(){

		$especialidadCodigo=$this->limpiarCadena($_POST['especialidadCodigo']);

		$datos=$this->ejecutarConsulta("SELECT * FROM especialidad WHERE especialidadCodigo='$especialidadCodigo'");
		if($datos->rowCount()<=0){
			$alerta=[
				"tipo"=>"simple",
				"titulo"=>"Ocurrió un error inesperado",
				"texto"=>"No hemos encontrado la especialidad en el sistema",
				"icono"=>"error"
			];
			return json_encode($alerta);
		}else{
			$datos=$datos->fetch();
		}
			
		$eliminarEspecialidad=$this->eliminarRegistro("Especialidad","especialidadCodigo",$especialidadCodigo);

		if($eliminarEspecialidad->rowCount()==1){
			if(is_file("../views/fotos/".$datos['especialidad_foto'])){
				chmod("../views/fotos/".$datos['especialidad_foto'],0777);
				unlink("../views/fotos/".$datos['especialidad_foto']);
			}
			$alerta=[
				"tipo"=>"recargar",
				"titulo"=>"Especialidad eliminada",
				"texto"=>"La Especialidad '".$datos['especialidadNombre']."' ha sido eliminada del sistema correctamente",
				"icono"=>"success"
			];
		}else{
			$alerta=[
				"tipo"=>"simple",
				"titulo"=>"Ocurrió un error inesperado",
				"texto"=>"No hemos podido eliminar la Especialidad '".$datos['especialidadNombre']."' del sistema, por favor intente nuevamente",
				"icono"=>"error"
			];
		}
		return json_encode($alerta);
	}	
}