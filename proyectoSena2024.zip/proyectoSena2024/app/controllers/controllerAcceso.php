<?php
namespace app\controllers;
use app\models\modelCrud;

class controllerAcceso extends modelCrud {

    public function iniciarSesionControlador() {
	
    $usuario_correo = $this->limpiarCadena($_POST['acceso_usuario']);
    $clave = $this->limpiarCadena($_POST['acceso_clave']);

    if ($usuario_correo == "" || $clave == "") {
        echo "<script>
            Swal.fire({
              icon: 'error',
              title: 'Ocurrió un error inesperado',
              text: 'No has llenado todos los campos que son obligatorios'
            });
        </script>";
    } else {
        if ($this->verificarDatos("[a-zA-Z0-9\s@.]{8,35}", $usuario_correo)) {
                echo "<script>
                    Swal.fire({
                      icon: 'error',
                      title: 'Ocurrió un error inesperado',
                      text: 'El USUARIO o CORREO no coincide con el formato solicitado'
                    });
                </script>";
        } else {
            if ($this->verificarDatos("[a-zA-Z0-9$@.-]{3,100}", $clave)) {
                echo "<script>
                    Swal.fire({
                      icon: 'error',
                      title: 'Ocurrió un error inesperado',
                      text: 'La CLAVE no coincide con el formato solicitado'
                    });
                </script>";
            } else {
                
                $check_usuario_persona = $this->ejecutarConsulta("SELECT * FROM usuario u 
                    INNER JOIN persona pe ON u.usua_codigo = pe.usua_codigo_fk 				
                    WHERE u.usua_usuario='$usuario_correo' OR u.correo='$usuario_correo'");

                if ($check_usuario_persona->rowCount() == 1) {
                        $check_usuario_persona = $check_usuario_persona->fetch();

                        if (($check_usuario_persona['usua_usuario'] == $usuario_correo || $check_usuario_persona['correo'] == $usuario_correo) && password_verify($clave, $check_usuario_persona['usua_clave'])) {

                            $_SESSION['codigo'] = $check_usuario_persona['usua_codigo'];
                            $_SESSION['usuario'] = $check_usuario_persona['usua_usuario'];
                            $_SESSION['correo'] = $check_usuario_persona['correo'];
                            $_SESSION['rol'] = $check_usuario_persona['rol'];
                            $_SESSION['foto'] = $check_usuario_persona['usuario_foto'];
                            $_SESSION['nombre'] = $check_usuario_persona['nombre'];
                            $_SESSION['apellido'] = $check_usuario_persona['apellido'];

                            if ($_SESSION['rol'] == 'Administrador') {
                                $administradorDatos = $this->ejecutarConsulta("SELECT adminCodigo FROM Administrador  
                                    WHERE usua_codigo_fk = '{$check_usuario_persona['usua_codigo']}'");

                                if ($administradorDatos->rowCount() == 1) {
                                    $administradorDatos = $administradorDatos->fetch();
                                    $_SESSION['adminCodigo'] = $administradorDatos['adminCodigo'];
                                }
                            }
                            
                            if ($_SESSION['rol'] == 'Especialista') {
                                $especialistaDatos = $this->ejecutarConsulta("SELECT especialista.especialistaCodigo, especialista.especialidadCodigo_fk, especialidad.especialidad_foto FROM Especialista especialista 
                                    INNER JOIN Especialidad especialidad ON especialista.especialidadCodigo_fk = especialidad.especialidadCodigo 
                                    WHERE especialista.usua_codigo_fk = '{$check_usuario_persona['usua_codigo']}'");

                                if ($especialistaDatos->rowCount() == 1) {
                                    $especialistaDatos = $especialistaDatos->fetch();
                                    
                                    $_SESSION['especialistaCodigo'] = $especialistaDatos['especialistaCodigo'];
                                    $_SESSION['especialidadCodigo'] = $especialistaDatos['especialidadCodigo_fk'];
                                    $_SESSION['especialidadFoto'] = $especialistaDatos['especialidad_foto'];
                                }
                            }

                            if ($_SESSION['rol'] == 'Paciente') {
                                $pacienteDatos = $this->ejecutarConsulta("SELECT pacienteCodigo FROM Paciente WHERE usua_codigo_fk = '{$check_usuario_persona['usua_codigo']}'");

                                if ($pacienteDatos->rowCount() == 1) {
                                    $pacienteDatos = $pacienteDatos->fetch();

                                    $_SESSION['pacienteCodigo'] = $pacienteDatos['pacienteCodigo'];
                                }
                            }

                            if (headers_sent()) {
                                echo "<script> window.location.href='" . APP_URL . "dashboard/'; </script>";
                            } else {
                                header("Location: " . APP_URL . "dashboard/");
                            }

                        } else {
                            echo "<script>
                                Swal.fire({
                                  icon: 'error',
                                  title: 'Ocurrió un error inesperado',
                                  text: 'Usuario, Correo o clave incorrectos'
                                });
                            </script>";
                        }
                } else {
                    echo "<script>
                        Swal.fire({
                          icon: 'error',
                          title: 'Ocurrió un error inesperado',
                          text: 'Usuario, Correo o clave incorrectos'
                        });
                    </script>";
                }
            }
        }
    }
    }

    public function cerrarSesionControlador() {
    session_destroy();

    if (headers_sent()) {
        echo "<script> window.location.href='" . APP_URL . "dashboardUsuario/'; </script>";
    } else {
        header("Location: " . APP_URL . "dashboardUsuario/");
    }
    }
}