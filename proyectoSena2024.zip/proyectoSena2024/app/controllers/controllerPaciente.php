<?php 
namespace app\controllers;
use app\models\modelCrud;

class controllerPaciente extends modelCrud{

	public function obtenerEspecialistasDias() {
        $especialidadCodigo = $this->limpiarCadena($_POST['especialidadCodigo']);
        if (!$especialidadCodigo) {
            echo json_encode([
                'success' => false,
                'message' => 'Especialidad no proporcionada.'
            ]);
            exit();
        }
    
        $especialistas = $this->obtenerEspecialistasPorEspecialidad($especialidadCodigo);
    
        $diasDisponibles = $this->obtenerDiasPorEspecialidad($especialidadCodigo);
    
        if ($especialistas && $diasDisponibles) {
            echo json_encode([
                'success' => true,
                'especialistas' => $especialistas,
                'diasDisponibles' => $diasDisponibles
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'No se encontraron especialistas o días disponibles para esta especialidad.'
            ]);
        }
        exit();
    }

    public function obtenerDisponibilidadHoras() {
        $especialistaCodigo_fk = $this->limpiarCadena($_POST['especialistaCodigo']);
        if (!$especialistaCodigo_fk) {
            echo json_encode(['success' => false, 'message' => 'Código de especialista no válido']);
            return;
        }

        $disponibilidad = $this->seleccionarDatos("Unico", "disponibilidadEspecialista", "especialistaCodigo_fk", $especialistaCodigo_fk)->fetch();
		if (!$disponibilidad) {
            echo json_encode(['success' => false, 'message' => 'No se encontró disponibilidad para el especialista.']);
        }else{
            echo json_encode(['success' => true, 'horaInicio' => $disponibilidad['horaInicio'], 'horaFin' => $disponibilidad['horaFin']]);
        }        
    }

	public function agendarCita() {
        $especialistaCodigo_fk = $this->limpiarCadena($_POST['especialistaCodigo']);
        $especialidadCodigo_fk = $this->limpiarCadena($_POST['especialidadCodigo']);
        $horaInicio = $this->limpiarCadena($_POST['hora']);
        $fecha = $this->limpiarCadena($_POST['fecha']);
    
        $especialidad = $this->seleccionarDatos('Unico', 'Especialidad', 'especialidadCodigo', $especialidadCodigo_fk)->fetch();
        if (!$especialidad) {
            $alerta = [
                "tipo" => "error",
                "titulo" => "Error",
                "texto" => "No se encontró la especialidad seleccionada",
                "icono" => "error"
            ];
            header('Content-Type: application/json');
            echo json_encode($alerta);
            exit();
        }

        list($horas, $minutos, $segundos) = explode(':', $especialidad['duracion']);
        $duracionEnMinutos = ($horas * 60) + $minutos + ($segundos / 60);
    
        $horaFin = date('H:i:s', strtotime($horaInicio . " + {$duracionEnMinutos} minutes"));
    
        $consulta_cita = $this->ejecutarConsulta("
            SELECT * FROM Cita 
                WHERE especialistaCodigo_fk = '$especialistaCodigo_fk' 
                AND fecha = '$fecha' 
                AND (
                    ('$horaInicio' BETWEEN horaInicio AND horaFin) 
                    OR ('$horaFin' BETWEEN horaInicio AND horaFin)
                    OR (horaInicio BETWEEN '$horaInicio' AND '$horaFin')
                    OR (horaFin BETWEEN '$horaInicio' AND '$horaFin'))
        ");
        
        if ($consulta_cita->rowCount() > 0) {
            $citaExistente = $consulta_cita->fetch();
            $horaFinCitaExistente = $citaExistente['horaFin'];
        
            $alerta = [
                "tipo" => "error",
                "titulo" => "Conflicto de Horario",
                "texto" => "Ya existe una cita registrada en ese horario. La próxima cita terminará a las " . $horaFinCitaExistente,
                "icono" => "error"
            ];
        
            header('Content-Type: application/json');
            echo json_encode($alerta);
            exit();
        }
        
        $conexion = $this->conectar();
    
        $guardar_cita = [
            [
                "campo_nombre" => "fecha",
                "campo_marcador" => ":Fecha",
                "campo_valor" => $fecha
            ],
            [
                "campo_nombre" => "horaInicio",
                "campo_marcador" => ":HoraInicio",
                "campo_valor" => $horaInicio
            ],
            [
                "campo_nombre" => "horaFin",
                "campo_marcador" => ":HoraFin",
                "campo_valor" => $horaFin
            ],
            [
                "campo_nombre" => "estado",
                "campo_marcador" => ":Estado",
                "campo_valor" => "Agendada"
            ],
            [
                "campo_nombre" => "especialidadCodigo_fk",
                "campo_marcador" => ":EspecialidadCodigo_fk",
                "campo_valor" => $especialidadCodigo_fk
            ],
            [
                "campo_nombre" => "especialistaCodigo_fk",
                "campo_marcador" => ":EspecialistaCodigo_fk",
                "campo_valor" => $especialistaCodigo_fk
            ],
            [
                "campo_nombre" => "pacienteCodigo_fk",
                "campo_marcador" => ":PacienteCodigo_fk",
                "campo_valor" => $_SESSION['pacienteCodigo']  
            ]
        ];
    

        $resultado = $this->guardarDatos("Cita", $guardar_cita, $conexion);

        if ($resultado->rowCount()==1) {
            $alerta = [
                "tipo" => "simple",  
                "titulo" => "Cita agendada",
                "texto" => "Tu cita ha sido agendada con éxito",
                "icono" => "success"
            ];
            echo json_encode($alerta);
            exit();
            
        } else {
            $alerta = [
                "tipo" => "error",
                "titulo" => "Ocurrió un error inesperado",
                "texto" => "No se pudo agendar la cita, intente nuevamente",
                "icono" => "error"
            ];
            header('Content-Type: application/json');
            echo json_encode($alerta);
            exit();
        }
    }   

	public function verHistorialCitas($pacienteCodigo) {
		return $this->obtenerHistorialCitasPorPaciente($pacienteCodigo);
	}
	
	public function verCitasAgendadas($pacienteCodigo) {
		return $this->obtenerCitasAgendadasPorPaciente($pacienteCodigo);
	}

	public function cancelarCita() {
		$citaCodigo_fk = $this->limpiarCadena($_POST['citaCodigo']);
		$motivo = $this->limpiarCadena($_POST['motivo']); 
		
		$datosCita = $this->seleccionarDatos("Unico", "Cita", "citaCodigo", $citaCodigo_fk)->fetch();
		if (!$datosCita) {
			$alerta = [
				"tipo" => "simple",
				"titulo" => "Ocurrió un error inesperado",
				"texto" => "No hemos encontrado la Cita en el sistema",
				"icono" => "error"
			];
			return json_encode($alerta);
		}
	
		$estadoAnterior = $datosCita['estado'];
	
		$cita_datos_up = [
			[
				"campo_nombre" => "estado",
				"campo_marcador" => ":Estado",
				"campo_valor" => "Cancelada"
			]
		];
	
		$condicionCita = [
			"condicion_campo" => "citaCodigo",
			"condicion_marcador" => ":citaCodigo", 
			"condicion_valor" => $citaCodigo_fk
		];
	
		if(!$this->actualizarDatos("Cita", $cita_datos_up, $condicionCita)){
			$alerta = [
				"tipo" => "simple",
				"titulo" => "Ocurrió un error inesperado",
				"texto" => "No se ha podido actualizar el nuevo Estado de la Cita",
				"icono" => "error"
			];
			return json_encode($alerta);
		}
	
		$fecha_modificacion = date("Y-m-d H:i:s");
		$diaSemanaIngles = date("l", strtotime($fecha_modificacion));
		
		$diasSemana = [
			'Sunday' => 'Domingo',
			'Monday' => 'Lunes',
			'Tuesday' => 'Martes',
			'Wednesday' => 'Miércoles',
			'Thursday' => 'Jueves',
			'Friday' => 'Viernes',
			'Saturday' => 'Sábado'
		];
		
		$diaSemana = $diasSemana[$diaSemanaIngles];
		
		$conexion = $this->conectar();
		
		$historialCita_datos_reg = [
			[
				"campo_nombre" => "citaCodigo_fk",
				"campo_marcador" => ":IDCita",
				"campo_valor" => $citaCodigo_fk
			],
			[
				"campo_nombre" => "fecha_modificacion",
				"campo_marcador" => ":Fecha",
				"campo_valor" => $fecha_modificacion
			],
			[
				"campo_nombre" => "diaSemana",
				"campo_marcador" => ":Dia",
				"campo_valor" => $diaSemana
			],
			[
				"campo_nombre" => "estado_anterior",
				"campo_marcador" => ":Anterior",
				"campo_valor" => $estadoAnterior
			],
			[
				"campo_nombre" => "estado_nuevo",
				"campo_marcador" => ":Nuevo",
				"campo_valor" => "Cancelada"
			]
		];
	
		if(!$this->guardarDatos("historialCita", $historialCita_datos_reg, $conexion)){
			$alerta = [
				"tipo" => "simple",
				"titulo" => "Ocurrió un error inesperado",
				"texto" => "No se ha podido registrar el Historial de la Cita",
				"icono" => "error"
			];
			return json_encode($alerta);
		}else{
			$alerta = [
				"tipo" => "simple",
				"titulo" => "Cita Actualizada",
				"texto" => "La Cita se ha actualizado correctamente",
				"icono" => "success"
			];
		}
		
		if (isset($motivo) && $motivo != "") {
			$fecha_cancelacion = date("Y-m-d H:i:s");
			$diaSemanaInglesCancelacion = date("l", strtotime($fecha_cancelacion));
			
			$diaSemanaCancelacion = $diasSemana[$diaSemanaInglesCancelacion];
			
			$cancelacionCita_datos_reg = [
				[
					"campo_nombre" => "citaCodigo_fk",
					"campo_marcador" => ":IDCita",
					"campo_valor" => $citaCodigo_fk
				],
				[
					"campo_nombre" => "usua_codigo_fk",
					"campo_marcador" => ":IDUsuario",
					"campo_valor" => $_SESSION['codigo']
				],
				[
					"campo_nombre" => "fecha_cancelacion",
					"campo_marcador" => ":Fecha",
					"campo_valor" => $fecha_cancelacion
				],
				[
					"campo_nombre" => "diaSemana",
					"campo_marcador" => ":Dia",
					"campo_valor" => $diaSemanaCancelacion
				],
				[
					"campo_nombre" => "motivo",
					"campo_marcador" => ":Motivo",
					"campo_valor" => $motivo
				]
			];
			
			if(!$this->guardarDatos("cancelacionCita", $cancelacionCita_datos_reg, $conexion)){
				$alerta = [
					"tipo" => "simple",
					"titulo" => "Ocurrió un error inesperado",
					"texto" => "No se ha podido registrar la cancelación de Cita",
					"icono" => "error"
				];
				return json_encode($alerta);
			}
		}
	
		return json_encode($alerta);
	}

	public function buscarCita($pagina, $registros, $url, $busqueda) {
		if ($_SESSION['rol'] != "Paciente") {
			session_destroy();
			header("Location: " . APP_URL . "app/views/content/404-vista");
			exit();
		}
	
		$pagina = $this->limpiarCadena($pagina);
		$registros = $this->limpiarCadena($registros);
		$url = $this->limpiarCadena($url);
		$url = APP_URL . $url . "/";
		$busqueda = $this->limpiarCadena($busqueda);
		$codigo_paciente = $this->limpiarCadena($_SESSION['pacienteCodigo']);
	
		$tabla = "";
	
		$pagina = (isset($pagina) && $pagina > 0) ? (int)$pagina : 1;
		$inicio = ($pagina > 0) ? (($pagina * $registros) - $registros) : 0;
	
		if (isset($busqueda) && $busqueda != "") {
			$consulta_datos = "SELECT ci.citaCodigo, ci.horaInicio, h.fecha_modificacion, h.diaSemana, h.estado_anterior, h.estado_nuevo,
								e.especialidadNombre, 
								pe.nombre, pe.apellido, pe.sexo, pe.edad 
							   FROM Cita ci
							   INNER JOIN Paciente pa ON ci.pacienteCodigo_fk = pa.pacienteCodigo
							   INNER JOIN Especialista es ON ci.especialistaCodigo_fk = es.especialistaCodigo
							   INNER JOIN Especialidad e ON ci.especialidadCodigo_fk = e.especialidadCodigo
							   INNER JOIN Persona pe ON es.personaCodigo_fk = pe.personaCodigo
							   LEFT JOIN historialCita h ON ci.citaCodigo = h.citaCodigo_fk
							   WHERE pa.pacienteCodigo = '$codigo_paciente'
							   AND h.estado_nuevo IN ('Cancelada', 'Completada')
							   AND (e.especialidadNombre LIKE '%$busqueda%' OR pe.nombre LIKE '%$busqueda%' 
							   OR pe.apellido LIKE '%$busqueda%' OR pe.sexo LIKE '%$busqueda%' OR h.fecha_modificacion LIKE '%$busqueda%' 
							   OR h.estado_anterior LIKE '%$busqueda%' OR h.estado_nuevo LIKE '%$busqueda%' OR h.diaSemana LIKE '%$busqueda%')
							   ORDER BY h.fecha_modificacion ASC LIMIT $inicio, $registros";
	
		$consulta_total = "SELECT COUNT(ci.citaCodigo) 
							FROM Cita ci
							INNER JOIN Paciente pa ON ci.pacienteCodigo_fk = pa.pacienteCodigo
							INNER JOIN Especialista es ON ci.especialistaCodigo_fk = es.especialistaCodigo
							INNER JOIN Especialidad e ON ci.especialidadCodigo_fk = e.especialidadCodigo
							INNER JOIN Persona pe ON es.personaCodigo_fk = pe.personaCodigo
							LEFT JOIN historialCita h ON ci.citaCodigo = h.citaCodigo_fk
							WHERE pa.pacienteCodigo = '$codigo_paciente'
							AND h.estado_nuevo IN ('Cancelada', 'Completada')
							AND (e.especialidadNombre LIKE '%$busqueda%' OR pe.nombre LIKE '%$busqueda%' 
							OR pe.apellido LIKE '%$busqueda%' OR pe.sexo LIKE '%$busqueda%' 
							OR h.fecha_modificacion LIKE '%$busqueda%' 
							OR h.estado_anterior LIKE '%$busqueda%' OR h.estado_nuevo LIKE '%$busqueda%' 
							OR h.diaSemana LIKE '%$busqueda%')";

		} 
	
		$datos = $this->ejecutarConsulta($consulta_datos); 
		$datos = $datos->fetchAll();
	
		$total = $this->ejecutarConsulta($consulta_total);
		$total = (int)$total->fetchColumn();
	
		$numeroPaginas = ceil($total / $registros);
	
		$tabla .= '<div class="table-container">
					<table class="table is-fullwidth is-striped is-hoverable">
						<thead>
							<tr>
								<th>Fecha y Hora</th>
								<th>Día Semana</th>
								<th>Estado Anterior</th>
								<th>Estado Actual</th>
								<th>Especialidad</th>
								<th>Especialista</th>
								<th>Género</th>
								<th>Edad</th>
								<th>  PDF</th>
							</tr>
						</thead>
						<tbody>';
	
		if ($total > 0) {
			foreach ($datos as $row) {
				$tabla .= '<tr>
    					<td>' . htmlspecialchars($row['fecha_modificacion']) . '</td>
    					<td>' . htmlspecialchars($row['diaSemana']) . '</td>
    					<td>' . 
    					    ($row['estado_anterior'] == 'Agendada' ? 
    					        '<span class="tag is-info">' . htmlspecialchars($row['estado_anterior']) . '</span>' : 
    					        '') . 
    					'</td>
    					<td>' . 
    					    ($row['estado_nuevo'] == 'Completada' ? 
    					        '<span class="tag is-success">' . htmlspecialchars($row['estado_nuevo']) . '</span>' : 
    					        ($row['estado_nuevo'] == 'Cancelada' ? 
    					            '<span class="tag is-danger">' . htmlspecialchars($row['estado_nuevo']) . '</span>' : 
    					            ''
    					        )) . 
    					'</td>
    					<td>' . htmlspecialchars($row['especialidadNombre']) . '</td>
    					<td>' . htmlspecialchars($row['nombre']) . ' ' . htmlspecialchars($row['apellido']) . '</td>
    					<td>' . htmlspecialchars($row['sexo']) . '</td>
    					<td>' . htmlspecialchars($row['edad']) . '</td>
    					<td>
    					    <a href="http://localhost/proyectoSena2024/app/controllers/descargarHistorialCitaPDF.php?citaID=' . htmlspecialchars($row['citaCodigo']) . '" target="_blank" class="button is-small is-link">Descargar PDF</a>
    					</td>
				</tr>';

			
			}
		} else {
			$tabla .= '<tr><td colspan="9">No se encontraron resultados</td></tr>';
		}
	
		$tabla .= '</tbody></table></div>';
	
		return $tabla;
	}
	
	

	public function verMisEspecialistas($pacienteCodigo) {
		return $this->obtenerMisEspecialistas($pacienteCodigo);
	}	

	public function enviarFormularioDeContacto() {  
		$usuarioAutenticado = isset($_SESSION['codigo']);
		
		$nombre = $this->limpiarCadena($_POST['nombre']);
		$correo = $this->limpiarCadena($_POST['correo']);
		$mensaje = $this->limpiarCadena($_POST['mensaje']);
	
		if ($nombre == "" || $correo == "" || $mensaje == "") {
			$alerta = [
				"tipo" => "simple",
				"titulo" => "Ocurrió un error inesperado",
				"texto" => "No has llenado todos los campos que son obligatorios para enviar tu consulta",
				"icono" => "error"
			];
			return json_encode($alerta);
		}
	
		if ($this->verificarDatos("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]{3,40}", $nombre)) {
			$alerta = [
				"tipo" => "simple",
				"titulo" => "Ocurrió un error inesperado",
				"texto" => "El NOMBRE no coincide con el formato solicitado",
				"icono" => "error"
			];
			return json_encode($alerta);
		}
	
		if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
			$alerta = [
				"tipo" => "simple",
				"titulo" => "Ocurrió un error inesperado",
				"texto" => "Ha ingresado un correo electrónico no válido",
				"icono" => "error"
			];
			return json_encode($alerta);
		}
	
		if ($usuarioAutenticado) {
			$codigo = $_SESSION['codigo'];
			$pacienteCodigo = $this->limpiarCadena($_POST['pacienteCodigo']);
	
			$verificacionPaciente = $this->ejecutarConsulta(
				"SELECT * FROM usuario u 
					INNER JOIN persona pe ON u.usua_codigo = pe.usua_codigo_fk 
					INNER JOIN paciente pa ON u.usua_codigo = pa.usua_codigo_fk 
				WHERE u.usua_codigo = '$codigo' AND pa.pacienteCodigo = '$pacienteCodigo'"
			);
	
			if ($verificacionPaciente->rowCount() <= 0) {
				$alerta = [
					"tipo" => "simple",
					"titulo" => "Ocurrió un error inesperado",
					"texto" => "No hemos encontrado el Paciente en el sistema",
					"icono" => "error"
				];
				return json_encode($alerta);
			}
	
			$consulta_correo = $this->ejecutarConsulta("SELECT correo FROM usuario WHERE usua_codigo = '$codigo'");
			
			if ($consulta_correo && $consulta_correo->rowCount() > 0) {
				$correoUsuario = $consulta_correo->fetch(\PDO::FETCH_ASSOC)['correo'];
	
				if ($correo !== $correoUsuario) {
					$alerta = [
						"tipo" => "simple",
						"titulo" => "Ocurrió un error inesperado",
						"texto" => "El CORREO ingresado no coincide con el correo asociado a tu cuenta.",
						"icono" => "error"
					];
					return json_encode($alerta);
				}
			} else {
				$alerta = [
					"tipo" => "simple",
					"titulo" => "Ocurrió un error inesperado",
					"texto" => "El correo no está registrado en el sistema.",
					"icono" => "error"
				];
				return json_encode($alerta);
			}
		}
	
		if (strlen($mensaje) > 255) {
			$alerta = [
				"tipo" => "simple",
				"titulo" => "Ocurrió un error inesperado",
				"texto" => "El MENSAJE no debe exceder los 255 caracteres",
				"icono" => "error"
			];
			return json_encode($alerta);
		}
	
		$alerta = [
			"tipo" => "limpiar",
			"titulo" => "Consulta enviada",
			"texto" => "Tu mensaje ha sido enviado exitosamente, nos pondremos en contacto pronto",
			"icono" => "success"
		];
		
		return json_encode($alerta);
	}
	
	
}	
?>