<?php  
namespace app\controllers;
use app\models\modelCrud;
use fpdf186\FPDF;

class controllerEspecialista extends modelCrud {

	public function verHistorialCitas($especialistaCodigo) {
		return $this->obtenerHistorialCitasPorEspecialista($especialistaCodigo);
	}
	
	public function verCitasPendientes($especialistaCodigo) {
		return $this->obtenerCitasPendientesPorEspecialista($especialistaCodigo);
	}

	public function actualizarEstadoCita() {
		$citaCodigo_fk = $this->limpiarCadena($_POST['citaCodigo']);
		$estadoNuevo = $this->limpiarCadena($_POST['estado']); 
		
		if(isset($_POST['motivo']) && $_POST['motivo'] != ""){
			$motivo = $this->limpiarCadena($_POST['motivo']);
		}
	
		$datosCita = $this->seleccionarDatos("Unico", "Cita", "citaCodigo", $citaCodigo_fk)->fetch();
		if (!$datosCita) {
			$alerta = [
				"tipo" => "simple",
				"titulo" => "Ocurrió un error inesperado",
				"texto" => "No hemos encontrado la Cita en el sistema",
				"icono" => "error"
			];
			return json_encode($alerta);
		}
	
		$estadoAnterior = $datosCita['estado'];
	
		$cita_datos_up = [
			[
				"campo_nombre" => "estado",
				"campo_marcador" => ":Estado",
				"campo_valor" => $estadoNuevo
			]
		];
	
		$condicionCita = [
			"condicion_campo" => "citaCodigo",
			"condicion_marcador" => ":citaCodigo", 
			"condicion_valor" => $citaCodigo_fk
		];
	
		if(!$this->actualizarDatos("Cita", $cita_datos_up, $condicionCita)){
			$alerta = [
				"tipo" => "simple",
				"titulo" => "Ocurrió un error inesperado",
				"texto" => "No se ha podido actualizar el nuevo Estado de la Cita",
				"icono" => "error"
			];
			return json_encode($alerta);
		}
	
		$fecha_modificacion = date("Y-m-d H:i:s");
		$diaSemanaIngles = date("l", strtotime($fecha_modificacion));
		
		$diasSemana = [
			'Sunday' => 'Domingo',
			'Monday' => 'Lunes',
			'Tuesday' => 'Martes',
			'Wednesday' => 'Miércoles',
			'Thursday' => 'Jueves',
			'Friday' => 'Viernes',
			'Saturday' => 'Sábado'
		];
		
		$diaSemana = $diasSemana[$diaSemanaIngles];
		
		$conexion = $this->conectar();
		
		$historialCita_datos_reg = [
			[
				"campo_nombre" => "citaCodigo_fk",
				"campo_marcador" => ":IDCita",
				"campo_valor" => $citaCodigo_fk
			],
			[
				"campo_nombre" => "fecha_modificacion",
				"campo_marcador" => ":Fecha",
				"campo_valor" => $fecha_modificacion
			],
			[
				"campo_nombre" => "diaSemana",
				"campo_marcador" => ":Dia",
				"campo_valor" => $diaSemana
			],
			[
				"campo_nombre" => "estado_anterior",
				"campo_marcador" => ":Anterior",
				"campo_valor" => $estadoAnterior
			],
			[
				"campo_nombre" => "estado_nuevo",
				"campo_marcador" => ":Nuevo",
				"campo_valor" => $estadoNuevo
			]
		];
	
		if(!$this->guardarDatos("historialCita", $historialCita_datos_reg, $conexion)){
			$alerta = [
				"tipo" => "simple",
				"titulo" => "Ocurrió un error inesperado",
				"texto" => "No se ha podido registrar el Historial de la Cita",
				"icono" => "error"
			];
			return json_encode($alerta);
		}else{
			$alerta = [
				"tipo" => "simple",
				"titulo" => "Cita Actualizada",
				"texto" => "La Cita se ha actualizado correctamente",
				"icono" => "success"
			];
		}
		
		if ($estadoNuevo === 'Cancelada' && isset($motivo) && $motivo) {
			$fecha_cancelacion = date("Y-m-d H:i:s");
			$diaSemanaInglesCancelacion = date("l", strtotime($fecha_cancelacion));
			
			$diaSemanaCancelacion = $diasSemana[$diaSemanaInglesCancelacion];
			
			$cancelacionCita_datos_reg = [
				[
					"campo_nombre" => "citaCodigo_fk",
					"campo_marcador" => ":IDCita",
					"campo_valor" => $citaCodigo_fk
				],
				[
					"campo_nombre" => "usua_codigo_fk",
					"campo_marcador" => ":IDUsuario",
					"campo_valor" => $_SESSION['codigo']
				],
				[
					"campo_nombre" => "fecha_cancelacion",
					"campo_marcador" => ":Fecha",
					"campo_valor" => $fecha_cancelacion
				],
				[
					"campo_nombre" => "diaSemana",
					"campo_marcador" => ":Dia",
					"campo_valor" => $diaSemanaCancelacion
				],
				[
					"campo_nombre" => "motivo",
					"campo_marcador" => ":Motivo",
					"campo_valor" => $motivo
				]
			];
			
			if(!$this->guardarDatos("cancelacionCita", $cancelacionCita_datos_reg, $conexion)){
				$alerta = [
					"tipo" => "simple",
					"titulo" => "Ocurrió un error inesperado",
					"texto" => "No se ha podido registrar la cancelación de Cita",
					"icono" => "error"
				];
				return json_encode($alerta);
			}
		}
	
		return json_encode($alerta);
	}

	public function buscarCita($pagina, $registros, $url, $busqueda) {
		if ($_SESSION['rol'] != "Especialista") {
			session_destroy();
			header("Location: " . APP_URL . "app/views/content/404-vista");
			exit();
		}
	
		$pagina = $this->limpiarCadena($pagina);
		$registros = $this->limpiarCadena($registros);
		$url = $this->limpiarCadena($url);
		$url = APP_URL . $url . "/";
		$busqueda = $this->limpiarCadena($busqueda);
		$codigo_especialista = $this->limpiarCadena($_SESSION['especialistaCodigo']);
	
		$tabla = "";
	
		$pagina = (isset($pagina) && $pagina > 0) ? (int)$pagina : 1;
		$inicio = ($pagina > 0) ? (($pagina * $registros) - $registros) : 0;
	
		if (isset($busqueda) && $busqueda != "") {
			$consulta_datos = "SELECT ci.citaCodigo, ci.horaInicio, h.fecha_modificacion, h.diaSemana, h.estado_anterior, h.estado_nuevo,
								e.especialidadNombre, 
								pe.nombre, pe.apellido, pe.sexo, pe.edad 
							   FROM Cita ci
							   INNER JOIN Especialista es ON ci.especialistaCodigo_fk = es.especialistaCodigo
							   INNER JOIN Paciente pa ON ci.pacienteCodigo_fk = pa.pacienteCodigo
							   INNER JOIN Especialidad e ON ci.especialidadCodigo_fk = e.especialidadCodigo
							   INNER JOIN Persona pe ON pa.personaCodigo_fk = pe.personaCodigo
							   LEFT JOIN historialCita h ON ci.citaCodigo = h.citaCodigo_fk
							   WHERE es.especialistaCodigo = '$codigo_especialista'
							   AND h.estado_nuevo IN ('Cancelada', 'Completada')
							   AND (e.especialidadNombre LIKE '%$busqueda%' OR pe.nombre LIKE '%$busqueda%' 
							   OR pe.apellido LIKE '%$busqueda%' OR pe.sexo LIKE '%$busqueda%' OR h.fecha_modificacion LIKE '%$busqueda%' 
							   OR h.estado_anterior LIKE '%$busqueda%' OR h.estado_nuevo LIKE '%$busqueda%' OR h.diaSemana LIKE '%$busqueda%')
							   ORDER BY h.fecha_modificacion ASC LIMIT $inicio, $registros";
	
		$consulta_total = "SELECT COUNT(ci.citaCodigo) 
							FROM Cita ci
							INNER JOIN Especialista es ON ci.especialistaCodigo_fk = es.especialistaCodigo
							INNER JOIN Paciente pa ON ci.pacienteCodigo_fk = pa.pacienteCodigo
							INNER JOIN Especialidad e ON ci.especialidadCodigo_fk = e.especialidadCodigo
							INNER JOIN Persona pe ON pa.personaCodigo_fk = pe.personaCodigo
							LEFT JOIN historialCita h ON ci.citaCodigo = h.citaCodigo_fk
							WHERE es.especialistaCodigo = '$codigo_especialista'
							AND h.estado_nuevo IN ('Cancelada', 'Completada')
							AND (e.especialidadNombre LIKE '%$busqueda%' OR pe.nombre LIKE '%$busqueda%' 
							OR pe.apellido LIKE '%$busqueda%' OR pe.sexo LIKE '%$busqueda%' 
							OR h.fecha_modificacion LIKE '%$busqueda%' 
							OR h.estado_anterior LIKE '%$busqueda%' OR h.estado_nuevo LIKE '%$busqueda%' 
							OR h.diaSemana LIKE '%$busqueda%')";

		} 
	
		$datos = $this->ejecutarConsulta($consulta_datos); 
		$datos = $datos->fetchAll();
	
		$total = $this->ejecutarConsulta($consulta_total);
		$total = (int)$total->fetchColumn();
	
		$numeroPaginas = ceil($total / $registros);
	
		$tabla .= '<div class="table-container">
					<table class="table is-fullwidth is-striped is-hoverable">
						<thead>
							<tr>
								<th>Fecha y Hora</th>
								<th>Día Semana</th>
								<th>Estado Anterior</th>
								<th>Estado Actual</th>
								<th>Especialidad</th>
								<th>Especialista</th>
								<th>Género</th>
								<th>Edad</th>
								<th>  PDF</th>
							</tr>
						</thead>
						<tbody>';
	
		if ($total > 0) {
			foreach ($datos as $row) {
				$tabla .= '<tr>
    					<td>' . htmlspecialchars($row['fecha_modificacion']) . '</td>
    					<td>' . htmlspecialchars($row['diaSemana']) . '</td>
    					<td>' . 
    					    ($row['estado_anterior'] == 'Agendada' ? 
    					        '<span class="tag is-info">' . htmlspecialchars($row['estado_anterior']) . '</span>' : 
    					        '') . 
    					'</td>
    					<td>' . 
    					    ($row['estado_nuevo'] == 'Completada' ? 
    					        '<span class="tag is-success">' . htmlspecialchars($row['estado_nuevo']) . '</span>' : 
    					        ($row['estado_nuevo'] == 'Cancelada' ? 
    					            '<span class="tag is-danger">' . htmlspecialchars($row['estado_nuevo']) . '</span>' : 
    					            ''
    					        )) . 
    					'</td>
    					<td>' . htmlspecialchars($row['especialidadNombre']) . '</td>
    					<td>' . htmlspecialchars($row['nombre']) . ' ' . htmlspecialchars($row['apellido']) . '</td>
    					<td>' . htmlspecialchars($row['sexo']) . '</td>
    					<td>' . htmlspecialchars($row['edad']) . '</td>
    					<td>
    					    <a href="http://localhost/proyectoSena2024/app/controllers/descargarHistorialCitaPDF.php?citaID=' . htmlspecialchars($row['citaCodigo']) . '" target="_blank" class="button is-small is-link">Descargar PDF</a>
    					</td>
				</tr>';

			
			}
		} else {
			$tabla .= '<tr><td colspan="9">No se encontraron resultados</td></tr>';
		}
	
		$tabla .= '</tbody></table></div>';
	
		return $tabla;
	}
	
	public function verMisPacientes($especialistaCodigo) {
		return $this->obtenerMisPacientes($especialistaCodigo);
	}	

	public function verMiDisponibilidad($especialistaCodigo) {
		return $this->obtenerMiDisponibilidad($especialistaCodigo);
	}	
	
    public function descargarHistorialCitaPDF($especialistaCodigo, $citaID) {
        $historialCitaModel = new modelCrud;
        
        $historialCita = $historialCitaModel->obtenerDetallesCita($especialistaCodigo, $citaID);

        if (!$historialCita) {
			$alerta = [
				"tipo" => "simple",
				"titulo" => "Ocurrió un error inesperado",
				"texto" => "No hemos encontrado la Cita en el sistema",
				"icono" => "error"
			];
			return json_encode($alerta);
        }

        $pdf = new FPDF();
        $pdf->AddPage();

        $pdf->Image('./app/views/img/logo-a-tu-salud.png',10,6,30); 
        $pdf->SetFont('Arial', 'B', 16);
        $pdf->Cell(190, 10, 'Historial de Cita - A tu Salud', 0, 1, 'C');
        $pdf->Ln(10); 
        
        $pdf->SetFont('Arial', '', 12);
        $pdf->Cell(50, 10, 'Fecha de Modificacion:', 0, 0);
        $pdf->Cell(100, 10, $historialCita['fecha_modificacion'], 0, 1);

        $pdf->Cell(50, 10, 'Dia de la Semana:', 0, 0);
        $pdf->Cell(100, 10, $historialCita['diaSemana'], 0, 1);

        $pdf->Cell(50, 10, 'Estado Anterior:', 0, 0);
        $pdf->Cell(100, 10, $historialCita['estado_anterior'], 0, 1);

        $pdf->Cell(50, 10, 'Estado Nuevo:', 0, 0);
        $pdf->Cell(100, 10, $historialCita['estado_nuevo'], 0, 1);

        if ($historialCita['estado_nuevo'] == 'Cancelada') {
            $pdf->Cell(50, 10, 'Motivo de Cancelacion:', 0, 0);
            $pdf->MultiCell(100, 10, $historialCita['motivo'], 0);
        }

        $pdf->Cell(50, 10, 'Paciente:', 0, 0);
        $pdf->Cell(100, 10, $historialCita['paciente_nombre'] . ' ' . $historialCita['paciente_apellido'], 0, 1);

        $pdf->Cell(50, 10, 'Especialista:', 0, 0);
        $pdf->Cell(100, 10, $historialCita['especialista_nombre'] . ' ' . $historialCita['especialista_apellido'], 0, 1);

        $pdf->Cell(50, 10, 'Especialidad:', 0, 0);
        $pdf->Cell(100, 10, $historialCita['especialidad_nombre'], 0, 1);

        $pdf->Cell(50, 10, 'Duracion de la Cita:', 0, 0);
        $pdf->Cell(100, 10, $historialCita['duracion'], 0, 1);

        $pdf->Cell(50, 10, 'Costo del Servicio:', 0, 0);
        $pdf->Cell(100, 10, $historialCita['costo'], 0, 1);

        if ($historialCita['estado_nuevo'] == 'Completada') {
            $pdf->Cell(50, 10, 'Hora de Inicio:', 0, 0);
            $pdf->Cell(100, 10, $historialCita['horaInicio'], 0, 1);

            $pdf->Cell(50, 10, 'Hora de Fin:', 0, 0);
            $pdf->Cell(100, 10, $historialCita['horaFin'], 0, 1);
        }
        $pdf->Output('D', 'Historial_Cita_' . $historialCita['citaCodigo'] . '.pdf');
    }
}