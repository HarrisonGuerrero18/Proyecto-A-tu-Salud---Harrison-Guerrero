<?php
require_once "./app/controllers/controllerEspecialista.php";
use app\controllers\controllerEspecialista;

$controller = new controllerEspecialista(); 
if (isset($_POST['citaID'])) {
    $controller->descargarHistorialCitaPDF($_SESSION['especialistaCodigo'], $_POST['citaID']);
} else {
    echo "Error: ID de la cita no proporcionado";
}
?>