document.querySelectorAll('.activar-model-btn').forEach(button => { 
    button.addEventListener('click', function (event) {
        event.preventDefault();
        const especialidadCodigo = this.getAttribute('data-especialidad');
        const especialidadNombre = this.closest('.box').querySelector('.title').textContent; 
        
        const modal = document.getElementById('modal-cita');
        
        document.getElementById('modal-title').textContent = `Agenda tu Cita para ${especialidadNombre}`;
        
        document.getElementById('especialidadCodigo').value = especialidadCodigo;

        modal.classList.add('is-active'); 
        
        fetch('http://localhost/proyectoSena2024/cita-especialista-fecha/obtenerEspecialistasDias', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: new URLSearchParams({ especialidadCodigo: especialidadCodigo })
        })
        .then(response => response.json())
        .then(data => {
            console.log('Respuesta del servidor:', data);
            
            if (data.success) {
                const selectEspecialista = document.getElementById('especialistaCodigo');
                selectEspecialista.innerHTML = '<option value="">Seleccione un especialista</option>';
                
                data.especialistas.forEach(especialista => {
                    const option = document.createElement('option');
                    option.value = especialista.especialistaCodigo;
                    option.textContent = `${especialista.nombre} ${especialista.apellido}`;
                    selectEspecialista.appendChild(option);
                });
                
                const diasDisponibles = data.diasDisponibles;
                const fechaInput = document.getElementById('diaSemana');
                
                const newInput = fechaInput.cloneNode(true);
                fechaInput.parentNode.replaceChild(newInput, fechaInput);
                
                const hoy = new Date().toISOString().split('T')[0]; 
                const unAnioDespues = new Date();
                unAnioDespues.setFullYear(unAnioDespues.getFullYear() + 1);
                const limiteMaximo = unAnioDespues.toISOString().split('T')[0];
                
                newInput.setAttribute('min', hoy);
                newInput.setAttribute('max', limiteMaximo);

                newInput.addEventListener('change', function () {
                    const fechaSeleccionada = new Date(this.value + 'T00:00:00');
                    const diaSemanaSeleccionado = fechaSeleccionada.toLocaleDateString('es-ES', { weekday: 'long' });
                    const diaSemanaNormalizado = diaSemanaSeleccionado.charAt(0).toUpperCase() + diaSemanaSeleccionado.slice(1);
                    
                    if (!diasDisponibles.includes(diaSemanaNormalizado)) {
                        Swal.fire({
                            title: 'Fecha no disponible',
                            text: `El ${diaSemanaSeleccionado} no se realiza este Servicio.`,
                            icon: 'error',
                            confirmButtonColor: 'gray',
                            confirmButtonText: 'Entendido'
                        });
                        this.value = ''; 
                    }
                });
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: data.message || 'Error al obtener especialistas y días disponibles.',
                    confirmButtonText: 'Entendido'
                });
            }
        })
        .catch(error => {
            console.error('Error:', error); 
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Hubo un error al procesar la solicitud',
                confirmButtonText: 'Entendido'
            });
        });
    });
});

function closeCitaModal() {
    const modal = document.getElementById('modal-cita');
    modal.classList.remove('is-active');
}

let horaInicioEspecialista = null;
let horaFinEspecialista = null;

document.addEventListener('DOMContentLoaded', function() {
    const especialistaCodigoElement = document.getElementById('especialistaCodigo');
    if (especialistaCodigoElement) {
        especialistaCodigoElement.addEventListener('change', function() {
            const especialistaCodigo = this.value;
            if (especialistaCodigo) {
                fetch('http://localhost/proyectoSena2024/cita-hora/obtenerDisponibilidadHoras', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: new URLSearchParams({ especialistaCodigo: especialistaCodigo })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        horaInicioEspecialista = data.horaInicio;
                        horaFinEspecialista = data.horaFin;
                        validarHoraSeleccionada();
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: data.message || 'Error al obtener la disponibilidad del especialista.',
                            confirmButtonText: 'Entendido'
                        });
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Hubo un error al procesar la solicitud.',
                        confirmButtonText: 'Entendido'
                    });
                });
            } else {
                horaInicioEspecialista = null;
                horaFinEspecialista = null;
            }
        });
    }

    const horaInicioElement = document.getElementById('horaInicio');
    if (horaInicioElement) {
        horaInicioElement.addEventListener('change', function() {
            validarHoraSeleccionada();
        });
    }
});

function validarHoraSeleccionada() {
    const horaInicioSeleccionada = document.getElementById('horaInicio').value;
    if (horaInicioEspecialista && horaFinEspecialista && horaInicioSeleccionada) {
        const horaInicio = new Date(`1970-01-01T${horaInicioEspecialista}`);
        const horaFin = new Date(`1970-01-01T${horaFinEspecialista}`);
        const horaSeleccionada = new Date(`1970-01-01T${horaInicioSeleccionada}`);

        if (horaSeleccionada < horaInicio || horaSeleccionada >= horaFin) {
            Swal.fire({
                icon: 'error',
                title: 'Hora no disponible',
                text: `La hora seleccionada debe estar entre ${horaInicioEspecialista} y ${horaFinEspecialista}.`,
                confirmButtonText: 'Entendido'
            });
            document.getElementById('horaInicio').value = '';
        }
    }
}

function closeCancelarModal() {
    const modal = document.getElementById('modal-cancelar-cita');
    modal.classList.remove('is-active');
}

    const cancelBtns = document.querySelectorAll('.cancel-btn');
    const modalCancelar = document.getElementById('modal-cancelar-cita');

if (modalCancelar) {
    const closeModalBtn = modalCancelar.querySelector('.close-cancel-modal');
    cancelBtns.forEach(btn => {
        btn.addEventListener('click', (event) => {
            const citaId = btn.getAttribute('data-cita-id');
            modalCancelar.classList.add('is-active');
        });
    });
    if (closeModalBtn) { 
        closeModalBtn.addEventListener('click', closeCancelarModal);
    }
    modalCancelar.addEventListener('click', (event) => {
        if (event.target === modalCancelar) {
            closeCancelarModal(); 
        }
    });
}