const formularios_ajax = document.querySelectorAll(".FormularioAjax");

formularios_ajax.forEach(formulario => {

    formulario.addEventListener("submit", function(e) {
        
        e.preventDefault();
        
        const submitter = e.submitter;
        if (submitter && submitter.getAttribute('type') === 'submit') {

            Swal.fire({
                title: '¿Estás seguro?',
                text: "Quieres realizar la acción solicitada",
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Sí, realizar',
                cancelButtonText: 'No, cancelar'
            }).then((result) => { 
                if (result.isConfirmed) { 

                    let data = new FormData(this); 
                    let method = this.getAttribute("method"); 
                    let action = this.getAttribute("action"); 

                    let encabezados = new Headers();

                    let config = {
                        method: method,
                        headers: encabezados,
                        mode: 'cors',
                        cache: 'no-cache',
                        body: data
                    };

                    fetch(action, config)
                    .then(respuesta => respuesta.text())
                    .then(textoRespuesta => {
                        console.log(textoRespuesta); 
                        try {
                            const respuestaJson = JSON.parse(textoRespuesta); 
                            return alertas_ajax(respuestaJson);
                        } catch (error) {
                            console.error("Error al parsear JSON:", error);
                            Swal.fire({
                                icon: 'error',
                                title: 'Error en la respuesta',
                                text: 'El servidor no devolvió una respuesta válida en formato JSON.'
                            });
                        }
                    }).catch(error => {
                        console.error("Error en la solicitud fetch:", error);
                        Swal.fire({
                            icon: 'error',
                            title: 'Error de conexión',
                            text: 'Ocurrió un error al intentar realizar la solicitud.'
                        });
                    });
                
                }
            });
        }
    });
});

function alertas_ajax(alerta) {
    if (alerta.tipo === "error") {
        Swal.fire({
            icon: alerta.icono,
            title: alerta.titulo,
            text: alerta.texto,
            confirmButtonText: 'Aceptar'
        });
    } else if (alerta.tipo === "simple") {
        Swal.fire({
            icon: alerta.icono,
            title: alerta.titulo,
            text: alerta.texto,
            confirmButtonText: 'Aceptar'
        });
    } else if (alerta.tipo === "recargar") {
        Swal.fire({
            icon: alerta.icono,
            title: alerta.titulo,
            text: alerta.texto,
            confirmButtonText: 'Aceptar'
        }).then((resultado) => {
            if (resultado.isConfirmed) {
                location.reload();
            }
        });
    } else if (alerta.tipo === "limpiar") {
        Swal.fire({
            icon: alerta.icono,
            title: alerta.titulo,
            text: alerta.texto,
            confirmButtonText: 'Aceptar'
        }).then((resultado) => {
            if (resultado.isConfirmed) {
                document.querySelector(".FormularioAjax").reset();
            }
        });
    } else if (alerta.tipo === "redireccionar") {
        window.location.href = alerta.url;
    }else if (alerta.tipo === "formulario") {
        Swal.fire({
            title: alerta.titulo,
            html: `
                    <form id="form-nueva-contrasena" style="max-width: 400px; margin: 0 auto;">
                        <input type="hidden" id="usua_codigo" value="${alerta.usua_codigo}">

                        <p class="title is-3 has-text-centered has-text-info">Restablecer Contraseña</p>

                        <p class="has-text-centered">
                            <i class="fas fa-key fa-5x"></i>
                        </p>
                        <br>
                        <div class="field">
                            <label class="label" for="nueva_contrasena"><i class="fas fa-lock"></i> &nbsp; Nueva Contraseña:</label>
                            <div class="control has-icons-left">
                                <input type="password" id="nueva_contrasena" class="input is-rounded" placeholder="Ingrese su nueva contraseña" required>
                                <span class="icon is-small is-left">
                                    <i class="fas fa-key"></i>
                                </span>
                            </div>
                        </div>

                        <div class="field">
                            <label class="label" for="confirmar_contrasena"><i class="fas fa-lock"></i> &nbsp; Confirmar Contraseña:</label>
                            <div class="control has-icons-left">
                                <input type="password" id="confirmar_contrasena" class="input is-rounded" placeholder="Confirme su nueva contraseña" required>
                                <span class="icon is-small is-left">
                                    <i class="fas fa-key"></i>
                                </span>
                            </div>
                        </div>
                    </form>
            `,
            focusConfirm: false,
            preConfirm: () => {
                const nuevaContrasena = document.getElementById('nueva_contrasena').value;
                const confirmarContrasena = document.getElementById('confirmar_contrasena').value;
                const usuaCodigo = document.getElementById('usua_codigo').value;
                if (!nuevaContrasena || nuevaContrasena !== confirmarContrasena) {
                    Swal.showValidationMessage('Las contraseñas no coinciden o están vacías');
                    return false;
                }
                return { nuevaContrasena, usuaCodigo }; 
            },
            showCancelButton: true,
            confirmButtonText: 'Restablecer',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                let data = new FormData();
                data.append("nueva_contrasena", result.value.nuevaContrasena);
                data.append("usua_codigo", result.value.usuaCodigo); 
                fetch('http://localhost/proyectoSena2024/recuperar-contrasena/recuperarContrasena', {
                    method: 'POST',
                    body: data
                }).then(response => response.json())
                .then(respuesta => {
                    Swal.fire({
                        icon: respuesta.icono,
                        title: respuesta.titulo,
                        text: respuesta.texto,
                        confirmButtonText: 'Aceptar'
                    });
                }).catch(error => {
                    console.error("Error al enviar la contraseña:", error);
                    Swal.fire({
                        icon: 'error',
                        title: 'Error de conexión',
                        text: 'No se pudo restablecer la contraseña'
                    });
                });
            }
        });
    }    
}

document.addEventListener("DOMContentLoaded", function() {
    let btn_exit = document.getElementById("btn_exit");

    if (btn_exit) { 
        btn_exit.addEventListener("click", function(e) {
            e.preventDefault();

            Swal.fire({
                title: '¿Quieres salir del sistema?',
                text: "La sesión actual se cerrará y saldrás del sistema",
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Sí, salir',
                cancelButtonText: 'Cancelar'
            }).then((resultado) => {
                if (resultado.isConfirmed) {
                    let url = this.getAttribute("href");
                    window.location.href = url;
                }
            });
        });
    }
});