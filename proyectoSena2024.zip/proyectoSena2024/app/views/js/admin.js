const rolSelect = document.getElementById("rolSelect");

if (rolSelect) { 
    rolSelect.addEventListener("change", function() {
        const especialidadesDiv = document.getElementById("especialidades");
        if (this.value === "Especialista") {
            especialidadesDiv.classList.remove("is-hidden");
        } else {
            especialidadesDiv.classList.add("is-hidden");
        }
    });
}

function mostrarUsuarios() {
    document.getElementById("tablaUsuarios").style.display = "block";
    document.getElementById("tablaPersonas").style.display = "none";
}

function mostrarPersonas() {
    document.getElementById("tablaUsuarios").style.display = "none";
    document.getElementById("tablaPersonas").style.display = "block";
}