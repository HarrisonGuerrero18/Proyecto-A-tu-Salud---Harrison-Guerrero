document.addEventListener('DOMContentLoaded', function() {
    const selectElements = document.querySelectorAll('.select-estado');
    const submitButton = document.getElementById('button-select');

    if (submitButton) {
        submitButton.disabled = true;
        selectElements.forEach(function(select) {
            select.addEventListener('change', function() {
                const contenedorMotivo = this.closest('td').querySelector('.contenedorMotivo');
                if (this.value === 'Cancelada') {
                    contenedorMotivo.style.display = 'block';
                } else {
                    contenedorMotivo.style.display = 'none';
                }

                let hasSelected = false;
                selectElements.forEach(function(select) {
                    if (select.value !== "") {
                        hasSelected = true;
                    }
                });

                if (hasSelected) {
                    submitButton.disabled = false;
                    selectElements.forEach(function(otherSelect) {
                        if (otherSelect !== select) {
                            otherSelect.disabled = true;
                        }
                    });
                } else {
                    submitButton.disabled = true;
                    selectElements.forEach(function(otherSelect) {
                        otherSelect.disabled = false;
                    });
                }
            });
        });
    }
});
