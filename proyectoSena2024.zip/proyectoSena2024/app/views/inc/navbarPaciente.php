<nav class="navbar has-background-info-light">
    <div class="navbar-brand">
        <a href="<?php echo APP_URL; ?>dashboard/">
            <img src="<?php echo APP_URL; ?>app/views/img/logo-a-tu-salud.png" alt="A tu Salud" width="65" height="65">
        </a>
        <div class="navbar-burger" data-target="navbarExampleTransparentExample">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </div>
    
    <div id="navbarExampleTransparentExample" class="navbar-menu">
        <div class="navbar-start">
            <a class="navbar-item" href="<?php echo APP_URL; ?>dashboard/">
                Página de Inicio
            </a>
            <a class="navbar-item" href="<?php echo APP_URL; ?>serviciosMedicos/">
                Servicios Médicos
            </a>

            <div class="navbar-item has-dropdown is-hoverable">
                <a class="navbar-link" href="#">
                    Citas
                </a>
                <div class="navbar-dropdown is-boxed">
                    <a class="navbar-item" href="<?php echo APP_URL; ?>historialCitasPac/">
                        Tu Historial de Citas
                    </a>
                    <a class="navbar-item" href="<?php echo APP_URL; ?>citasAgendadas/">
                        Citas Agendadas
                    </a>
                    <a class="navbar-item" href="<?php echo APP_URL; ?>citasPacientesBuscar/">
                        Buscar (por nombre del Especialista, Fecha u Hora)
                    </a>
                </div>
            </div>
            
            <a class="navbar-item" href="<?php echo APP_URL; ?>misEspecialistas/">
                Mis Especialistas
            </a>

            <a class="navbar-item" href="<?php echo APP_URL; ?>quienesSomos/">
                ¿Quiénes Somos?
            </a>

            <a class="navbar-item" href="<?php echo APP_URL; ?>soportePaciente/">
                Soporte y Contacto
            </a>
        </div>
        
        <div class="navbar-end">
            <div class="navbar-item has-dropdown is-hoverable">
                <a class="navbar-link">
                    ** <?php echo $_SESSION['usuario']; ?> **
                </a>
                <div class="navbar-dropdown is-boxed">
                    <a class="navbar-item" href="<?php echo APP_URL."usuarioActualizarPaciente/".$_SESSION['codigo']."/"; ?>">
                        Mi cuenta
                    </a>
                    <a class="navbar-item" href="<?php echo APP_URL."eliminarUsuario/".$_SESSION['codigo']."/"; ?>">
                        Eliminar cuenta
                    </a>
                    <a class="navbar-item" href="<?php echo APP_URL."usuarioFoto/".$_SESSION['codigo']."/"; ?>">
                        Mi foto
                    </a>
                    <hr class="navbar-divider">
                    <a class="navbar-item" href="<?php echo APP_URL."cerrarSesion/"; ?>" id="btn_exit">
                        Salir
                    </a>
                </div>
            </div>
        </div>
    </div>
</nav>