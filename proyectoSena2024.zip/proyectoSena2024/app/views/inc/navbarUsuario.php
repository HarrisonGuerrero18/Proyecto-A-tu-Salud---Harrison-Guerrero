<nav class="navbar has-background-info-light">
    <div class="navbar-brand">
        <a href="<?php echo APP_URL; ?>dashboardUsuario/">
            <img src="<?php echo APP_URL; ?>app/views/img/logo-a-tu-salud.png" alt="A tu Salud" width="65" height="65">
        </a>
        <div class="navbar-burger" data-target="navbarMenu">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </div>
    
    <div id="navbarMenu" class="navbar-menu">
        <div class="navbar-start">
            <a class="navbar-item" href="<?php echo APP_URL; ?>dashboardUsuario/">
                Página de Inicio
            </a>

            <a class="navbar-item" href="<?php echo APP_URL; ?>especialistasInfo/">
                Especialistas
            </a>

            <a class="navbar-item" href="<?php echo APP_URL; ?>quienesSomos/">
                ¿Quiénes Somos?
            </a>

            <a class="navbar-item" href="<?php echo APP_URL; ?>soporteUsuario/">
                Soporte y Contacto
            </a>
        </div>
        
        <div class="navbar-end">
            <a class="button is-success is-rounded is-small mb-4 mr-3 mt-4" href="<?php echo APP_URL; ?>acceso/">
                Iniciar Sesión
            </a>
            <a class="button is-info is-rounded is-small mb-4 mr-3 mt-4" href="<?php echo APP_URL; ?>registrarUsuario/">
                Registrarse
            </a>
        </div>
    </div>
</nav>