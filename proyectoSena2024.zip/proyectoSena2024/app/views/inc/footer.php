<footer class="footer has-background-dark has-text-white-ter"> 
    <div class="content has-text-centered">
        <div class="columns is-vcentered is-centered">
            <div class="column">
                <p>
                    <strong><?php echo APP_NAME; ?></strong> &copy; <?php echo date('Y'); ?>. Todos los derechos reservados.
                </p>
                <p>
                    <a href="<?php echo APP_URL; ?>terminosCondiciones/" class="has-text-grey-light">Términos y Condiciones</a> | 
                    <a href="<?php echo APP_URL; ?>politicaPrivacidad/" class="has-text-grey-light">Política de Privacidad</a>
                </p>
            </div>

            <div class="column">
                <p>Contacto:</p>
                <p>
                    <a href="mailto:hguerrer@arp.edu.co" class="has-text-grey-light">hguerrer@arp.edu.co</a>
                    <br>
                    Teléfono: <a href="tel:+573045955299" class="has-text-grey-light">+57 304 595 5299</a>
                </p>
            </div>

            <div class="column has-text-centered">
                <p>Síguenos en:</p>
                <div class="buttons are-medium is-centered">
                    <a href="https://www.facebook.com/HarrisonDavidGuerreroPalacios" target="_blank" class="button is-link is-light">
                        <span class="icon">
                            <i class="fab fa-facebook fa-lg"></i>
                        </span>
                    </a>

                    <a href="https://wa.me/573045955299" target="_blank" class="button is-success is-light">
                        <span class="icon">
                            <i class="fab fa-whatsapp fa-lg"></i>
                        </span>
                    </a>
                    
                    <a href="https://www.instagram.com" target="_blank" class="button is-danger is-light">
                        <span class="icon">
                            <i class="fab fa-instagram fa-lg"></i>
                        </span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</footer>
