<nav class="navbar has-background-light">
    <div class="navbar-brand">
        <a href="<?php echo APP_URL; ?>dashboard/">
            <img src="<?php echo APP_URL; ?>app/views/img/logo-a-tu-salud.png" alt="A tu Salud" width="65" height="65">
        </a>
        <div class="navbar-burger" data-target="navbarExampleTransparentExample">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </div>
    <div id="navbarExampleTransparentExample" class="navbar-menu">
        <div class="navbar-start">
            <a class="navbar-item" href="<?php echo APP_URL; ?>dashboard/">
                Página de Inicio
            </a>
            <div class="navbar-item has-dropdown is-hoverable">
                <a class="navbar-link" href="#">
                    Usuarios
                </a>
                <div class="navbar-dropdown is-boxed">
                    <a class="navbar-item" href="<?php echo APP_URL; ?>usuarioNuevo/">
                        Nuevo
                    </a>
                    <a class="navbar-item" href="<?php echo APP_URL; ?>usuarioPersonaLista/">
                        Lista de Usuarios y Personas
                    </a>
                    <a class="navbar-item" href="<?php echo APP_URL; ?>usuarioPersonaBuscar/">
                        Buscar
                    </a>
                </div>
            </div>
 
            <div class="navbar-item has-dropdown is-hoverable">
                <a class="navbar-link" href="#">
                    Pacientes
                </a>
                <div class="navbar-dropdown is-boxed">
                    <a class="navbar-item" href="<?php echo APP_URL; ?>pacienteLista/">
                        Lista de Pacientes
                    </a>
                    <a class="navbar-item" href="<?php echo APP_URL; ?>pacienteBuscar/">
                        Buscar
                    </a>
                </div>
            </div>

            <div class="navbar-item has-dropdown is-hoverable">
                <a class="navbar-link" href="#">
                    Especialistas
                </a>
                <div class="navbar-dropdown is-boxed">
                    <a class="navbar-item" href="<?php echo APP_URL; ?>especialistaLista/">
                        Lista de Especialistas
                    </a>
                    <a class="navbar-item" href="<?php echo APP_URL; ?>especialistaBuscar/">
                        Buscar
                    </a>
                </div>
            </div>

            <div class="navbar-item has-dropdown is-hoverable">
                <a class="navbar-link" href="#">
                    Especialidades
                </a>
                <div class="navbar-dropdown is-boxed">
                    <a class="navbar-item" href="<?php echo APP_URL; ?>especialidadNuevo/">
                        Nuevo
                    </a>
                    <a class="navbar-item" href="<?php echo APP_URL; ?>especialidadLista/">
                        Lista de Especialidades
                    </a>
                    <a class="navbar-item" href="<?php echo APP_URL; ?>especialidadBuscar/">
                        Buscar
                    </a>
                </div>
            </div>
        </div>
        
        <div class="navbar-end">
            <div class="navbar-item has-dropdown is-hoverable">
                <a class="navbar-link">
                    ** <?php echo $_SESSION['usuario']; ?> **
                </a>
                <div class="navbar-dropdown is-boxed">
                    <a class="navbar-item" href="<?php echo APP_URL."usuarioActualizar/".$_SESSION['codigo']."/"; ?>">
                        Mi cuenta
                    </a>
                    <a class="navbar-item" href="<?php echo APP_URL."usuarioFoto/".$_SESSION['codigo']."/"; ?>">
                        Mi foto
                    </a>
                    <hr class="navbar-divider">
                    <a class="navbar-item" href="<?php echo APP_URL."cerrarSesion/"; ?>" id="btn_exit">
                        Salir
                    </a>
                </div>
            </div>
        </div>
    </div>
</nav>