<br>
<div class="container is-fluid mb-6">
    <h1 class="title is-spaced has-text-centered">Soporte</h1>
    <h2 class="subtitle has-text-centered">Estamos aquí para ayudarte</h2>
</div>

<div class="has-text-centered">
    <figure class="image is-128x128 is-inline-block">
        <img src="http://localhost/proyectoSena2024/app/views/img/soporteImagen.png" alt="Soporte Técnico">
    </figure>
</div>

<section class="section">
    <div class="container">
        <div class="box has-background-light">
            <h3 class="title is-4">Preguntas Frecuentes</h3>
            <div class="content">
                <ul>
                    <li><strong>¿Cómo puedo agendar una cita?</strong><br>Para agendar una cita, registrate e inicia sesión, luego navega a la sección 'Servicios' y selecciona una especialidad médica.</li>
                    <li><strong>¿Cómo puedo modificar mi información?</strong><br>Accede a tu perfil desde el panel de control y actualiza tus datos personales.</li>
                    <li><strong>¿Cómo puedo contactar a un especialista?</strong><br>Puedes ver los detalles de tus especialistas en la sección 'Mis Especialistas' una vez te hayas registrado.</li>
                </ul>
            </div>
        </div>
    </div>
</section>
<br>
<br>
<br>