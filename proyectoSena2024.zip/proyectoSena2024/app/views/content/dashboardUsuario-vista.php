<?php  
require_once "app/models/modelCrud.php";
$objConsulta = new app\models\modelCrud();
$datosEspecialidad = $objConsulta->seleccionarDatos("Normal", "Especialidad", "especialidadNombre, descripcion, especialidad_foto", ""); 

if ($datosEspecialidad && $datosEspecialidad->rowCount() > 0) {
    $datosEspecialidadArray = $datosEspecialidad->fetchAll(PDO::FETCH_ASSOC);
} else {
    echo "Error: No se obtuvieron datos.";
    $datosEspecialidadArray = []; 
}

$especialidades_json = json_encode($datosEspecialidadArray);
?>

<div class="wrapper">
    <div class="content">
        <div class="container is-fluid">
            <br>
            <header class="has-text-centered mb-5">
                <h1 class="title" style="color: #4a4a4a;">Bienvenido a "A tu Salud"</h1>
                <div class="mb-4">
                    <p class="subtitle" style="color: #7a7a7a;">Una plataforma diseñada para facilitar la gestión de citas entre pacientes y especialistas.</p>
                </div>
            </header>

            <section class="box has-text-centered" style="box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1); border-radius: 10px; background-color: #fff;">
                <h2 class="title" style="padding: 1rem; background-color: #e0f7fa; border-radius: 8px; color: #00796b;">Nuestros Servicios</h2>
                <div id="especialidad-contenido" class="columns is-vcentered is-flex is-justify-content-center">
                    <div class="column is-half">
                        <img id="especialidad-imagen" src="<?php echo APP_URL; ?>app/views/fotos/defaultEspecialidad.png" alt="Especialidad" class="image is-300x300 is-rounded" style="object-fit: cover; border-radius: 15px; width: 100%; height: auto;">
                    </div>
                    <div class="column is-half">
                        <h3 id="especialidad-nombre" class="title has-text-left" style="padding: 1rem; background-color: #f9f9f9; border-radius: 8px; color: #00796b; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);">
                        </h3>
                        <p id="especialidad-descripcion" class="subtitle has-text-left" style="padding: 1rem; background-color: #f9f9f9; border-radius: 8px; color: #333; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);">
                        </p>
                    </div>
                </div>
            </section>

            <section class="box has-text-centered" style="box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1); border-radius: 10px; background-color: #fff;">
                <h2 class="title" style="padding: 1rem; background-color: #e0f7fa; border-radius: 8px; color: #00796b;">Nuestra Ubicación</h2>
                <div class="content">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d1988.4274738203349!2d-74.06589852211633!3d4.619954871114935!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e3f9985888cdc43%3A0x40e37f16967415c8!2sSede%20Asistencial%20La%20Perseverancia!5e0!3m2!1ses-419!2sco!4v1729664946296!5m2!1ses-419!2sco" width="100%" height="450" style="border:0; border-radius: 8px;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
            </section>
        </div>
    </div>
</div>

<script>
    const especialidades = <?php echo $especialidades_json; ?>;

    function mostrarEspecialidad(index) {
        if (especialidades.length === 0) {
            console.error("No hay especialidades disponibles");
            return; 
        }
        
        const especialidad = especialidades[index];
        const imagen = especialidad.especialidad_foto ? 
            '<?php echo APP_URL; ?>app/views/fotos/' + especialidad.especialidad_foto : 
            '<?php echo APP_URL; ?>app/views/fotos/defaultEspecialidad.png';
        
        document.getElementById('especialidad-imagen').src = imagen;
        document.getElementById('especialidad-nombre').textContent = especialidad.especialidadNombre;
        document.getElementById('especialidad-descripcion').textContent = especialidad.descripcion;
    }

    mostrarEspecialidad(0); 

    let index = 0;
    setInterval(() => {
        index = (index + 1) % especialidades.length; 
        mostrarEspecialidad(index);
    }, 5000); 
</script>