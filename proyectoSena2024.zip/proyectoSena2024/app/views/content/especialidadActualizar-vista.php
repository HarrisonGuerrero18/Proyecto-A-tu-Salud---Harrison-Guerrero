<div class="container is-fluid mb-6">
    <?php 
        $especialidadCodigo = $objAcceso->limpiarCadena($url[1]);
    ?>

<div class="container pb-6 pt-6">
    <?php
        include "./app/views/inc/btn_back.php";

        $datosEspecialidad = $objAcceso->seleccionarDatos("Unico", "Especialidad", "especialidadCodigo", $especialidadCodigo);
        
        $datos = $datosEspecialidad->fetch();
    ?>
    
    <h2 class="title has-text-centered"><?php echo $datos['especialidadNombre']; ?></h2>
    
    <p class="has-text-centered pb-6"><?php echo "<strong>Especialidad creada:</strong> " . date("d-m-Y  h:i:s A", strtotime($datos['especialidad_creada'])) . " &nbsp; <strong>Especialidad actualizada:</strong> " . date("d-m-Y  h:i:s A", strtotime($datos['especialidad_actualizada'])); ?></p>



<div class="container pb-6 pt-6">

    <form class="FormularioAjax" action="<?php echo APP_URL; ?>app/ajax/especialidadAjax.php" method="POST" autocomplete="off" enctype="multipart/form-data">
        <input type="hidden" name="modulo_especialidad" value="actualizar">
        <input type="hidden" name="especialidadCodigo" value="<?php echo $datos['especialidadCodigo']; ?>">

        <div class="columns">
            <div class="column">
                <div class="control">
                <label class="label">Nombre de la Especialidad:</label>
                <input class="input" type="text" name="especialidadNombre" pattern="[a-zA-ZáéíóúÁÉÍÓÚñÑ ]{5,30}" maxlength="30" value="<?php echo $datos['especialidadNombre'];?>" required>
                </div>
            </div>
        </div>

        <div class="columns">
            <div class="column">
                <div class="control">
                    <label class="label">Descripción:</label>
                    <textarea class="textarea" name="descripcion" maxlength="255" required><?php echo $datos['descripcion']; ?></textarea>
                </div>
            </div>
        </div>

        <div class="columns">
            <div class="column">
                <div class="control">
                    <label class = "label">Duración (En Horas, minutos y segundos):</label>
                    <input class = "input" type="text" name="duracion" placeholder="HH:MM:SS" pattern="([01][0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]" value = "<?php echo $datos['duracion'];?>" required>

                </div>
            </div>

            <div class="column">
                <div class="control">
                    <label class = "label">Costo (Se permiten Decimales):</label>
                    <input class="input" type="number" name="costo" step="0.01" min="0" value="<?php echo $datos['costo'];?>" required>
                </div>
            </div>

        </div>

        <div class="columns">
            <div class="column">
                <div class="control">
                    <label class = "label">Días de la semana disponibles:</label>
                    <input class="input" type="text" name="diaSemana" pattern="[a-zA-ZáéíóúÁÉÍÓÚñÑ, ]{5,50}" maxlength="50" placeholder="Lunes, Martes, Miércoles..." value="<?php echo $datos['diaSemana'];?>" required>
                </div>
            </div>
        </div>
        <p class="has-text-centered">
            Para poder actualizar los datos de esta Especialidad por favor ingrese su USUARIO y CLAVE con la que ha iniciado sesión
        </p>
        <div class="columns">
            <div class="column">
                <div class="control">
                    <label class = "label has-text-danger">Usuario o Correo</label>
                    <input class="input" type="text" name="administrador_usuario" pattern="[a-zA-Z0-9\s@.]{8,35}" maxlength="35" required>
                </div>
            </div>
            <div class="column">
                <div class="control">
                    <label class = "label has-text-danger">Clave</label>
                    <input class="input" type="password" name="administrador_clave" pattern="[a-zA-Z0-9$@.-]{3,100}" maxlength="100" required>
                </div>
            </div>
        </div>
        <br>
        <p class="has-text-centered">
            <button type="reset" class="button is-link is-light is-rounded">Limpiar</button>
            <button type="submit" class="button is-info is-rounded">Guardar Especialidad</button>
        </p>
    </form>
</div>