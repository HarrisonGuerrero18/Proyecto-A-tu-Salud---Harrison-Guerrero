<?php
use app\controllers\controllerPaciente;

if ($_SESSION['rol'] != "Paciente" || empty($_SESSION['pacienteCodigo'])) {
    include "./app/views/inc/error_alert.php";
    session_destroy();
} else {
    $pacienteController = new controllerPaciente();
    
    $historialCitas = $pacienteController->verHistorialCitas($_SESSION['pacienteCodigo']);
?>
<br>
<div class="container is-fluid mb-6">
    <h1 class="title is-spaced has-text-centered">Historial de Tus Citas Realizadas</h1>
    <h2 class="subtitle has-text-centered">Completadas y Rechazadas</h2>
</div>

<div class="container pb-6 pt-6">
    <div class="form-rest mb-6 mt-6">
        <?php if (empty($historialCitas)): ?>
            <div class="notification is-info has-text-centered">
                No tienes citas completadas o rechazadas.
            </div>
        <?php else: ?>
            <table class="table is-fullwidth is-striped is-hoverable">
                <thead>
                    <tr>
                        <th>Fecha y Hora</th>
                        <th>Día Semana</th>
                        <th>Estado Anterior</th>
                        <th>Estado Actual</th>
                        <th>Especialidad</th>
                        <th>Especialista</th>
                        <th>Sexo</th>
                        <th>Edad</th>
                        <th>  PDF</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($historialCitas as $cita): ?>
                        <tr>
                            <td><?= htmlspecialchars($cita['fecha_modificacion']) ?></td>
                            <td><?= htmlspecialchars($cita['diaSemana']) ?></td>
                            <td>
                                <span class="tag is-info"><?= htmlspecialchars($cita['estado_anterior']) ?></span>
                            </td>
                            <td>
                                <?php if ($cita['estado_nuevo'] == 'Completada'): ?>
                                    <span class="tag is-success"><?= htmlspecialchars($cita['estado_nuevo']) ?></span>
                                <?php elseif ($cita['estado_nuevo'] == 'Cancelada'): ?>
                                    <span class="tag is-danger"><?= htmlspecialchars($cita['estado_nuevo']) ?></span>
                                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars($cita['especialidadNombre']) ?></td>
                            <td><?= htmlspecialchars($cita['nombre']) ?> <?= htmlspecialchars($cita['apellido']) ?></td>
                            <td><?= htmlspecialchars($cita['sexo']) ?></td>
                            <td><?= htmlspecialchars($cita['edad']) ?></td>
                            <td>
                                <a href="http://localhost/proyectoSena2024/app/controllers/descargarHistorialCitaPDF.php?citaID=<?= htmlspecialchars($cita['citaCodigo']) ?>" target="_blank" class="button is-small is-link">Descargar PDF</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<?php
}
?>
