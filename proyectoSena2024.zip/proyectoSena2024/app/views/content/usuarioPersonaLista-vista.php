<?php 
use app\controllers\controllerAdministrador;

    if ($_SESSION['rol'] != "Administrador" || empty($_SESSION['adminCodigo'])) {
		include "./app/views/inc/error_alert.php";
        session_destroy();
	} else {
?>

<br>

<div class="container is-fluid mb-6">
    <h1 class="title is-spaced has-text-centered">Usuarios y Personas</h1>
    <h2 class="subtitle has-text-centered">Lista de Usuarios y Personas</h2>
    
    <div class="buttons has-addons is-centered">
        <button class="button is-link" id="btnUsuarios" onclick="mostrarUsuarios()">Ver Usuarios</button>
        <button class="button is-info" id="btnPersonas" onclick="mostrarPersonas()">Ver Personas</button>
    </div>
</div>

<div class="container pb-6 pt-6">
    <div class="form-rest mb-6 mt-6">

        <div id="tablaUsuarios" style="display:block;">
            <h2 class="subtitle has-text-centered">Lista de Usuarios</h2>
            <?php
                $objUsuariosPersonas = new controllerAdministrador();
                echo $objUsuariosPersonas->listarUsuario($url[1], 10, $url[0], "", $_SESSION['codigo']);
            ?>
        </div>

        <div id="tablaPersonas" style="display:none;">
            <h2 class="subtitle has-text-centered">Lista de Personas</h2>
            <?php
                echo $objUsuariosPersonas->listarPersona($url[1], 10, $url[0], "", $_SESSION['codigo']);
            ?>
        </div>
    </div>
</div>
<?php 
    } 
?>
