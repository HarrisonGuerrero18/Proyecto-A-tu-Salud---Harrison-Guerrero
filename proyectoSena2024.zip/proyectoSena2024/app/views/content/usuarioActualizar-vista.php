<?php 
	if ($_SESSION['rol'] != "Administrador" || empty($_SESSION['adminCodigo'])) {
		include "./app/views/inc/error_alert.php";
		session_destroy();
	} else {
?>
<br>
<div class="container is-fluid mb-6">
    <?php 
        $usua_codigo = $objAcceso->limpiarCadena($url[1]);

        if ($usua_codigo == $_SESSION['codigo']) { 
    ?>
    
    <h1 class="title is-spaced has-text-centered">Mi cuenta de Administrador</h1>
    <h2 class="subtitle has-text-centered">Actualizar cuenta</h2>
    
    <?php } else { ?>
    <h1 class="title subtitle is-spaced has-text-centered">Usuarios</h1>
    <h2 class="subtitle has-text-centered">Actualizar usuario</h2>
    <?php } ?>
</div>

<div class="container pb-6 pt-6">
    <?php
        include "./app/views/inc/btn_back.php";
        
        $datosUsuario = $objAcceso->seleccionarDatos("Unico", "usuario", "usua_codigo", $usua_codigo);
        $datosPersona = $objAcceso->seleccionarDatos("Unico", "persona", "usua_codigo_fk", $usua_codigo);
        
        if ($datosUsuario->rowCount() == 1 && $datosPersona->rowCount() == 1) {
            $datosUsuario = $datosUsuario->fetch(PDO::FETCH_ASSOC);
            $datosPersona = $datosPersona->fetch(PDO::FETCH_ASSOC);
            $datos = array_merge($datosUsuario, $datosPersona);
    ?>
    
    <h2 class="title has-text-centered"><?php echo $datos['nombre'] . " " . $datos['apellido']; ?></h2>
    
    <p class="has-text-centered pb-6"><?php echo "<strong>Usuario creado:</strong> " . date("d-m-Y  h:i:s A", strtotime($datos['usuario_creado'])) . " &nbsp; <strong>Usuario actualizado:</strong> " . date("d-m-Y  h:i:s A", strtotime($datos['usuario_actualizado'])); ?></p>
    
    <form class="FormularioAjax" action="<?php echo APP_URL; ?>app/ajax/administradorAjax.php" method="POST" autocomplete="off">

        <input type="hidden" name="modulo_administrador" value="actualizar">
        <input type="hidden" name="usua_codigo" value="<?php echo $datos['usua_codigo']; ?>">

        <div class="columns">
            <div class="column">
                <div class="control">
                    <label class="label">Nombre:</label>
                    <input class="input" type="text" name="nombre" pattern="[a-zA-ZáéíóúÁÉÍÓÚñÑ ]{3,40}" maxlength="40" value="<?php echo $datos['nombre'];?>" required>
                </div>
            </div>
            <div class="column">
                <div class="control">
                    <label class="label">Apellido:</label>
                    <input class="input" type="text" name="apellido" pattern="[a-zA-ZáéíóúÁÉÍÓÚñÑ ]{3,40}" maxlength="40" value="<?php echo $datos['apellido'];?>" required>
                </div>
            </div>
        </div>

        <div class="columns">
            <div class="column">
                <div class="control">
                    <label class="label">Correo electrónico:</label>
                    <input class="input" type="email" name="correo" maxlength="40" value="<?php echo $datos['correo'];?>" required>
                </div>
            </div>
            <div class="column">
                <div class="control">
                    <label class="label">Nombre de Usuario:</label>
                    <input class="input" type="text" name="usua_usuario" pattern="[a-zA-Z0-9\s ]{8,35}" maxlength="35" value="<?php echo $datos['usua_usuario'];?>" required>
                </div>
            </div>
        </div>

        <div class="columns">
            <div class="column">
                <div class="control">
                    <label class="label">Identificación:</label>
                    <input class="input" type="number" name="identificacion" pattern="[0-9]{8,13}" maxlength="13" value="<?php echo $datos['identificacion'];?>" required>
                </div>
            </div>

            <div class="column">
                <div class="control">
                    <label class="label">Edad:</label>
                    <input class="input" type="" name="edad" pattern="[0-9]{1,2}" maxlength="2" value="<?php echo $datos['edad'];?>" required>
                </div>
            </div>
        </div>

        <div class="columns">
            <div class="column">
                <div class="control">
                    <label class = "label">Celular:</label>
                    <input class="input" type="tel" name="celular" pattern = "[0-9]{10}" maxlength = "10" value="<?php echo $datos['celular'];?>" required>
                </div>
            </div>

            <div class="column">
                <div class="control">
                    <label class="label">Teléfono 2 (Opcional):</label>
                    <input class="input" type="tel" name="telef2" pattern = "[0-9]{10,15}" maxlength = "15" value="<?php echo $datos['telef2'];?>">
                </div>
            </div>
        </div>

        <div class="columns">
            <div class="column">
                <div class="control">
                    <label class="label">Dirección (Opcional):</label>
                    <input class="input" type="text" name="direccion" pattern="[a-zA-Z0-9\s ]{10,100}" maxlength="100" value="<?php echo $datos['direccion'];?>">
                </div>
            </div>

            <div class="column">
                <div class="select">
                    <label class="label">Tipo de Documento:</label> 
                    <select name="tipoID" class="select" required> 
                        <option value="" disabled selected>Seleccione su tipo de Identificación</option> 					
                        <option value="CC">Cédula de Ciudadanía</option> 
                        <option value="TI">Tarjeta de Identidad</option> 
                    </select>
                </div>
            </div>
        </div>

        <br><br>
        <p class="has-text-centered">
            Si desea actualizar la clave de este usuario por favor llene los 2 campos. Si NO desea actualizar la clave deje los campos vacíos.
        </p>
        <br>
        <div class="columns">
            <div class="column">
                <div class="control">
                    <label class="label has-text-danger">Nueva clave</label>
                    <input class="input" type="password" name="usuario_clave_1" pattern="[a-zA-Z0-9$@.-]{3,100}" maxlength="100">
                </div>
            </div>
            <div class="column">
                <div class="control">
                    <label class="label has-text-danger">Repetir nueva clave</label>
                    <input class="input" type="password" name="usuario_clave_2" pattern="[a-zA-Z0-9$@.-]{3,100}" maxlength="100">
                </div>
            </div>
        </div>

        <br><br><br>
        <p class="has-text-centered">
            Para poder actualizar los datos de este usuario por favor ingrese su USUARIO y CLAVE con la que ha iniciado sesión
        </p>
        <div class="columns">
            <div class="column">
                <div class="control">
                    <label class="label has-text-danger">Usuario o Correo</label>
                    <input class="input" type="text" name="administrador_usuario" pattern="[a-zA-Z0-9\s@.]{8,35}" maxlength="35" required>
                </div>
            </div>
            <div class="column">
                <div class="control">
                    <label class="label has-text-danger">Clave</label>
                    <input class="input" type="password" name="administrador_clave" pattern="[a-zA-Z0-9$@.-]{3,100}" maxlength="100" required>
                </div>
            </div>
        </div>
        <p class="has-text-centered">
            <button type="submit" class="button is-success is-rounded">Actualizar</button>
        </p>
    </form>

    <?php
        } else {
            include "./app/views/inc/error_alert.php";
		    session_destroy();

        }
    ?>
</div>
<?php 

	} 

?>