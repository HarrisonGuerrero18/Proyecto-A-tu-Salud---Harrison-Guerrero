<?php
use app\controllers\controllerPaciente;

if ($_SESSION['rol'] != "Paciente" || empty($_SESSION['pacienteCodigo'])) {
    include "./app/views/inc/error_alert.php";
    session_destroy();
} else {
    $pacienteController = new controllerPaciente();
    
    $citasAgendadas = $pacienteController->verCitasAgendadas($_SESSION['pacienteCodigo']);
?>
<br>
<div class="container is-fluid mb-6">
    <h1 class="title is-spaced has-text-centered">Citas Agendadas</h1>
    <h2 class="subtitle has-text-centered">Citas Agendadas por Ti</h2>
</div>

<div class="container pb-6 pt-6">
    <div class="form-rest mb-6 mt-6">
        <?php if (empty($citasAgendadas)): ?>
            <div class="notification is-info has-text-centered">
                No tienes citas pendientes.
            </div>
        <?php else: ?>
            <table class="table is-fullwidth is-striped is-hoverable">
                <thead>
                    <tr>
                        <th>Fecha</th>
                        <th>Hora de Inicio</th>
                        <th>Hora de Fin</th>
                        <th>Especialidad</th>
                        <th>Paciente</th>
                        <th>Género</th>
                        <th>Edad</th>
                        <th>Cancelar Cita</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($citasAgendadas as $cita): ?>
                        <tr>
                            <td><?= htmlspecialchars($cita['fecha']) ?></td>
                            <td><?= htmlspecialchars($cita['horaInicio']) ?></td>
                            <td><?= htmlspecialchars($cita['horaFin']) ?></td>
                            <td><?= htmlspecialchars($cita['especialidadNombre']) ?></td>
                            <td><?= htmlspecialchars($cita['nombre']) ?> <?= htmlspecialchars($cita['apellido']) ?></td>
                            <td><?= htmlspecialchars($cita['sexo']) ?></td>
                            <td><?= htmlspecialchars($cita['edad']) ?></td>
                            <td>
                                <button class="button is-danger cancel-btn" data-cita-id="<?= htmlspecialchars($cita['citaCodigo']) ?>">Cancelar</button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<div id="modal-cancelar-cita" class="modal">
    <div class="modal-background"></div>
    <div class="modal-card">
        <header class="modal-card-head">
            <p class="modal-card-title">Cancelar Cita</p>
            <button class="delete close-cancel-modal" aria-label="close" onclick="closeCancelarModal()"></button>
        </header>
        <section class="modal-card-body">
            <form class="FormularioAjax" action="<?php echo APP_URL; ?>app/ajax/citaAjax.php" method="POST" autocomplete="off">
                <input type="hidden" name="modulo_cita" value="cancelar_cita_paciente">
                <input type="hidden" name="citaCodigo" value="<?= htmlspecialchars($cita['citaCodigo']) ?>">
                <div class="field">
                    <label class="label">Motivo de Cancelación</label>
                    <div class="control">
                        <textarea class="textarea" name="motivo" rows="4" placeholder="Describe el motivo de la cancelación" maxlength="255" required></textarea>
                    </div>
                </div>
                <footer class="modal-card-foot">
                    <button type="submit" class="button is-danger">Confirmar cancelación</button>
                    <button class="button" onclick="closeCancelarModal()">Cancelar</button>
                </footer>
            </form>
        </section>
    </div>
</div>
<?php

    }

?>