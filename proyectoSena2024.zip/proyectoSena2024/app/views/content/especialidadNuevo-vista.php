<br>
<div class = "container is-fluid mb-6">
	<h1 class = "title is-spaced has-text-centered">Especialidad</h1>
	<h2 class = "subtitle has-text-centered">Nueva especialidad</h2>
</div>

<div class = "container pb-6 pt-6">

    <form class="FormularioAjax" action="<?php echo APP_URL; ?>app/ajax/especialidadAjax.php" method="POST" autocomplete="off" enctype="multipart/form-data">
        <input type="hidden" name="modulo_especialidad" value="registrar">

        <div class="columns">
            <div class="column">
                <div class="control">
                    <label class = "label">Nombre de la Especialidad:</label>
                    <input class="input" type="text" name="especialidadNombre" pattern="[a-zA-ZáéíóúÁÉÍÓÚñÑ ]{5,30}" maxlength="30">
                </div>
            </div>
        </div>
    
        <div class="columns">
            <div class="column">
                <div class="control">
                    <label class = "label">Descripción:</label>
                    <textarea class="textarea" name="descripcion" maxlength="255" required></textarea>
                </div>
            </div>
        </div>
    
        <div class="columns">
            <div class="column">
                <div class="control">
                    <label class = "label">Duración (En Horas, minutos y segundos):</label>
                    <input class = "input" type="text" name="duracion" placeholder="HH:MM:SS" pattern="([01][0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]" required>
                </div>
            </div>
    
            <div class="column">
                <div class="control">
                    <label class = "label">Costo (en formato decimal):</label>
                    <input class="input" type="number" name="costo" step="0.01" min="0" required>
                </div>
            </div>
        </div>
    
        <div class="columns">
            <div class="column">
                <div class="control">
                    <label class = "label">Días de la semana disponibles:</label>
                    <input class = "input" type="text" name="diaSemana" pattern="[a-zA-ZáéíóúÁÉÍÓÚñÑ, ]{5,255}" maxlength="50" placeholder="Lunes, Martes, Miércoles..." required>
                </div>
            </div>
        </div>
    
        <div class="columns">
            <div class="column">
                <div class="file has-name is-boxed">
                    <label class="file-label">
                    <input class="file-input" type="file" name="especialidad_foto" accept=".jpg, .png, .jpeg">
                        <span class="file-cta">
                            <span class="file-label">Seleccione una foto</span>
                        </span>
                        <span class="file-name">JPG, JPEG, PNG. (MAX 5MB)</span>
                    </label>
                </div>
            </div>
        </div>
    
        <br>
        <p class="has-text-centered">
            <button type="reset" class="button is-link is-light is-rounded">Limpiar</button>
            <button type="submit" class="button is-info is-rounded">Guardar Especialidad</button>
        </p>
    </form>
</div>