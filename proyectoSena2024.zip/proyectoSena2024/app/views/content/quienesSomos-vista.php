<br>
<div class="container is-fluid mb-6">
    <h1 class="title has-text-centered has-text-info">¿Quiénes Somos?</h1>
</div>

<div class="container is-fluid mb-6">
    <div class="content">
        <p>
            Soy <strong>Harrison Guerrero</strong>, estudiante de grado once y aprendiz en la técnica de <strong>'Diseño y Desarrollo de Software'</strong>. He desarrollado este proyecto con dedicación y esfuerzo, con el objetivo de crear un sistema eficiente y fácil de usar para agendar citas médicas, así como para que los especialistas registrados puedan atenderlas. A continuación, presento la misión, visión y objetivos de mi proyecto.
        </p>
    </div>

    <div class="box has-background-light">
        <h2 class="title is-4 has-text-centered has-text-primary">Misión</h2>
        <p>
            El propósito de este proyecto es ofrecer una plataforma ágil y confiable para la gestión de citas médicas, facilitando la interacción entre pacientes y especialistas. A través de un sistema intuitivo y eficiente, buscamos mejorar la experiencia de los usuarios al permitirles agendar y gestionar sus citas de manera rápida, segura y accesible, contribuyendo así a una atención médica más organizada y oportuna.
        </p>
    </div>strong

    <div class="box has-background-light">
        <h2 class="title is-4 has-text-centered has-text-primary">Visión</h2>
        <p>
            Ser una solución líder en el sector de salud digital a nivel local y, en el futuro, expandirnos hacia una plataforma regional que revolucione la forma en que los pacientes accedan a servicios médicos. Aspiramos a convertirnos en una herramienta esencial para la gestión de citas, brindando a los especialistas la posibilidad de optimizar sus agendas y a los pacientes la tranquilidad de acceder a servicios médicos de calidad en cualquier momento y lugar.
        </p>
    </div>

    <div class="box has-background-light">
        <h2 class="title is-4 has-text-centered has-text-primary">Objetivo</h2>
        <p>
            El objetivo principal del proyecto es desarrollar un sistema de agendamiento de citas médicas en línea que sea intuitivo y eficiente, permitiendo a los usuarios gestionar sus citas de forma autónoma y a los especialistas gestionar su disponibilidad de manera efectiva. A corto plazo, el sistema busca integrar notificaciones y correos automáticos para mejorar la comunicación entre los usuarios y los especialistas, ofreciendo un servicio más integral y ágil que contribuya al mejoramiento de la atención médica.
        </p>
    </div>
</div>