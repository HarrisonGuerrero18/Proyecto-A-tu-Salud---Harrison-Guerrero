<br>
<div class="container is-fluid mb-6">
    <h1 class="title is-spaced has-text-centered">Crear cuenta</h1>
    <h2 class="subtitle has-text-centered">Regístrate para acceder a nuestros servicios</h2>
</div>

<div class="container pb-6 pt-6">
    <form class="FormularioAjax" action="<?php echo APP_URL; ?>app/ajax/usuarioAjax.php" method="POST" autocomplete="off" enctype="multipart/form-data">
        <input type="hidden" name="modulo_usuario" value="registrarUsuario_Persona">

        <div class="columns">
            <div class="column">
                <div class="control">
                    <label class="label">Nombre:</label>
                    <input class="input" type="text" name="nombre" pattern="[a-zA-ZáéíóúÁÉÍÓÚñÑ ]{3,40}" maxlength="40" required>
                </div>
            </div>

            <div class="column">
                <div class="control">
                    <label class="label">Apellido:</label>
                    <input class="input" type="text" name="apellido" pattern="[a-zA-ZáéíóúÁÉÍÓÚñÑ ]{3,40}" maxlength="40" required>
                </div>
            </div>
        </div>

        <div class="columns">
            <div class="column">
                <div class="control">
                    <label class="label">Correo electrónico:</label>
                    <input class="input" type="email" name="correo" maxlength="40" required>
                </div>
            </div>

            <div class="column">
                <div class="control">
                    <label class="label">Nombre de Usuario:</label>
                    <input class="input" type="text" name="usua_usuario" pattern="[a-zA-Z0-9\s ]{8,35}" maxlength="35" required>
                </div>
            </div>
        </div>

        <div class="columns">
            <div class="column">
                <div class="control">
                    <label class="label has-text-danger">Clave:</label>
                    <input class="input" type="password" name="usua_clave1" pattern="[a-zA-Z0-9$@.-]{3,100}" maxlength="100" required>
                </div>
            </div>

            <div class="column">
                <div class="control">
                    <label class="label has-text-danger">Confirmar Clave:</label>
                    <input class="input" type="password" name="usua_clave2" pattern="[a-zA-Z0-9$@.-]{3,100}" maxlength="100" required>
                </div>
            </div>
        </div>

        <div class="columns">
            <div class="column">
                <div class="control">
                    <label class="label">Identificación:</label>
                    <input class="input" type="text" name="identificacion" pattern = "[0-9]{8,10}" maxlength = "10" required>
                </div>
            </div>

            <div class="column">
                <div class="control">
                    <label class="label">Edad:</label>
                    <input class="input" type="" name="edad" pattern="[0-9]{1,2}" maxlength="2" required>
                </div>
            </div>
        </div>

        <div class="columns">
            <div class="column">
                <div class="control">
                    <label class="label">Celular:</label>
                    <input class="input" type="tel" name="celular" pattern="[0-9]{10}" maxlength="10" required>
                </div>
            </div>

            <div class="column">
                <div class="control">
                    <label class="label">Teléfono 2 (Opcional):</label>
                    <input class="input" type="text" name="telef2" pattern="[0-9]{10}" maxlength="10">
                </div>
            </div>
        </div>

        <div class="columns">
            <div class="column">
                <div class="control">
                    <label class="label">Dirección (Opcional):</label>
                    <input class="input" type="text" name="direccion" pattern="[a-zA-Z0-9\s#\-]{10,100}" maxlength="100">
                </div>
            </div>

            <div class="column">
                <div class="control">
                    <label class="label">Tipo de Documento:</label>
                    <div class="select is-fullwidth">
                        <select name="tipoID" required>
                            <option value="" disabled selected>Seleccione su tipo de Identifiación</option>
                            <option value="CC">Cédula de Ciudadanía</option>
                            <option value="TI">Tarjeta de Identidad</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>

        <div class="columns">
            <div class="column">
                <div class="control">
                    <label class="label">Género:</label>
                    <div class="select is-fullwidth">
                        <select name="sexo" required>
                            <option value="" disabled selected>Seleccione su Género</option>
                            <option value="Masculino">Masculino</option>
                            <option value="Femenino">Femenino</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="column">
                <div class="file has-name is-boxed">
                    <label class="file-label">
                        <input class="file-input" type="file" name="usuario_foto" accept=".jpg, .png, .jpeg">
                        <span class="file-cta">
                            <span class="file-label">Seleccione una foto</span>
                        </span>
                        <span class="file-name">JPG, JPEG, PNG. (MAX 5MB)</span>
                    </label>
                </div>
            </div>
        </div>

        <br>
        <p class="has-text-centered">
            <button type="reset" class="button is-link is-light is-rounded">Limpiar</button>
            <button type="submit" class="button is-info is-rounded">Registrarse</button>
        </p>
    </form>
</div>
