<section class="hero is-info is-medium">
    <div class="hero-body">
        <p class="title has-text-centered">
            Política de Privacidad
        </p>
        <p class="subtitle has-text-centered">
            Última actualización: Octubre 2024
        </p>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="content-section">
            <h2 class="title is-4">Introducción</h2>
            <p>
                En <strong><?php echo APP_NAME; ?></strong>, respetamos su privacidad y nos comprometemos a proteger la información personal que comparte con nosotros.
            </p>
        </div><br>

        <div class="content-section">
            <h2 class="title is-4">Información que Recopilamos</h2>
            <p>
                Recopilamos diferentes tipos de información para diversos fines, incluyendo:
            </p>
            <div class="box">
                <ul>
                    <li>Datos personales como nombre, correo electrónico, y número de teléfono.</li>
                    <li>Información sobre el uso de nuestro servicio, como direcciones IP y cookies.</li>
                </ul>
            </div>
        </div><br>

        <div class="content-section">
            <h2 class="title is-4">Uso de la Información</h2>
            <p>
                Utilizamos los datos recopilados para mejorar nuestros servicios, comunicarnos con usted y cumplir con nuestras obligaciones legales.
            </p>
        </div><br>

        <div class="content-section">
            <h2 class="title is-4">Seguridad de su Información</h2>
            <p>
                La seguridad de su información personal es importante para nosotros, y tomamos medidas adecuadas para protegerla.
            </p>
        </div><br>

        <div class="content-section">
            <h2 class="title is-4">Derechos de los Usuarios</h2>
            <p>
                Usted tiene derecho a acceder, corregir o eliminar su información personal. Para ello, puede ponerse en contacto con nosotros en <a href="mailto:hguerrer@arp.edu.co" class="has-text-link">hguerrer@arp.edu.co</a>.
            </p>
        </div><br>

        <div class="content-section">
            <h2 class="title is-4">Cambios a esta Política</h2>
            <p>
                Nos reservamos el derecho de actualizar esta política en cualquier momento. Cualquier cambio será comunicado a través de esta página.
            </p>
        </div><br>

        <div class="content-section">
            <h2 class="title is-4">Contacto</h2>
            <p>
                Si tiene alguna pregunta sobre esta Política de Privacidad, puede contactarnos a través de <a href="mailto:hguerrer@arp.edu.co" class="has-text-link">hguerrer@arp.edu.co</a>.
            </p>
        </div>
    </div>
</section>
