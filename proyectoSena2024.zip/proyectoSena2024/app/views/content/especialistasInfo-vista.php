<?php
use app\controllers\controllerUsuario;

$controllerUsuario = new controllerUsuario();
$especialistasPorEspecialidad = $controllerUsuario->verEspecialistasPorEspecialidad();
$especialidadActual = null;
?>

<br>
<div class="container is-fluid mb-6">
    <h1 class="title is-spaced has-text-centered">Especialistas Disponibles</h1>
    <h2 class="subtitle has-text-centered">Consulta información de nuestros especialistas separados por especialidad</h2>
</div>

<section class="section">
    <div class="container is-fluid">
        <?php foreach ($especialistasPorEspecialidad as $especialista) { 
            if ($especialidadActual !== $especialista['especialidadNombre']) {
                if ($especialidadActual !== null) {
                    echo "</div></div><br>"; 
                }
                $especialidadActual = $especialista['especialidadNombre'];
                ?>
                <div class="box">
                    <h2 class="title is-4"><?= htmlspecialchars($especialidadActual); ?></h2>
                    <div class="columns is-multiline">
                <?php
            }
            ?>
            <div class="column is-one-quarter">
                <div class="card">
                    <div class="card-image has-text-centered">
                        <figure class="image is-128x128 is-inline-block">
                            <img src="<?= $especialista['usuario_foto'] ? APP_URL . 'app/views/fotos/' . $especialista['usuario_foto'] : APP_URL . 'app/views/fotos/default.png'; ?>" 
                                 alt="Foto de <?= htmlspecialchars($especialista['nombre'] . ' ' . $especialista['apellido']); ?>">
                        </figure>
                    </div>

                    <div class="card-content">
                        <div class="media">
                            <div class="media-content has-text-centered">
                                <p class="title is-4"><?= htmlspecialchars($especialista['nombre'] . ' ' . $especialista['apellido']); ?></p>
                            </div>
                        </div>
                        <footer class="card-footer">
                            <div class="content has-text-left">
                                <p class="label">Usuario:</p> <p><?= htmlspecialchars($especialista['usua_usuario']); ?></p>
                                <p class="label">Sexo:</p> <p><?= htmlspecialchars($especialista['sexo']); ?></p>
                                <p class="label">Edad:</p> <p><?= htmlspecialchars($especialista['edad']); ?> años</p>
                            </div>
                        </footer>
                    </div>
                </div>
            </div>
        <?php } ?>
        </div> 
    </div>
</section>
