<?php
use app\controllers\controllerEspecialista;

if ($_SESSION['rol'] != "Especialista" || empty($_SESSION['especialistaCodigo'])) {
    include "./app/views/inc/error_alert.php";
    session_destroy();
} else {
    $especialistaController = new controllerEspecialista();
    $pacientes = $especialistaController->verMisPacientes($_SESSION['especialistaCodigo']);
?>
<br>
<div class="container is-fluid mb-6">
    <h1 class="title is-spaced has-text-centered">Mis Pacientes</h1>
    <h2 class="subtitle has-text-centered">Pacientes que haz atendido</h2>
</div>

<section class="section">
    <div class="container is-fluid">
        <?php if (!empty($pacientes)) { ?>
            <div class="columns is-multiline">
                <?php foreach ($pacientes as $paciente) { ?>
                    <div class="column is-one-quarter">
                        <div class="card">
                            <div class="card-image has-text-centered">
                                <br>
                                <figure class="image is-128x128 is-inline-block">
                                    <img src="<?= $paciente['usuario_foto'] ? APP_URL . 'app/views/fotos/' . $paciente['usuario_foto'] : APP_URL . 'app/views/fotos/default.png'; ?>" 
                                         alt="Foto de <?= htmlspecialchars($especialista['nombre'] . ' ' . $paciente['apellido']); ?>">
                                </figure>
                            </div>

                            <div class="card-content">
                                <div class="media">
                                    <div class="media-content has-text-centered">
                                        <p class="title is-4"><?= htmlspecialchars($paciente['nombre'] . ' ' . $paciente['apellido']); ?></p>
                                    </div>
                                </div>
                                <footer class="card-footer">
                                    <div class="content has-text-left">
                                        <p class="label">Especialidad:</p> <p><?= htmlspecialchars($paciente['especialidadNombre']); ?>
                                        <p class="label">Sexo:</p> <p><?= htmlspecialchars($paciente['sexo']); ?>
                                        <p class="label">Edad:</p> <p><?= htmlspecialchars($paciente['edad']); ?> años
                                    </div>
                                </footer>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
        <?php } else { ?>
            <div class="notification is-warning has-text-centered">
                <h2 class="title">No tienes Pacientes asociados aún.</h2>
            </div>
        <?php } ?>
    </div>
</section>

<?php
}
?>
