<div class="main-container">
    <div class="box recuperar has-background-white">
        <form class="FormularioAjax" action="<?php echo APP_URL; ?>app/ajax/usuarioAjax.php" method="POST" autocomplete="off">
            <input type="hidden" name="modulo_usuario" value="recuperar_contrasena">

            <p class="title is-spaced is-2 has-text-centered has-text-info">Recupera tu Cuenta</p>
            <p class="subtitle is-6 has-text-centered">Ingresa tu correo electrónico o nombre de usuario, tu número de identificación, el tipo de documento y selecciona tu rol para buscar tu cuenta</p>

            <div class="field">
                <label class="label"><i class="fas fa-user-secret"></i> &nbsp; Usuario o Correo</label>
                <div class="control">
                    <input class="input is-rounded" type="text" name="usuarioCorreo_recuperar" pattern="[a-zA-Z0-9\s@.]{8,35}" maxlength="35" placeholder="Ingrese su usuario o correo" required>
                </div>
            </div>

            <div class="field">
                <label class="label"><i class="fas fa-id-card"></i> &nbsp; Número de Identificación</label>
                <div class="control">
                    <input class="input is-rounded" type="text" name="identificacion_recuperar" pattern="[0-9]{8,13}" maxlength="13" placeholder="Ingrese su número de identificación" required>
                </div>
            </div>

            <div class="field">
                <label class="label"><i class="fas fa-address-card"></i> &nbsp; Tipo ID</label>
                <div class="control">
                    <div class="select is-rounded is-fullwidth">
                        <select name="tipoID_recuperar" required>
                            <option value="" disabled selected>Seleccione su tipo de Documento</option>
                            <option value="TI">Tarjeta de Identidad</option>
                            <option value="CC">Cédula de Ciudadanía</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="field">
                <label class="label"><i class="fas fa-user-tag"></i> &nbsp; Rol</label>
                <div class="control">
                    <div class="select is-rounded is-fullwidth">
                        <select name="rol_recuperar" required>
                            <option value="" disabled selected>Seleccione su rol</option>
                            <option value="Administrador">Administrador</option>
                            <option value="Especialista">Especialista</option>
                            <option value="Paciente">Paciente</option>
                        </select>
                    </div>
                </div>
            </div>

            <p class="has-text-centered mb-4 mt-3">
                <button class="button is-info is-rounded is-fullwidth" type="submit">Recuperar Contraseña</button>
            </p>
        </form>

        <div class="has-text-centered mt-4">
            <p class="is-size-6">
                ¿Ya tienes una cuenta? <a href="<?php echo APP_URL; ?>acceso/" class="has-text-link">Inicia sesión aquí</a>
            </p>
            <p class="is-size-6 mt-2">
                ¿No tienes cuenta? <a href="<?php echo APP_URL; ?>registrarUsuario/" class="has-text-link">Regístrate aquí</a>
            </p>
        </div>
    </div>
</div>
