<div class="main-container">
    <div class="box login has-background-white">

        <form action="" method="POST" autocomplete="on">
            <p class="has-text-centered">
                <i class="fas fa-user-circle fa-5x"></i>
            </p>
		    <h5 class="title is-5 has-text-centered">Inicia sesión con tu cuenta</h5>

            <div class="field">
                <label class="label"><i class="fas fa-user-secret"></i> &nbsp; Usuario o Correo</label>    
                <div class="control">
                    <input class="input is-rounded" type="text" name="acceso_usuario" pattern="[a-zA-Z0-9\s@.]{8,35}" maxlength="35" placeholder="Ingrese su usuario o correo" required>
                </div>
            </div>

            <div class="field">
                <label class="label"><i class="fas fa-key"></i> &nbsp; Clave</label>
                <div class="control">
                    <input class="input is-rounded" type="password" name="acceso_clave" pattern="[a-zA-Z0-9$@.-]{3,100}" maxlength="100" placeholder="Ingrese su contraseña" required>
                </div>
            </div>
            
            <p class="has-text-centered mb-4 mt-3">
                <button class="button is-info is-rounded is-fullwidth" type="submit">Iniciar sesión</button>
            </p>
        </form>

        <div class="has-text-centered mt-4">
            <p class="is-size-6">
                <a href="<?php echo APP_URL; ?>recuperarContrasena/" class="has-text-link">¿Olvidaste tu contraseña?</a>
            </p>
            <p class="is-size-6 mt-2">
                ¿Aún no tienes cuenta? <a href="<?php echo APP_URL; ?>registrarUsuario/" class="has-text-link">Regístrate aquí</a>
            </p>
        </div>
    </div>
</div>

<?php
if(isset($_POST['acceso_usuario']) && isset($_POST['acceso_clave'])){
    $objAcceso->iniciarSesionControlador();
}
?>