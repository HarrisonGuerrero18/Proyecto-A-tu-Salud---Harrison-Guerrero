<?php
use app\controllers\controllerEspecialista;

if ($_SESSION['rol'] != "Especialista" || empty($_SESSION['especialistaCodigo'])) {
    include "./app/views/inc/error_alert.php";
    session_destroy();
} else {
    $especialistaController = new controllerEspecialista();
    $disponibilidad = $especialistaController->verMiDisponibilidad($_SESSION['especialistaCodigo']);
?>
<br>
<div class="container is-fluid mb-6">
    <h1 class="title is-spaced has-text-centered">Mi Disponibilidad</h1>
    <h2 class="subtitle has-text-centered">Detalles de tu Disponibilidad</h2>
</div>

<section class="section">
  <div class="container">

    <div class="box">
      <article class="media">
        <div class="media-left">
          <figure class="image is-128x128">
              <img src="<?php echo $disponibilidad[0]['usuario_foto'] ? APP_URL . 'app/views/fotos/' . $disponibilidad[0]['usuario_foto'] : APP_URL . 'app/views/fotos/default.png'; ?>" 
              alt="Foto de <?= htmlspecialchars($disponibilidad[0]['nombre'] . ' ' . $disponibilidad[0]['apellido']); ?>">
          </figure>
        </div>
        <div class="media-content">
          <div class="content">
            <p>
              <strong>Especialista: </strong>Dr. <?= htmlspecialchars($disponibilidad[0]['nombre'] . ' ' . $disponibilidad[0]['apellido']); ?><br>
              <strong>Especialidad: </strong><?= htmlspecialchars($disponibilidad[0]['especialidadNombre']); ?><br>
              <strong>Descripción: </strong><?= htmlspecialchars($disponibilidad[0]['descripcion']); ?><br>
              <strong>Costo por consulta: </strong>$<?= htmlspecialchars($disponibilidad[0]['costo']); ?><br>
            </p>
          </div>
        </div>
        <div class="media-right">
          <figure class="image is-128x128">
              <img src="<?php echo $disponibilidad[0]['especialidad_foto'] ? APP_URL . 'app/views/fotos/' . $disponibilidad[0]['especialidad_foto'] : APP_URL . 'app/views/fotos/defaultEspecialidad.png'; ?>" 
              alt="Foto de <?= htmlspecialchars($disponibilidad[0]['especialidadNombre']); ?>">
          </figure>
        </div>
      </article>
    </div>

    <div class="table-container">
      <table class="table is-striped is-fullwidth">
        <thead>
          <tr>
            <th>Día de la Semana</th>
            <th>Hora de Inicio</th>
            <th>Hora de Fin</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($disponibilidad as $dispo) { ?>
          <tr>
            <td><?= htmlspecialchars($dispo['diaSemana']); ?></td>
            <td><?= htmlspecialchars($dispo['horaInicio']); ?></td>
            <td><?= htmlspecialchars($dispo['horaFin']); ?></td>
          </tr>
          <?php } ?>
        </tbody>
      </table>
    </div>

    <div class="notification is-info is-light">
      <p><strong>Nota: </strong>Si necesitas modificar tu disponibilidad, contacta al administrador.</p>
    </div>
  </div>
</section>

<?php
}
?>
