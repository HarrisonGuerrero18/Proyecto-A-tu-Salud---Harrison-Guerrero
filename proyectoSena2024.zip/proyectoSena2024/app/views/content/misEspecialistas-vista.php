<?php
use app\controllers\controllerPaciente;

if ($_SESSION['rol'] != "Paciente" || empty($_SESSION['pacienteCodigo'])) {
    include "./app/views/inc/error_alert.php";
    session_destroy();
} else {
    $pacienteController = new controllerPaciente();
    $especialistas = $pacienteController->verMisEspecialistas($_SESSION['pacienteCodigo']);
?>
<br>
<div class="container is-fluid mb-6">
    <h1 class="title is-spaced has-text-centered">Mis Especialistas</h1>
    <h2 class="subtitle has-text-centered">Especialistas que te han atendido</h2>
</div>

<section class="section">
    <div class="container is-fluid">
        <?php if (!empty($especialistas)) { ?>
            <div class="columns is-multiline">
                <?php foreach ($especialistas as $especialista) { ?>
                    <div class="column is-one-quarter">
                        <div class="card">
                            <div class="card-image has-text-centered">
                                <br>
                                <figure class="image is-128x128 is-inline-block">
                                    <img src="<?= $especialista['usuario_foto'] ? APP_URL . 'app/views/fotos/' . $especialista['usuario_foto'] : APP_URL . 'app/views/fotos/default.png'; ?>" 
                                         alt="Foto de <?= htmlspecialchars($especialista['nombre'] . ' ' . $especialista['apellido']); ?>">
                                </figure>
                            </div>

                            <div class="card-content">
                                <div class="media">
                                    <div class="media-content has-text-centered">
                                        <p class="title is-4"><?= htmlspecialchars($especialista['nombre'] . ' ' . $especialista['apellido']); ?></p>
                                    </div>
                                </div>
                                <footer class="card-footer">
                                    <div class="content has-text-left">
                                        <p class="label">Especialidad:</p> <p><?= htmlspecialchars($especialista['especialidadNombre']); ?>
                                        <p class="label">Sexo:</p> <p><?= htmlspecialchars($especialista['sexo']); ?>
                                        <p class="label">Edad:</p> <p><?= htmlspecialchars($especialista['edad']); ?> años
                                    </div>
                                </footer>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
        <?php } else { ?>
            <div class="notification is-warning has-text-centered">
                <h2 class="title">No tienes Especialistas asociados aún.</h2>
            </div>
        <?php } ?>
    </div>
</section>
<?php 

} 

?>