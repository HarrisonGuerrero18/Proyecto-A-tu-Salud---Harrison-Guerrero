<section class="hero is-info is-medium">
    <div class="hero-body">
        <p class="title has-text-centered">
            Términos y Condiciones
        </p>
        <p class="subtitle has-text-centered">
            Vigente desde: Octubre 2024
        </p>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="content-section">
            <h2 class="title is-4">Introducción</h2>
            <p>
                Estos Términos y Condiciones regulan el uso del sitio web <strong><?php echo APP_NAME; ?></strong> y los servicios proporcionados. Al utilizar nuestro sitio, acepta cumplir con estos términos.
            </p>
        </div><br>

        <div class="content-section">
            <h2 class="title is-4">Uso Aceptable</h2>
            <p>
                El uso de nuestro sitio debe ser legal y de acuerdo con las normas aplicables. Está prohibido:
            </p>
            <div class="box">
                <ul>
                    <li>Usar el sitio para fines fraudulentos o ilegales.</li>
                    <li>Publicar contenido ofensivo, difamatorio o que infrinja derechos de terceros.</li>
                </ul>
            </div>
        </div><br>

        <div class="content-section">
            <h2 class="title is-4">Propiedad Intelectual</h2>
            <p>
                Todo el contenido, incluidos textos, imágenes y logotipos, son propiedad de <strong><?php echo APP_NAME; ?></strong> o de terceros licenciantes. No está permitido su uso sin nuestra autorización expresa.
            </p>
        </div><br>

        <div class="content-section">
            <h2 class="title is-4">Modificaciones al Servicio</h2>
            <p>
                Nos reservamos el derecho de modificar, suspender o interrumpir los servicios en cualquier momento sin previo aviso.
            </p>
        </div><br>

        <div class="content-section">
            <h2 class="title is-4">Limitación de Responsabilidad</h2>
            <p>
                En ningún caso seremos responsables por daños o pérdidas derivadas del uso de nuestro sitio o servicios.
            </p>
        </div><br>

        <div class="content-section">
            <h2 class="title is-4">Cambios a los Términos</h2>
            <p>
                Podemos modificar estos Términos y Condiciones en cualquier momento. Las modificaciones serán efectivas al ser publicadas en esta página.
            </p>
        </div><br>

        <div class="content-section">
            <h2 class="title is-4">Contacto</h2>
            <p>
                Si tiene preguntas sobre estos Términos, por favor contáctenos en <a href="mailto:hguerrer@arp.edu.co" class="has-text-link">hguerrer@arp.edu.co</a>.
            </p>
        </div>
    </div>
</section>
