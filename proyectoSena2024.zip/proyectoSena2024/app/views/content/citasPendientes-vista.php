<?php
use app\controllers\controllerEspecialista;

if ($_SESSION['rol'] != "Especialista" || empty($_SESSION['especialistaCodigo'])) {
    include "./app/views/inc/error_alert.php";
} else {
    $especialistaController = new controllerEspecialista();
    
    $citasPendientes = $especialistaController->verCitasPendientes($_SESSION['especialistaCodigo']);
?>
<br>
<div class="container is-fluid mb-6">
    <h1 class="title is-spaced has-text-centered">Citas Pendientes</h1>
    <h2 class="subtitle has-text-centered">Citas Agendadas a ti</h2>
</div>

<div class="container pb-6 pt-6">
    <div class="form-rest mb-6 mt-6">
        <?php if (empty($citasPendientes)): ?>
            <div class="notification is-info has-text-centered">
                No tienes citas pendientes.
            </div>
        <?php else: ?>
            <form class="FormularioAjax" action="<?php echo APP_URL; ?>app/ajax/citaAjax.php" method="POST" autocomplete="off">
                <input type="hidden" name="modulo_cita" value="actualizar_estado_especialista">
                
                <table class="table is-fullwidth is-striped is-hoverable">
                    <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Hora de Inicio</th>
                            <th>Hora de Fin</th>
                            <th>Especialidad</th>
                            <th>Paciente</th>
                            <th>Género</th>
                            <th>Edad</th>
                            <th>Estado</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($citasPendientes as $cita): ?>
                            <tr>
                                <td><?= htmlspecialchars($cita['fecha']) ?></td>
                                <td><?= htmlspecialchars($cita['horaInicio']) ?></td>
                                <td><?= htmlspecialchars($cita['horaFin']) ?></td>
                                <td><?= htmlspecialchars($cita['especialidadNombre']) ?></td>
                                <td><?= htmlspecialchars($cita['nombre']) ?> <?= htmlspecialchars($cita['apellido']) ?></td>
                                <td><?= htmlspecialchars($cita['sexo']) ?></td>
                                <td><?= htmlspecialchars($cita['edad']) ?></td>
                                <td>
                                    <select class="select select-estado" name="estado">
                                        <option value="">Seleccione el estado</option>
                                        <option value="Completada">Completada</option>
                                        <option value="Cancelada">Cancelar</option>
                                    </select>
                                    <div class="has-text-centered contenedorMotivo" style="display:none;">
                                        <label class="label">Motivo de la cancelación:</label>
                                        <textarea class="textarea" name="motivo" rows="4" cols="50" placeholder="Escribe el motivo de la cancelación..." maxlength="255"></textarea>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <div class="has-text-centered" style="height: 100px;">
                    <button type="submit" id="button-select" class="button is-primary">Enviar Actualizaciones</button>
                </div>
                <input type="hidden" name="citaCodigo" value="<?= htmlspecialchars($cita['citaCodigo']) ?>">
            </form>
        <?php endif; ?>
    </div>
</div>
<?php
}
?>
