<?php 
require_once "app/models/modelCrud.php";
$objConsulta = new app\models\modelCrud();
$datosEspecialidad = $objConsulta->seleccionarDatos("Normal", "Especialidad", "*", "");     
?>
<br>
<div class="container is-fluid mb-6">
    <h1 class="title has-text-centered">Servicios Médicos Disponibles</h1>
</div>

<section class="section">
    <div class="container is-fluid">
        <div class="columns is-multiline">
            <?php foreach ($datosEspecialidad as $especialidad): ?>
                <div class="column is-one-third">
                    <div class="box">
                        <div class="card">
                            <div class="card-image">
                                <figure class="image is-4by3">
                                    <img src="<?php echo $especialidad['especialidad_foto'] ? APP_URL . 'app/views/fotos/' . $especialidad['especialidad_foto'] : APP_URL . 'app/views/fotos/defaultEspecialidad.png'; ?>" 
                                         alt="<?php echo htmlspecialchars($especialidad['especialidadNombre']); ?>">
                                </figure>
                            </div>
                            <div class="card-content">
                                <h2 class="title is-4"><?php echo htmlspecialchars($especialidad['especialidadNombre']); ?></h2>
                                <p></p>
                                <p class="subtitle"><?php echo htmlspecialchars($especialidad['descripcion']); ?></p>
                                <p><strong>Duración:</strong> <?php echo htmlspecialchars($especialidad['duracion']); ?> mins</p>
                                <p><strong>Costo:</strong> $<?php echo number_format($especialidad['costo'], 2); ?></p>
                                <p><strong>Días Disponibles:</strong> <?php echo htmlspecialchars($especialidad['diaSemana']); ?></p>
                            </div>
                            <footer class="card-footer">
                                <form class="card-footer-item" method="POST">
                                    <button type="button" class="button is-primary is-fullwidth activar-model-btn" data-especialidad="<?php echo htmlspecialchars($especialidad['especialidadCodigo']); ?>">Agendar Cita</button>
                                </form>
                            </footer>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<div id="modal-cita" class="modal">
    <div class="modal-background"></div>
    <div class="modal-card">
        <header class="modal-card-head">
            <p class="modal-card-title" id="modal-title"></p>
            <button class="delete" aria-label="close" onclick="closeCitaModal()"></button>
        </header>
        <section class="modal-card-body">
            <form class="FormularioAjax" action="<?php echo APP_URL; ?>app/ajax/citaAjax.php" method="POST">
                <input type="hidden" name="modulo_cita" value="agendar">    
                <input type="hidden" name="especialidadCodigo" id="especialidadCodigo">
                
                <div class="field">
                    <label class="label">Fecha</label>
                    <div class="control">
                        <input class="input" type="date" id="diaSemana" name="fecha" required>
                    </div>
                </div>
                
                <div class="field">
                    <label class="label">Hora de inicio</label>
                    <div class="control">
                        <input class="input" type="time" id="horaInicio" name="hora" required>
                    </div>
                </div>
                
                <div class="field">
                    <label class="label">Especialistas Disponibles</label>
                    <div class="control">
                        <div class="select is-fullwidth">
                            <select id="especialistaCodigo" name="especialistaCodigo" required>
                                <option value="">Seleccione un especialista</option>
                            </select>
                        </div>
                    </div>
                </div>
                
                <footer class="modal-card-foot">
                    <button type="submit" class="button is-success">Agendar</button>
                    <button type="button" class="button" onclick="closeCitaModal()">Cancelar</button>
                </footer>
            </form>
        </section>
    </div>
</div>
