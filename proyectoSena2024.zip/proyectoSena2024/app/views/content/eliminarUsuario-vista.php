<?php  
if (!($_SESSION['rol'] == "Especialista" || $_SESSION['rol'] == "Paciente") || 
    empty($_SESSION['especialistaCodigo']) && empty($_SESSION['pacienteCodigo'])) {
    include "./app/views/inc/error_alert.php";
    session_destroy();
} else {
?>
<br>
<?php include "./app/views/inc/btn_back.php"; ?>

<div class="container is-fluid">
    <h1 class="title is-spaced has-text-centered">¿Estás seguro de que quieres irte?</h1>
    <h2 class="subtitle has-text-centered">Lamentaremos verte partir 😢</h2>
    <p class="has-text-centered pb-6">
        Si decides eliminar tu cuenta, perderás acceso a tus datos y esta acción no se podrá deshacer.
    </p>
</div>

<div class="container pb-6 pt-6">
    <div class="box" style="max-width: 400px; margin: 0 auto;">
        <form class="FormularioAjax" action="<?php echo APP_URL; ?>app/ajax/usuarioAjax.php" method="POST" autocomplete="off">
            <input type="hidden" name="modulo_usuario" value="eliminar">
            <input type="hidden" name="usua_codigo" value="<?php echo $_SESSION['codigo']; ?>">

            <p class="has-text-centered">
                <i class="fas fa-user-slash fa-5x"></i>
            </p>
            <h5 class="title is-5 has-text-centered">Eliminar Cuenta</h5>

            <div class="field">
                <label class="label"><i class="fas fa-user-secret"></i> &nbsp; Usuario o Correo:</label>
                <div class="control has-icons-left">
                    <input class="input is-rounded" type="text" name="usuario_correo" pattern="[a-zA-Z0-9\s@.]{8,35}" maxlength="35" placeholder="Ingrese su usuario o correo" required>
                    <span class="icon is-small is-left">
                        <i class="fas fa-user"></i>
                    </span>
                </div>
            </div>

            <div class="field">
                <label class="label"><i class="fas fa-key"></i> &nbsp; Clave:</label>
                <div class="control has-icons-left">
                    <input class="input is-rounded" type="password" name="usuario_clave" pattern="[a-zA-Z0-9$@.-]{3,100}" maxlength="100" placeholder="Ingrese su contraseña" required>
                    <span class="icon is-small is-left">
                        <i class="fas fa-lock"></i>
                    </span>
                </div>
            </div>

            <p class="has-text-centered pt-6">
                <button type="submit" class="button is-danger is-rounded is-fullwidth">Eliminar Cuenta</button>
            </p>

            <div class="has-text-centered mt-4">
                <p class="is-size-6">
                    ¿Segur@ que deseas eliminar tu cuenta? Esta acción es irreversible.
                </p>
            </div>
        </form>
    </div>
</div>


<?php 
}
?>
