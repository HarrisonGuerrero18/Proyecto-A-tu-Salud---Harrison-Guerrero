<?php 
	if ($_SESSION['rol'] == "Especialista" || $_SESSION['rol'] == "Administrador") {
		include "./app/views/inc/error_alert.php";
		session_destroy();
	} else {
        $pacienteCodigo = $_SESSION['pacienteCodigo'];
?>
<br>
<div class="container is-fluid mb-6">
    <h1 class="title is-spaced has-text-centered">Soporte</h1>
    <h2 class="subtitle has-text-centered">Estamos aquí para ayudarte</h2>
</div>

<section class="section">
    <div class="container">
        <div class="box">
            <h3 class="title is-4">Preguntas Frecuentes</h3>
            <div class="content">
                <ul>
                    <li><strong>¿Cómo puedo agendar una cita?</strong><br>Para agendar una cita, navega a la sección 'Servicios' y selecciona una especialidad médica.</li>
                    <li><strong>¿Cómo puedo modificar mi información?</strong><br>Accede a tu perfil desde el panel de control y actualiza tus datos personales.</li>
                    <li><strong>¿Cómo puedo contactar a un especialista?</strong><br>Puedes ver los detalles de tus especialistas en la sección 'Mis Especialistas'.</li>
                </ul>
            </div>
        </div>

        <div class="box">
            <h3 class="title is-4">Formulario de Contacto</h3>
            <form class="FormularioAjax" action="<?php echo APP_URL; ?>app/ajax/pacienteAjax.php" method="POST">
                <input type="hidden" name ="modulo_paciente" value="contacto">

                <div class="field">
                    <label class="label">Nombre</label>
                    <div class="control">
                        <input class="input" type="text" name="nombre" placeholder="Tu nombre" pattern="[a-zA-ZáéíóúÁÉÍÓÚñÑ ]{3,40}" maxlength="40" required>
                    </div>
                </div>
                <div class="field">
                    <label class="label">Correo Electrónico</label>
                    <div class="control">
                        <input class="input" type="email" name="correo" placeholder="Tu correo electrónico" maxlength="40" required>
                    </div>
                </div>
                <div class="field">
                    <label class="label">Mensaje</label>
                    <div class="control">
                        <textarea class="textarea" name="mensaje" placeholder="Escribe tu consulta aquí" maxlength="255" required></textarea>
                    </div>
                </div>
                <div class="field">
                    <div class="control">
                        <button class="button is-link" type="submit">Enviar</button>
                    </div>
                </div>
                
                <input type="hidden" name="pacienteCodigo" value="<?php echo htmlspecialchars($pacienteCodigo); ?>">
            </form>
        </div>
</div>
<?php 

	} 

?>