<?php
    $objAcceso->cerrarSesionControlador();