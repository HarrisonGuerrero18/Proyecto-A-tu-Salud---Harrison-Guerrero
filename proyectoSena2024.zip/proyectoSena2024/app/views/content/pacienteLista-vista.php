<?php 
use app\controllers\controllerAdministrador;

	if ($_SESSION['rol'] != "Administrador" || empty($_SESSION['adminCodigo'])) {
		include "./app/views/inc/error_alert.php";
		session_destroy();
	} else {
?>
<br>
<div class="container is-fluid mb-6">
	<h1 class="title is-spaced has-text-centered">Pacientes</h1>
	<h2 class="subtitle has-text-centered">Lista de Pacientes</h2>
</div>
<div class="container pb-6 pt-6">
	<div class="form-rest mb-6 mt-6">
		<?php
			$objAdministrador = new controllerAdministrador();
			echo $objAdministrador->listarPaciente($url[1], 10, $url[0], "", $_SESSION['codigo']);
		?>
	</div>
</div>
<?php	
	}
?>