<?php
	
	require_once "../../config/app.php";
	require_once "../views/inc/session_start.php";
	require_once "../../autoload.php";
	
	use app\controllers\controllerAdministrador;

	if(isset($_POST['modulo_administrador'])){

		$objUsuario = new controllerAdministrador();

		if($_POST['modulo_administrador']=="registrarUsuario_Persona"){
			echo $objUsuario->registrarUsuarioPersona();
		}

		if($_POST['modulo_administrador']=="eliminar"){
			echo $objUsuario->eliminarUsuarioPersona();
		}

		if($_POST['modulo_administrador']=="actualizar"){
			echo $objUsuario->actualizarUsuarioPersona();
		}
		
	}else{
		session_destroy();
		header("Location: ".APP_URL."acceso/");
	}