<?php
	
	require_once "../../config/app.php";
	require_once "../views/inc/session_start.php";
	require_once "../../autoload.php";
	
	use app\controllers\controllerPaciente;

	if(isset($_POST['modulo_paciente'])){

		$objPaciente = new controllerPaciente();

		if($_POST['modulo_paciente']=="contacto"){
			echo $objPaciente->enviarFormularioDeContacto();
		}
	}else{
		session_destroy();
		header("Location: ".APP_URL."acceso/");
	}