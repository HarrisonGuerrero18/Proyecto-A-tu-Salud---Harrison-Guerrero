<?php
	
	require_once "../../config/app.php";
	require_once "../views/inc/session_start.php";
	require_once "../../autoload.php";
	
	use app\controllers\controllerAdministrador;

	if(isset($_POST['modulo_especialidad'])){

		$objEspecialidad = new controllerAdministrador();

		if($_POST['modulo_especialidad']=="registrar"){
			echo $objEspecialidad->registrarEspecialidad();
		}

        if($_POST['modulo_especialidad']=="actualizar"){
			echo $objEspecialidad->actualizarEspecialidad();
		}

        if($_POST['modulo_especialidad']=="eliminar"){
			echo $objEspecialidad->eliminarEspecialidad();
		}
	}else{
		session_destroy();
		header("Location: ".APP_URL."acceso/");
	}