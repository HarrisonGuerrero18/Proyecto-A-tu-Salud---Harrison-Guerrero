<?php
	
	require_once "../../config/app.php";
	require_once "../views/inc/session_start.php";
	require_once "../../autoload.php";
	
	use app\controllers\controllerPaciente;
	use app\controllers\controllerEspecialista;

	if(isset($_POST['modulo_cita'])){

		$objEspecialista = new controllerEspecialista();
		$objPaciente = new controllerPaciente();


		if($_POST['modulo_cita']=="agendar"){
			echo $objPaciente->agendarCita();
		}

		if($_POST['modulo_cita']=="actualizar_estado_especialista"){
			echo $objEspecialista->actualizarEstadoCita();
		}

		if($_POST['modulo_cita']=="cancelar_cita_paciente"){
			echo $objPaciente->cancelarCita();
		}
		
	}else{
		session_destroy();
		header("Location: ".APP_URL."acceso/");
	}