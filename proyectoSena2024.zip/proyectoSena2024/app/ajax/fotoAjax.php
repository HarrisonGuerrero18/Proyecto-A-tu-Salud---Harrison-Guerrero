<?php
	
	require_once "../../config/app.php";
	require_once "../views/inc/session_start.php";
	require_once "../../autoload.php";
	
	use app\controllers\controllerFotos;

	if(isset($_POST['modulo_foto'])){

		$objUsuario = new controllerFotos();

		if($_POST['modulo_foto']=="eliminarFoto_Usuario"){
			echo $objUsuario->eliminarFotoUsuario();
		}

		if($_POST['modulo_foto']=="actualizarFoto_Usuario"){
			echo $objUsuario->actualizarFotoUsuario();
		}

		if($_POST['modulo_foto']=="eliminarFoto_Especialidad"){
			echo $objUsuario->eliminarFotoEspecialidad();
		}

		if($_POST['modulo_foto']=="actualizarFoto_Especialidad"){
			echo $objUsuario->actualizarFotoEspecialidad();
		}
		
	}else{
		session_destroy();
		header("Location: ".APP_URL."acceso/");
	}