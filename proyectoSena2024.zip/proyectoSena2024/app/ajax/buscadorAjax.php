<?php
	
	require_once "../../config/app.php";
	require_once "../views/inc/session_start.php";
	require_once "../../autoload.php";
	
	use app\controllers\controllerBuscar;

	if(isset($_POST['modulo_buscador'])){

		$objBuscador = new controllerBuscar();

		if($_POST['modulo_buscador']=="buscar"){
			echo $objBuscador->iniciarBuscadorControlador();
		}

		if($_POST['modulo_buscador']=="eliminar"){
			echo $objBuscador->eliminarBuscadorControlador();
		}
	}else{
		session_destroy();
		header("Location: ".APP_URL."dashboardUsuario/");
	}