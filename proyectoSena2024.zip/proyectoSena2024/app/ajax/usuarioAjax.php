<?php
	require_once "../../config/app.php";
	require_once "../views/inc/session_start.php";
	require_once "../../autoload.php";
	
	use app\controllers\controllerUsuario;

	if(isset($_POST['modulo_usuario'])){

		$objUsuario = new controllerUsuario();

		if($_POST['modulo_usuario']=="recuperar_contrasena"){
			echo $objUsuario->recuperarContrasena();
		}

		if($_POST['modulo_usuario']=="registrarUsuario_Persona"){
			echo $objUsuario->registrarUsuarioPersona();
		}		

		if($_POST['modulo_usuario']=="actualizar"){
			echo $objUsuario->actualizarUsuarioPersona();
		}	

		if($_POST['modulo_usuario']=="eliminar"){
			echo $objUsuario->eliminarUsuarioPersona();
		}	
	}else{
		session_destroy();
		header("Location: ".APP_URL."acceso/");
	}