<?php
namespace app\models;
use \PDO;

if(file_exists(__DIR__."/../../config/server.php")){
	require_once __DIR__."/../../config/server.php";
}

class modelCrud {

	private $server=DB_SERVER;
	private $db=DB_NAME;
	private $user=DB_USER;
	private $pass=DB_PASS;

	protected function conectar(){
		$conexion = new PDO("mysql:host=".$this->server.";dbname=".$this->db,$this->user,$this->pass);
		$conexion->exec("SET CHARACTER SET utf8");
		return $conexion;
	}

	protected function ejecutarConsulta($consulta){
		$sql=$this->conectar()->prepare($consulta); 
		$sql->execute();
		return $sql;
	}

	public function limpiarCadena($cadena){

		$palabras=["<script>","</script>","<script src","<script type=","SELECT * FROM","SELECT "," SELECT ","DELETE FROM","INSERT INTO","DROP TABLE","DROP DATABASE","TRUNCATE TABLE","SHOW TABLES","SHOW DATABASES","<?php","?>","--","^","<",">","==","=",";","::"];

		$cadena=trim($cadena);
		$cadena=stripslashes($cadena);

		foreach($palabras as $palabra){
			$cadena=str_ireplace($palabra, "", $cadena);
		}

		$cadena=trim($cadena);
		$cadena=stripslashes($cadena);

		return $cadena;
	}

	protected function verificarDatos($filtro, $cadena) {
		return !preg_match("/".$filtro."/", $cadena);
	}
	
	protected function guardarDatos($tabla, $datos, $conexion) {
		$query = "INSERT INTO $tabla (";
	
		$C = 0;
		foreach ($datos as $clave) {
			if ($C >= 1) { $query .= ","; }
			$query .= $clave["campo_nombre"];
			$C++;
		}
	
		$query .= ") VALUES(";
	
		$C = 0;
		foreach ($datos as $clave) {
			if ($C >= 1) { $query .= ","; }
			$query .= $clave["campo_marcador"];
			$C++;
		}
	
		$query .= ")";
		$sql = $conexion->prepare($query);
	
		foreach ($datos as $clave) {
			$sql->bindParam($clave["campo_marcador"], $clave["campo_valor"]);
		}
	
		$sql->execute();
	
		return $sql;
	}
	
    public function seleccionarDatos($tipo,$tabla,$campo,$codigo){
		$tipo=$this->limpiarCadena($tipo);
		$tabla=$this->limpiarCadena($tabla);
		$campo=$this->limpiarCadena($campo);
		$codigoSesion=$this->limpiarCadena($codigo);

        if($tipo=="Unico"){
            $sql=$this->conectar()->prepare("SELECT * FROM $tabla WHERE $campo=:ID");
            $sql->bindParam(":ID",$codigo);
        }elseif($tipo=="Normal"){
            $sql=$this->conectar()->prepare("SELECT $campo FROM $tabla");
        }
        $sql->execute();
        return $sql;
	}

	protected function actualizarDatos($tabla,$datos,$condicion){
		
		$query="UPDATE $tabla SET ";

		$C=0;
		foreach ($datos as $clave){
			if($C>=1){ $query.=","; }
			$query.=$clave["campo_nombre"]."=".$clave["campo_marcador"];
			$C++;
		}

		$query.=" WHERE ".$condicion["condicion_campo"]."=".$condicion["condicion_marcador"];

		$sql=$this->conectar()->prepare($query);

		foreach ($datos as $clave){
			$sql->bindParam($clave["campo_marcador"],$clave["campo_valor"]);
		}

		$sql->bindParam($condicion["condicion_marcador"],$condicion["condicion_valor"]);

		$sql->execute();

		return $sql;
	}

    protected function eliminarRegistro($tabla,$campo,$usua_codigo){
        $sql=$this->conectar()->prepare("DELETE FROM $tabla WHERE $campo=:Usua_codigo_fk");
        $sql->bindParam(":Usua_codigo_fk",$usua_codigo);
        $sql->execute();
        
        return $sql;
    }

	protected function paginadorTablas($pagina,$numeroPaginas,$url,$botones) {
	       
		$tabla='<nav class="pagination is-centered is-rounded" role="navigation" aria-label="pagination">';

	       if($pagina<=1){
	           $tabla.='
	           <a class="pagination-previous is-disabled" disabled >Anterior</a>
	           <ul class="pagination-list">
	           ';
	       }else{
	           $tabla.='
	           <a class="pagination-previous" href="'.$url.($pagina-1).'/">Anterior</a>
	           <ul class="pagination-list">
	               <li><a class="pagination-link" href="'.$url.'1/">1</a></li>
	               <li><span class="pagination-ellipsis">&hellip;</span></li>
	           ';
	       }


	       $ci=0;
	       for($i=$pagina; $i<=$numeroPaginas; $i++){

	           if($ci>=$botones){
	               break;
	           }

	           if($pagina==$i){
	               $tabla.='<li><a class="pagination-link is-current" href="'.$url.$i.'/">'.$i.'</a></li>';
	           }else{
	               $tabla.='<li><a class="pagination-link" href="'.$url.$i.'/">'.$i.'</a></li>';
	           }

	           $ci++;
	       }

	       if($pagina==$numeroPaginas){
	           $tabla.='
	           </ul>
	           <a class="pagination-next is-disabled" disabled >Siguiente</a>
	           ';
	       }else{
	           $tabla.='
	               <li><span class="pagination-ellipsis">&hellip;</span></li>
	               <li><a class="pagination-link" href="'.$url.$numeroPaginas.'/">'.$numeroPaginas.'</a></li>
	           </ul>
	           <a class="pagination-next" href="'.$url.($pagina+1).'/">Siguiente</a>
	           ';
	       }

	       $tabla.='</nav>';
	       return $tabla;
	}

	public function obtenerDetallesEspecialidad($especialidadCodigo_fk, $conexion) {
		$query = "SELECT diaSemana, duracion FROM Especialidad WHERE especialidadCodigo = :especialidadCodigo";
		
		$stmt = $conexion->prepare($query);
		$stmt->bindParam(':especialidadCodigo', $especialidadCodigo_fk);
		$stmt->execute();
		
		return $stmt->fetch(PDO::FETCH_ASSOC); 
	}
	
	public function obtenerEspecialistasPorEspecialidad($especialidadCodigo_fk) { 
		$especialidadCodigo_fk = $this->limpiarCadena($especialidadCodigo_fk); 
		$sql = $this->conectar()->prepare("SELECT e.especialistaCodigo, p.nombre, p.apellido 
				FROM Especialista e 
				JOIN Persona p 
				ON e.personaCodigo_fk = p.personaCodigo
			WHERE e.especialidadCodigo_fk = :especialidadCodigo
		"); 
	
		$sql->bindParam(":especialidadCodigo", $especialidadCodigo_fk); 
		$sql->execute(); 
		return $sql->fetchAll(PDO::FETCH_ASSOC); 
	} 
	
	public function obtenerDiasPorEspecialidad($especialidadCodigo_fk) {
		$sql = $this->conectar()->prepare("
			SELECT diaSemana
			FROM Especialidad
			WHERE especialidadCodigo = :especialidadCodigo
		");
		
		$sql->bindParam(":especialidadCodigo", $especialidadCodigo_fk);
		$sql->execute();

		$resultado = $sql->fetch(PDO::FETCH_ASSOC);
		
		if ($resultado && isset($resultado['diaSemana'])) {
			$dias = explode(', ', $resultado['diaSemana']);  
			return array_map('trim', $dias); 
		}
		return[];
	}

	public function obtenerHistorialCitasPorEspecialista($especialistaCodigo_fk) {
		$sql = "SELECT c.citaCodigo, e.especialidadNombre, p.nombre, p.apellido, p.sexo, p.edad, h.fecha_modificacion, h.diaSemana, h.estado_anterior, h.estado_nuevo
					FROM Cita c
					INNER JOIN Especialidad e ON c.especialidadCodigo_fk = e.especialidadCodigo
					INNER JOIN Paciente pac ON c.pacienteCodigo_fk = pac.pacienteCodigo
					INNER JOIN Persona p ON pac.personaCodigo_fk = p.personaCodigo
					INNER JOIN historialCita h ON c.citaCodigo = h.citaCodigo_fk
				WHERE c.especialistaCodigo_fk = :especialistaCodigo 
				ORDER BY h.fecha_modificacion DESC";
	
		$consulta = $this->conectar()->prepare($sql);
		$consulta->bindParam(':especialistaCodigo', $especialistaCodigo_fk, PDO::PARAM_INT);
		$consulta->execute();
	
		return $consulta->fetchAll(PDO::FETCH_ASSOC);
	}
	
	public function obtenerCitasPendientesPorEspecialista($especialistaCodigo_fk) {
		$sql = "SELECT c.citaCodigo, c.fecha, c.horaInicio, c.horaFin, c.estado, e.especialidadNombre, p.nombre, p.apellido,p.sexo, p.edad
					FROM Cita c
					INNER JOIN Especialidad e ON c.especialidadCodigo_fk = e.especialidadCodigo
					INNER JOIN Paciente pa ON c.pacienteCodigo_fk = pa.pacienteCodigo
					INNER JOIN Persona p ON pa.personaCodigo_fk = p.personaCodigo
				WHERE c.especialistaCodigo_fk = :especialistaCodigo 
				AND c.estado = 'Agendada'
				ORDER BY c.fecha DESC";
	
		$consulta = $this->conectar()->prepare($sql);
		$consulta->bindParam(':especialistaCodigo', $especialistaCodigo_fk, PDO::PARAM_INT);
		$consulta->execute();
	
		return $consulta->fetchAll(PDO::FETCH_ASSOC);
	}

	public function obtenerHistorialCitasPorPaciente($pacienteCodigo_fk) {
		$sql = "SELECT c.citaCodigo, e.especialidadNombre, p.nombre, p.apellido, p.sexo, p.edad, h.fecha_modificacion, h.diaSemana, h.estado_anterior, h.estado_nuevo
					FROM Cita c
					INNER JOIN Especialidad e ON c.especialidadCodigo_fk = e.especialidadCodigo
					INNER JOIN Especialista es ON c.especialistaCodigo_fk = es.especialistaCodigo
					INNER JOIN Persona p ON es.personaCodigo_fk = p.personaCodigo
					INNER JOIN historialCita h ON c.citaCodigo = h.citaCodigo_fk
				WHERE c.pacienteCodigo_fk = :pacienteCodigo_fk 
				ORDER BY h.fecha_modificacion DESC";
	
		$consulta = $this->conectar()->prepare($sql);
		$consulta->bindParam(':pacienteCodigo_fk', $pacienteCodigo_fk, PDO::PARAM_INT);
		$consulta->execute();
	
		return $consulta->fetchAll(PDO::FETCH_ASSOC);
	}
	
	public function obtenerCitasAgendadasPorPaciente($pacienteCodigo_fk) {
		$sql = "SELECT c.citaCodigo, c.fecha, c.horaInicio, c.horaFin, c.estado, e.especialidadNombre, p.nombre, p.apellido,p.sexo, p.edad
					FROM Cita c
					INNER JOIN Especialidad e ON c.especialidadCodigo_fk = e.especialidadCodigo
					INNER JOIN Especialista es ON c.especialistaCodigo_fk = es.especialistaCodigo
					INNER JOIN Persona p ON es.personaCodigo_fk = p.personaCodigo
				WHERE c.pacienteCodigo_fk = :pacienteCodigo 
				AND c.estado = 'Agendada'
				ORDER BY c.fecha DESC";
	
		$consulta = $this->conectar()->prepare($sql);
		$consulta->bindParam(':pacienteCodigo', $pacienteCodigo_fk, PDO::PARAM_INT);
		$consulta->execute();
	
		return $consulta->fetchAll(PDO::FETCH_ASSOC);
	}

	public function obtenerMisEspecialistas($pacienteCodigo_fk) {
		$sql = "SELECT u.usuario_foto, p.nombre, p.apellido, p.sexo, p.edad, e.especialidadNombre
					FROM Cita c
					JOIN Especialista esp ON c.especialistaCodigo_fk = esp.especialistaCodigo
					JOIN Especialidad e ON esp.especialidadCodigo_fk = e.especialidadCodigo
					JOIN Persona p ON esp.personaCodigo_fk = p.personaCodigo
					JOIN Usuario u ON esp.usua_codigo_fk = u.usua_codigo
				WHERE c.pacienteCodigo_fk = :pacienteCodigo
				AND c.estado = 'Completada'
				GROUP BY esp.especialistaCodigo";

		$consulta = $this->conectar()->prepare($sql);
		$consulta->bindParam(':pacienteCodigo', $pacienteCodigo_fk, PDO::PARAM_INT);
		$consulta->execute();
		return $consulta->fetchAll(PDO::FETCH_ASSOC);
	}

	public function obtenerMisPacientes($especialistaCodigo_fk) {
		$sql = "SELECT u.usuario_foto, p.nombre, p.apellido, p.sexo, p.edad, e.especialidadNombre, pac.pacienteCodigo
					FROM Cita c
					JOIN Paciente pac ON c.pacienteCodigo_fk = pac.pacienteCodigo
					JOIN Especialidad e ON c.especialidadCodigo_fk = e.especialidadCodigo
					JOIN Persona p ON pac.personaCodigo_fk = p.personaCodigo
					JOIN Usuario u ON pac.usua_codigo_fk = u.usua_codigo
				WHERE c.especialistaCodigo_fk = :especialistaCodigo
				AND c.estado = 'Completada'
				GROUP BY pac.pacienteCodigo";

		$consulta = $this->conectar()->prepare($sql);
		$consulta->bindParam(':especialistaCodigo', $especialistaCodigo_fk, PDO::PARAM_INT);
		$consulta->execute();
		return $consulta->fetchAll(PDO::FETCH_ASSOC);
	}

	public function obtenerMiDisponibilidad($especialistaCodigo_fk) {
		$sql = "SELECT u.usuario_foto, p.nombre, p.apellido, especialidad.especialidadNombre, especialidad.descripcion, especialidad.costo, especialidad.especialidad_foto, d.diaSemana, d.horaInicio, d.horaFin 
					FROM usuario u 
					INNER JOIN persona p ON u.usua_codigo = p.usua_codigo_fk 
					INNER JOIN Especialista especialista ON p.personaCodigo = especialista.personaCodigo_fk 
					INNER JOIN Especialidad especialidad ON especialista.especialidadCodigo_fk = especialidad.especialidadCodigo 
					INNER JOIN disponibilidadEspecialista d ON especialista.especialistaCodigo = d.especialistaCodigo_fk 
				WHERE especialista.especialistaCodigo = :especialistaCodigo";

		$consulta = $this->conectar()->prepare($sql);
		$consulta->bindParam(':especialistaCodigo', $especialistaCodigo_fk, PDO::PARAM_INT);
		$consulta->execute();
		return $consulta->fetchAll(PDO::FETCH_ASSOC);
	}

	public function obtenerDetallesCita($especialistaCodigo_fk, $citaID) {
        $sql = $this->conectar()->prepare("SELECT 
			    hc.fecha_modificacion AS fecha_actualizacion,
			    hc.diaSemana AS dia_semana,
			    hc.estado_nuevo AS estado_cita,
			    cc.motivo AS motivo_cancelacion,
			    CONCAT(p.nombre, ' ', p.apellido) AS nombre_paciente,
			    CONCAT(ep.nombre, ' ', ep.apellido) AS nombre_especialista,
			    es.especialidadNombre AS nombre_especialidad,
			    es.duracion AS duracion,
			    es.costo AS costo,
			    c.horaInicio AS hora_inicio,
			    c.horaFin AS horaFin
			FROM 
			    historialCita hc
			JOIN 
			    Cita c ON hc.citaCodigo_fk = c.citaCodigo
			JOIN 
			    Paciente pa ON c.pacienteCodigo_fk = pa.pacienteCodigo
			JOIN
			    Persona p ON pa.personaCodigo_fk = p.personaCodigo
			JOIN
			    Especialista e ON c.especialistaCodigo_fk = e.especialistaCodigo
			JOIN 
			    Persona ep ON e.personaCodigo_fk = ep.personaCodigo  
			JOIN 
			    Especialidad es ON c.especialidadCodigo_fk = es.especialidadCodigo
			LEFT JOIN 
			    cancelacionCita cc ON hc.citaCodigo_fk = cc.citaCodigo_fk
			WHERE 
			    hc.estado_nuevo IN ('Completada', 'Cancelada')
			AND 
			    c.especialistaCodigo_fk = :especialistaCodigo_fk
			AND 
			    hc.citaCodigo_fk = :citaID");

        $sql->bindParam(":especialistaCodigo_fk", $especialistaCodigo_fk, PDO::PARAM_INT);
        $sql->bindParam(":citaID", $citaID, PDO::PARAM_INT);
        
        $sql->execute();

        $resultado = $sql->fetch(PDO::FETCH_ASSOC);

        if (!$resultado) {
            return null;
        }

    	$nombrePaciente = explode(' ', $resultado['nombre_paciente']);
    	$nombreEspecialista = explode(' ', $resultado['nombre_especialista']);

    	return [
    	    'fecha_modificacion' => $resultado['fecha_actualizacion'],
    	    'diaSemana' => $resultado['dia_semana'],
    	    'estado_nuevo' => $resultado['estado_cita'],
    	    'motivo' => $resultado['motivo_cancelacion'],
    	    'paciente_nombre' => $nombrePaciente[0] ?? '', 
    	    'paciente_apellido' => $nombrePaciente[1] ?? '', 
    	    'especialista_nombre' => $nombreEspecialista[0] ?? '', 
    	    'especialista_apellido' => $nombreEspecialista[1] ?? '', 
    	    'especialidad_nombre' => $resultado['nombre_especialidad'],
    	    'duracion' => $resultado['duracion'],
    	    'costo' => $resultado['costo'],
    	    'horaInicio' => $resultado['hora_inicio'],
    	    'horaFin' => $resultado['horaFin'],
    	    'citaCodigo' => $citaID,
    	];
    }
}