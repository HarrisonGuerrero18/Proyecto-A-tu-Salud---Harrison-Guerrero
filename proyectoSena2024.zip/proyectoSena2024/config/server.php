<?php
	const DB_SERVER="localhost";
	const DB_NAME="BD_proyectoSena2024HarrisonGuerrero";
	const DB_USER="root";
	const DB_PASS='';