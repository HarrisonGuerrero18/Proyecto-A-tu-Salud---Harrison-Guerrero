<?php const APP_URL="http://localhost/proyectoSena2024/";
	const APP_NAME="A TU SALUD";
	const APP_SESSION_NAME="proyectoSena2024";

	date_default_timezone_set("America/Bogota");
