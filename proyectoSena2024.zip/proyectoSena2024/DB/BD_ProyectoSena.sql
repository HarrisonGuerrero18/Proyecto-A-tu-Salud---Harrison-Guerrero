CREATE DATABASE BD_proyectoSena2024HarrisonGuerrero;
USE BD_proyectoSena2024HarrisonGuerrero;

CREATE TABLE Usuario (
  usua_codigo INT(11) PRIMARY KEY AUTO_INCREMENT,
  usua_usuario VARCHAR(35) NOT NULL UNIQUE,
  correo VARCHAR(25) NOT NULL UNIQUE,
  usua_clave VARCHAR(100) NOT NULL,
  rol ENUM('Administrador','Especialista','Paciente') NOT NULL,
  usuario_foto VARCHAR(535) NOT NULL,
  usuario_creado TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  usuario_actualizado TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO Usuario (usua_codigo, usua_usuario, correo, usua_clave, rol, usuario_foto, usuario_creado, usuario_actualizado) VALUES
(1, 'Harrison Guerrero', 'hguerrer@arp.edu.co', '$2b$12$pXOG.eO0CSMH0YOWhJxrv.i3mP2MJxd9g7IxJvxz3sF.dkVA9Ulwe', 'Administrador', '', '2024-10-17 12:00:00', '2024-10-17 12:00:00'),
(2, 'Jose Caicedo', 'jcaicedo@arp.edu.co', '$2b$12$pXOG.eO0CSMH0YOWhJxrv.i3mP2MJxd9g7IxJvxz3sF.dkVA9Ulwe', 'Especialista', '', '2024-10-17 12:00:00', '2024-10-17 12:00:00'),
(3, 'Juan Martínez', 'jmartinez@arp.edu.co', '$2b$12$pXOG.eO0CSMH0YOWhJxrv.i3mP2MJxd9g7IxJvxz3sF.dkVA9Ulwe', 'Paciente', '', '2024-10-17 12:00:00', '2024-10-17 12:00:00'),
(4, 'Esteban Peralta', 'eperalta@arp.edu.co', '$2b$12$pXOG.eO0CSMH0YOWhJxrv.i3mP2MJxd9g7IxJvxz3sF.dkVA9Ulwe', 'Paciente', '', '2024-10-17 12:00:00', '2024-10-17 12:00:00'),
(5, 'AndresPerez', 'andrez41@gmail.com', '$2b$12$pXOG.eO0CSMH0YOWhJxrv.i3mP2MJxd9g7IxJvxz3sF.dkVA9Ulwe', 'Especialista', '', '2024-10-17 12:00:00', '2024-10-17 12:00:00'),
(6, 'Brayan Hernandez', 'hernadezbrayan@gmail.com', '$2b$12$pXOG.eO0CSMH0YOWhJxrv.i3mP2MJxd9g7IxJvxz3sF.dkVA9Ulwe', 'Especialista', '', '2024-10-17 12:00:00', '2024-10-17 12:00:00'),
(7, 'PaolaGonzales2000', 'paolagonzales@gmail.com', '$2b$12$pXOG.eO0CSMH0YOWhJxrv.i3mP2MJxd9g7IxJvxz3sF.dkVA9Ulwe', 'Especialista', '', '2024-10-17 12:00:00', '2024-10-17 12:00:00'),
(8, 'miguelmerizalde', 'meizalde15@gmail.com', '$2b$12$pXOG.eO0CSMH0YOWhJxrv.i3mP2MJxd9g7IxJvxz3sF.dkVA9Ulwe', 'Especialista', '', '2024-10-17 12:00:00', '2024-10-17 12:00:00'),
(9, 'victorbecerra', 'victorbecerra@gmail.com', '$2b$12$pXOG.eO0CSMH0YOWhJxrv.i3mP2MJxd9g7IxJvxz3sF.dkVA9Ulwe', 'Especialista', '', '2024-10-17 12:00:00', '2024-10-17 12:00:00'),
(10, 'Maidy12345', 'maidy123@gmail.com', '$2b$12$pXOG.eO0CSMH0YOWhJxrv.i3mP2MJxd9g7IxJvxz3sF.dkVA9Ulwe', 'Especialista', '', '2024-10-17 12:00:00', '2024-10-17 12:00:00'),
(11, 'Felipe Monsalve', 'fmonsalve12@gmail.com', '$2b$12$pXOG.eO0CSMH0YOWhJxrv.i3mP2MJxd9g7IxJvxz3sF.dkVA9Ulwe', 'Especialista', '', '2024-10-17 12:00:00', '2024-10-17 12:00:00'),
(12, 'Cristian Sanchez', 'sanchezcristian4512@gmail.com', '$2b$12$pXOG.eO0CSMH0YOWhJxrv.i3mP2MJxd9g7IxJvxz3sF.dkVA9Ulwe', 'Especialista', '', '2024-10-17 12:00:00', '2024-10-17 12:00:00'),
(13, 'DanielHenao5000', 'danielhn12@gmail.com', '$2b$12$pXOG.eO0CSMH0YOWhJxrv.i3mP2MJxd9g7IxJvxz3sF.dkVA9Ulwe', 'Especialista', '', '2024-10-17 12:00:00', '2024-10-17 12:00:00'),
(14, 'CamiloPachon', 'cpachon50@gmail.com', '$2b$12$pXOG.eO0CSMH0YOWhJxrv.i3mP2MJxd9g7IxJvxz3sF.dkVA9Ulwe', 'Especialista', '', '2024-10-17 12:00:00', '2024-10-17 12:00:00'),
(15, 'MariaTrujillo', 'mtrujillo@gmail.com', '$2b$12$pXOG.eO0CSMH0YOWhJxrv.i3mP2MJxd9g7IxJvxz3sF.dkVA9Ulwe', 'Especialista', '', '2024-10-17 12:00:00', '2024-10-17 12:00:00');

CREATE TABLE Persona (
  personaCodigo INT(11) PRIMARY KEY AUTO_INCREMENT,
  usua_codigo_fk INT(11),
  identificacion VARCHAR(13) NOT NULL UNIQUE,
  tipoID ENUM('CC','TI') NOT NULL,
  nombre VARCHAR(40) NOT NULL,
  apellido VARCHAR(40) NOT NULL,
  edad TINYINT(2) NOT NULL,
  sexo ENUM('Masculino','Femenino') NOT NULL,
  celular VARCHAR(20) NOT NULL UNIQUE,
  direccion VARCHAR(100),
  telef2 VARCHAR(25) NULL UNIQUE,
  FOREIGN KEY (usua_codigo_fk) REFERENCES Usuario (usua_codigo) ON DELETE CASCADE ON UPDATE CASCADE
);

INSERT INTO Persona (personaCodigo, usua_codigo_fk, identificacion, tipoID, nombre, apellido, edad, sexo, celular, direccion, telef2) VALUES
(1, 1, 1034284499, 'CC', 'Harrison David', 'Guerrero Palacios', 18, 'Masculino', '3045955299', 'Calle 1', NULL),
(2, 2, 222, 'TI', 'Jose Efrain', 'Caicedo', 16, 'Masculino', '3145955299', 'Calle 2', NULL),
(3, 3, 333, 'CC', 'Juan Esteban', 'Martínez Macías', 18, 'Masculino', '3025544888', 'Calle 3', NULL),
(4, 4, 444, 'TI', 'Esteban', 'Peralta Avendaño', 17, 'Masculino', '3155955299', 'Calle 4', NULL),
(5, 5, 555, 'CC', 'Andrés', 'Perez', 20, 'Masculino', '3104444444', 'Calle 5', NULL),
(6, 6, 666, 'TI', 'Brayan', 'Hernández', 15, 'Masculino', '3105555555', 'Calle 6', NULL),
(7, 7, 777, 'CC', 'Paola', 'Gonzales', 25, 'Femenino', '3106666666', 'Calle 7', NULL),
(8, 8, 888, 'CC', 'Miguel', 'Merizalde', 22, 'Masculino', '3107777777', 'Calle 8', NULL),
(9, 9, 999, 'TI', 'Victor', 'Becerra', 17, 'Masculino', '3108888888', 'Calle 9', NULL),
(10, 10, 1000, 'CC', 'Maidy', 'Silva', 18, 'Femenino', '3109999999', 'Calle 10', NULL),
(11, 11, 1001, 'CC', 'Felipe', 'Monsalve', 45, 'Masculino', '3110000000', 'Calle 11', NULL),
(12, 12, 1002, 'CC', 'Cristian', 'Sanchez', 39, 'Masculino', '3120000000', 'Calle 12', NULL),
(13, 13, 1003, 'TI', 'Daniel', 'Henao', 16, 'Masculino', '3130000000', 'Calle 13', NULL),
(14, 14, 1004, 'CC', 'Camilo', 'Pachón', 14, 'Masculino', '3140000000', 'Calle 14', NULL),
(15, 15, 1005, 'CC', 'Maria', 'Trujillo', 29, 'Femenino', '3150000000', 'Calle 15', NULL);

CREATE TABLE Administrador (
  adminCodigo INT(11) PRIMARY KEY AUTO_INCREMENT,
  usua_codigo_fk INT(11) NOT NULL,
  personaCodigo_fk INT(11) NOT NULL,
  FOREIGN KEY (usua_codigo_fk) REFERENCES Usuario (usua_codigo) ON DELETE CASCADE ON UPDATE CASCADE,
  FOREIGN KEY (personaCodigo_fk) REFERENCES Persona (personaCodigo) ON DELETE CASCADE ON UPDATE CASCADE
);

INSERT INTO Administrador (adminCodigo, usua_codigo_fk, personaCodigo_fk) VALUES 
(1, 1, 1);

CREATE TABLE Especialidad (
  especialidadCodigo INT(11) AUTO_INCREMENT PRIMARY KEY,
  especialidadNombre VARCHAR(20) NOT NULL UNIQUE,
  descripcion VARCHAR(255) NOT NULL UNIQUE,
  duracion TIME NOT NULL,  
  costo DECIMAL(10,2) NOT NULL,
  diaSemana VARCHAR(255) NOT NULL,
  especialidad_foto VARCHAR(535) NOT NULL, 
  especialidad_creada TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  especialidad_actualizada TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO Especialidad (especialidadCodigo, especialidadNombre, descripcion, duracion, costo, diaSemana, especialidad_foto, especialidad_creada, especialidad_actualizada) VALUES 
(1, 'Chequeo General', 'Evaluación integral de la salud del paciente, que incluye exámenes físicos, análisis de laboratorio y 
revisiones de historial médico, para detectar problemas de salud antes de que se conviertan en serios.', '00:45:00', 40000.00, "Lunes, Martes, Miércoles, Jueves", "", "2024-10-17", "2024-10-17"),

(2, 'Citología', 'Estudio de células para detectar cambios o enfermedades, comúnmente utilizado en el diagnóstico del cáncer mediante pruebas como el Papanicolaou (Pap) para mujeres.', '00:15:00', 120000.00, "Martes, Miércoles, Sábado", "", "2024-10-17", "2024-10-17"),

(3, 'Dermatología', 'Especialidad que se ocupa del diagnóstico y tratamiento de enfermedades de la piel, cabello y uñas, así como problemas estéticos.','00:30:00', 200000.00, "Martes, Miércoles, Jueves", "", "2024-10-17", "2024-10-17"),

(4, 'Nutrición', 'Servicio enfocado en la evaluación y planificación de la dieta y hábitos alimenticios para promover la salud y prevenir enfermedades.','00:50:00', 37000.00, "Lunes, Martes, Jueves, Sábado", "", "2024-10-17", "2024-10-17"),

(5, 'Odontología', 'Rama de la medicina que se ocupa del diagnóstico, tratamiento y prevención de enfermedades bucodentales, incluyendo la salud de los dientes, encías y estructuras asociadas.','00:40:00', 200000.00, "Lunes, Miércoles, Sábado", "", "2024-10-17", "2024-10-17"),

(6, 'Oftalmología', 'Especialidad que se centra en el diagnóstico y tratamiento de enfermedades y condiciones del ojo, así como en la cirugía ocular.', '00:45:00', 220000.00, "Lunes, Miércoles, Viernes", "", "2024-10-17", "2024-10-17"),

(7, 'Optometría', 'Evaluación de la visión y prescripción de lentes correctivos; también se ocupa de la detección de algunas enfermedades oculares.','00:45:00', 60000.00, "Martes, Jueves, Viernes", "", "2024-10-17", "2024-10-17"),

(8, 'Ortodoncia',  'Especialidad dental que corrige los dientes y mandíbulas desalineados mediante el uso de aparatos ortopédicos y alineadores.','00:45:00', 450000.00, "Miércoles, Jueves, Sábado", "", "2024-10-17", "2024-10-17"),

(9, 'Pediatría', 'Rama de la medicina dedicada al cuidado de la salud infantil, desde el nacimiento hasta la adolescencia, abarcando el desarrollo físico, mental y social.','00:55:00', 150000.00, "Lunes, Martes, Miércoles, Sábado", "", "2024-10-17", "2024-10-17"),

(10, 'Psicología', 'Estudio y tratamiento de los procesos mentales y comportamientos, que incluye terapia para abordar problemas emocionales, conductuales y psicológicos.','00:55:00', 140000.00, "Lunes, Martes, Miércoles, Viernes", "", "2024-10-17", "2024-10-17"),

(11, 'Urología', 'Especialidad que se enfoca en el diagnóstico y tratamiento de enfermedades del sistema urinario en hombres y mujeres, y del sistema reproductor masculino.','00:40:00', 300000.00, "Lunes, Miércoles, Viernes, Sábado", "", "2024-10-17", "2024-10-17"),

(12, 'Venereología', 'Rama de la medicina que se ocupa del diagnóstico y tratamiento de enfermedades de transmisión sexual (ETS) y otros problemas relacionados con la salud sexual.','00:30:00', 87000.00, "Lunes, Viernes, Sábado", "", "2024-10-17", "2024-10-17");

CREATE TABLE Especialista (
  especialistaCodigo INT(11) PRIMARY KEY AUTO_INCREMENT,
  usua_codigo_fk INT(11) NOT NULL,
  personaCodigo_fk INT(11) NOT NULL,
  especialidadCodigo_fk INT(11) NOT NULL,
  FOREIGN KEY (usua_codigo_fk) REFERENCES Usuario (usua_codigo) ON DELETE CASCADE ON UPDATE CASCADE,
  FOREIGN KEY (personaCodigo_fk) REFERENCES Persona (personaCodigo) ON DELETE CASCADE ON UPDATE CASCADE,
  FOREIGN KEY (especialidadCodigo_fk) REFERENCES Especialidad (especialidadCodigo) ON DELETE CASCADE ON UPDATE CASCADE
);

INSERT INTO Especialista (especialistaCodigo, usua_codigo_fk, personaCodigo_fk, especialidadCodigo_fk) VALUES 
(1, 2, 2, 1),
(2, 4, 4, 2),
(3, 5, 5, 3),
(4, 6, 6, 4),
(5, 7, 7, 5),
(6, 8, 8, 6),
(7, 9, 9, 7),
(8, 10, 10, 8),
(9, 11, 11, 9),
(10, 12, 12, 10),
(11, 13, 13, 11),
(12, 14, 14, 12);

CREATE TABLE disponibilidadEspecialista (
  disponibilidadCodigo INT(11) PRIMARY KEY AUTO_INCREMENT,
  especialistaCodigo_fk INT(11) NOT NULL,
  diaSemana VARCHAR(255) NOT NULL,
  horaInicio TIME NOT NULL,
  horaFin TIME NOT NULL,
  FOREIGN KEY (especialistaCodigo_fk) REFERENCES Especialista (especialistaCodigo) ON DELETE CASCADE ON UPDATE CASCADE 
);

INSERT INTO disponibilidadEspecialista (disponibilidadCodigo, especialistaCodigo_fk, diaSemana, horaInicio, horaFin)VALUES 
(1, 1, "Lunes, Martes, Miércoles, Jueves", "07:00:00", "14:30:00"),
(2, 2, "Martes, Miércoles, Sábado", "07:00:00", "09:30:00"),
(3, 3, "Martes, Miércoles, Jueves", "07:00:00", "12:00:00"),
(4, 4, "Lunes, Martes, Jueves, Sábado", "07:00:00", "15:30:00"),
(5, 5, "Lunes, Miércoles, Sábado", "07:00:00", "13:40:00"),
(6, 6, "Lunes, Miércoles, Viernes", "07:00:00", "14:30:00"),
(7, 7, "Martes, Jueves, Viernes", "07:00:00", "14:30:00"),
(8, 8, "Miércoles, Jueves, Sábado", "07:00:00", "14:30:00"),
(9, 9, "Lunes, Martes, Miércoles, Sábado", "07:00:00", "16:10:00"),
(10, 10, "Lunes, Martes, Miércoles, Viernes", "07:00:00", "16:10:00"),
(11, 11, "Lunes, Miércoles, Viernes, Sábado", "07:00:00", "13:40:00"),
(12, 12, "Lunes, Viernes, Sábado", "07:00:00", "12:00:00");

CREATE TABLE Paciente (
  pacienteCodigo INT(11) PRIMARY KEY AUTO_INCREMENT NOT NULL,
  usua_codigo_fk INT(11) NOT NULL,
  personaCodigo_fk INT(11) NOT NULL,
  FOREIGN KEY (usua_codigo_fk) REFERENCES Usuario (usua_codigo) ON DELETE CASCADE ON UPDATE CASCADE,
  FOREIGN KEY (personaCodigo_fk) REFERENCES Persona (personaCodigo) ON DELETE CASCADE ON UPDATE CASCADE
);

INSERT INTO Paciente (pacienteCodigo, usua_codigo_fk, personaCodigo_fk) VALUES 
(1, 3, 3),
(2, 4, 4);

CREATE TABLE Cita (
  citaCodigo INT (11) PRIMARY KEY AUTO_INCREMENT,
  especialidadCodigo_fk INT(11) NOT NULL,
  especialistaCodigo_fk INT(11) NOT NULL, 
  pacienteCodigo_fk INT(11) NOT NULL,
  fecha DATE NOT NULL,
  horaInicio TIME NOT NULL,
  horaFin TIME NOT NULL,
  estado ENUM('Completada', 'Agendada', 'Cancelada') NOT NULL,
  diaSemana ENUM('Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo') NOT NULL,
  FOREIGN KEY (especialidadCodigo_fk) REFERENCES Especialidad(especialidadCodigo) ON DELETE CASCADE ON UPDATE CASCADE,
  FOREIGN KEY (especialistaCodigo_fk) REFERENCES Especialista(especialistaCodigo) ON DELETE CASCADE ON UPDATE CASCADE,
  FOREIGN KEY (pacienteCodigo_fk) REFERENCES Paciente(pacienteCodigo) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE historialCita (
  historialCodigo INT(11) PRIMARY KEY AUTO_INCREMENT,
  citaCodigo_fk INT(11) NOT NULL,
  fecha_modificacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  diaSemana ENUM('Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo') NOT NULL,
  estado_anterior ENUM('Completada', 'Agendada', 'Cancelada'),
  estado_nuevo ENUM('Agendada', 'Cancelada'),
  FOREIGN KEY (citaCodigo_fk) REFERENCES Cita(citaCodigo) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE cancelacionCita (
  cancelacionCodigo INT(11) PRIMARY KEY AUTO_INCREMENT,
  citaCodigo_fk INT(11) NOT NULL,
  usua_codigo_fk INT(11) NOT NULL,
  fecha_cancelacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  diaSemana ENUM('Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo') NOT NULL,
  motivo VARCHAR(255) NOT NULL,
  FOREIGN KEY (citaCodigo_fk) REFERENCES Cita(citaCodigo) ON DELETE CASCADE ON UPDATE CASCADE,
  FOREIGN KEY (usua_codigo_fk) REFERENCES Usuario(usua_codigo) ON DELETE CASCADE ON UPDATE CASCADE
);